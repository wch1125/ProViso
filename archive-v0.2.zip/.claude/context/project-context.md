# CreditLang Project Context

## What This Project Is

CreditLang is a domain-specific language that makes credit agreements executable. Instead of PDFs that require expensive legal memos to interpret, CreditLang files are programs that can answer compliance questions instantly.

### The Problem We're Solving

1. **"Can we do X?" questions** cost $50K and 2 weeks for a legal memo
2. **Basket tracking** is manual Excel work, error-prone
3. **Covenant compliance** requires quarterly scrambles
4. **Pro forma analysis** for M&A/financing is slow and uncertain

### The Solution

A DSL where credit agreements are code:
- Source reads like the legal document
- But executes like a program
- Answers questions with citations
- Tracks basket utilization automatically
- Simulates transactions instantly

## Domain Terminology

| Term | Meaning |
|------|---------|
| **Covenant** | A financial test the borrower must pass (e.g., leverage ratio ≤ 4.5x) |
| **Basket** | Permitted capacity for a restricted action (e.g., $25M for investments) |
| **EBITDA** | Earnings Before Interest, Taxes, Depreciation, Amortization |
| **Leverage** | Total Debt / EBITDA - measures how indebted the company is |
| **Pro Forma** | "As if" - calculations assuming a proposed transaction happened |
| **Event of Default** | A trigger that lets lenders accelerate the loan |
| **Grower Basket** | Capacity that grows with company size (% of EBITDA or assets) |
| **Builder Basket** | Capacity that accumulates over time (retained earnings, asset sale proceeds) |

## Technical Decisions

### Parser: Peggy (PEG)
- Chose PEG over alternatives (ANTLR, nearley) for:
  - Simple JavaScript integration
  - Readable grammar syntax
  - Good error messages
  - Single-file output

### Runtime: TypeScript
- Type safety for complex AST
- Good IDE support
- Easy async/await for future API work

### No External Database (MVP)
- State lives in interpreter instance
- Financial data loaded from JSON
- Keeps MVP simple; SQLite/Postgres for v1.0

## Architecture Notes

### Expression Evaluation
The interpreter uses recursive evaluation:
1. Identifiers resolve to definitions or raw financial data
2. Definitions evaluate their expression, applying modifiers (EXCLUDING, CAPPED AT)
3. Binary expressions recurse on left/right
4. Functions (GreaterOf, AVAILABLE, COMPLIANT) have special handling

### Precedence System (Planned)
Credit agreements have complex override rules:
```
PROHIBIT → EXCEPT → NOTWITHSTANDING → Amendment
```
Current MVP handles basic EXCEPT; full precedence coming in v0.2.

## Open Questions

### Language Design
- [ ] How to handle "including but not limited to" (non-exhaustive lists)?
- [ ] How to flag "material" and other judgment terms for human review?
- [ ] What should compile errors look like for lawyers?

### Product
- [ ] Who authors the CreditLang file? (Law firm? Borrower? Service provider?)
- [ ] Liability model if tool says "permitted" incorrectly?
- [ ] Integration with existing legal tech (iManage, NetDocs)?

## What's Working

- Core parser for MVP syntax
- DEFINE with arithmetic and modifiers
- COVENANT with comparison operators
- BASKET with fixed and GreaterOf capacity
- CONDITION with boolean logic
- PROHIBIT/EXCEPT with condition checking
- EVENT with triggers (evaluation not fully implemented)
- Pro forma simulation
- CLI with formatted output

## What's Next (v0.2)

1. **Grower/Builder Baskets** - Capacity that changes over time
2. **Basket Ledger** - Transaction history with audit trail
3. **Amendment Overlays** - Versioned changes to base agreement
4. **Cure Rights** - Mechanism to fix covenant breaches

## Files to Know

| File | Purpose |
|------|---------|
| `grammar/creditlang.pegjs` | The grammar - start here for syntax |
| `src/types.ts` | All TypeScript interfaces |
| `src/interpreter.ts` | The runtime - evaluation logic |
| `examples/corporate_revolver.crl` | Sample agreement to test against |
