// CreditLang Test Suite
import { describe, it, expect, beforeEach } from 'vitest';
import { parse, parseOrThrow } from '../src/parser.js';
import { CreditLangInterpreter } from '../src/interpreter.js';
import { Program } from '../src/types.js';

// ==================== PARSER TESTS ====================

describe('Parser', () => {
  it('should parse DEFINE statements', async () => {
    const source = `
      DEFINE EBITDA AS
        net_income + interest_expense + tax_expense
    `;
    const ast = await parseOrThrow(source);
    expect(ast.type).toBe('Program');
    expect(ast.statements.length).toBeGreaterThan(0);
    
    const define = ast.statements.find(s => s.type === 'Define');
    expect(define).toBeDefined();
    expect((define as any).name).toBe('EBITDA');
  });

  it('should parse COVENANT statements', async () => {
    const source = `
      COVENANT MaxLeverage
        REQUIRES Leverage <= 4.50
        TESTED QUARTERLY
    `;
    const ast = await parseOrThrow(source);
    const covenant = ast.statements.find(s => s.type === 'Covenant');
    expect(covenant).toBeDefined();
    expect((covenant as any).name).toBe('MaxLeverage');
    expect((covenant as any).tested).toBe('quarterly');
  });

  it('should parse BASKET statements', async () => {
    const source = `
      BASKET GeneralInvestments
        CAPACITY $25_000_000
    `;
    const ast = await parseOrThrow(source);
    const basket = ast.statements.find(s => s.type === 'Basket');
    expect(basket).toBeDefined();
    expect((basket as any).name).toBe('GeneralInvestments');
  });

  it('should parse currency with underscores', async () => {
    const source = `
      BASKET Test
        CAPACITY $1_000_000
    `;
    const ast = await parseOrThrow(source);
    const basket = ast.statements.find(s => s.type === 'Basket') as any;
    expect(basket.capacity.value).toBe(1000000);
  });

  it('should parse GreaterOf function', async () => {
    const source = `
      BASKET RestrictedPayments
        CAPACITY GreaterOf($10_000_000, 5% * total_assets)
    `;
    const ast = await parseOrThrow(source);
    const basket = ast.statements.find(s => s.type === 'Basket') as any;
    expect(basket.capacity.type).toBe('FunctionCall');
    expect(basket.capacity.name).toBe('GreaterOf');
  });

  it('should parse CONDITION statements', async () => {
    const source = `
      CONDITION NoDefault AS
        NOT EXISTS(EventOfDefault)
    `;
    const ast = await parseOrThrow(source);
    const condition = ast.statements.find(s => s.type === 'Condition');
    expect(condition).toBeDefined();
    expect((condition as any).name).toBe('NoDefault');
  });

  it('should parse PROHIBIT with EXCEPT WHEN', async () => {
    const source = `
      PROHIBIT Dividends
        EXCEPT WHEN
          | amount <= AVAILABLE(RestrictedPayments)
          | AND NoDefault
    `;
    const ast = await parseOrThrow(source);
    const prohibit = ast.statements.find(s => s.type === 'Prohibit');
    expect(prohibit).toBeDefined();
    expect((prohibit as any).target).toBe('Dividends');
    expect((prohibit as any).exceptions.length).toBeGreaterThan(0);
  });

  it('should parse EVENT statements', async () => {
    const source = `
      EVENT CrossDefault
        TRIGGERS WHEN external_debt_default > 10_000_000
        CONSEQUENCE EventOfDefault
    `;
    const ast = await parseOrThrow(source);
    const event = ast.statements.find(s => s.type === 'Event');
    expect(event).toBeDefined();
    expect((event as any).name).toBe('CrossDefault');
  });

  it('should parse comments', async () => {
    const source = `
      // This is a comment
      DEFINE Test AS 100
    `;
    const ast = await parseOrThrow(source);
    expect(ast.statements.length).toBe(2);
  });
});

// ==================== INTERPRETER TESTS ====================

describe('Interpreter', () => {
  let interpreter: CreditLangInterpreter;

  const sampleSource = `
    DEFINE EBITDA AS
      net_income + interest_expense + tax_expense + depreciation + amortization
      EXCLUDING extraordinary_items

    DEFINE TotalDebt AS
      funded_debt + capital_leases

    DEFINE Leverage AS
      TotalDebt / EBITDA

    COVENANT MaxLeverage
      REQUIRES Leverage <= 4.50
      TESTED QUARTERLY

    COVENANT MinLiquidity
      REQUIRES cash >= 15_000_000
      TESTED QUARTERLY

    BASKET GeneralInvestments
      CAPACITY $25_000_000

    BASKET RestrictedPayments
      CAPACITY GreaterOf($10_000_000, 5% * total_assets)

    CONDITION NoDefault AS
      NOT EXISTS(EventOfDefault)

    PROHIBIT Investments
      EXCEPT WHEN
        | amount <= AVAILABLE(GeneralInvestments)
        | AND NoDefault
  `;

  const sampleFinancials = {
    net_income: 22000000,
    interest_expense: 8200000,
    tax_expense: 7500000,
    depreciation: 4800000,
    amortization: 2200000,
    extraordinary_items: 0,
    funded_debt: 156000000,
    capital_leases: 5000000,
    cash: 28400000,
    total_assets: 340000000,
  };

  beforeEach(async () => {
    const ast = await parseOrThrow(sampleSource);
    interpreter = new CreditLangInterpreter(ast);
    interpreter.loadFinancials(sampleFinancials);
  });

  describe('Expression Evaluation', () => {
    it('should evaluate EBITDA correctly', () => {
      // EBITDA = net_income + interest + tax + depreciation + amortization - extraordinary
      // = 22M + 8.2M + 7.5M + 4.8M + 2.2M - 0 = 44.7M
      const ebitda = interpreter['evaluate']('EBITDA');
      expect(ebitda).toBe(44700000);
    });

    it('should evaluate TotalDebt correctly', () => {
      // TotalDebt = funded_debt + capital_leases = 156M + 5M = 161M
      const totalDebt = interpreter['evaluate']('TotalDebt');
      expect(totalDebt).toBe(161000000);
    });

    it('should evaluate Leverage correctly', () => {
      // Leverage = TotalDebt / EBITDA = 161M / 44.7M ≈ 3.60
      const leverage = interpreter['evaluate']('Leverage');
      expect(leverage).toBeCloseTo(3.60, 1);
    });
  });

  describe('Covenant Checking', () => {
    it('should check MaxLeverage covenant', () => {
      const result = interpreter.checkCovenant('MaxLeverage');
      expect(result.compliant).toBe(true);
      expect(result.actual).toBeCloseTo(3.60, 1);
      expect(result.threshold).toBe(4.50);
      expect(result.headroom).toBeCloseTo(0.90, 1);
    });

    it('should check MinLiquidity covenant', () => {
      const result = interpreter.checkCovenant('MinLiquidity');
      expect(result.compliant).toBe(true);
      expect(result.actual).toBe(28400000);
      expect(result.threshold).toBe(15000000);
    });

    it('should return all covenants', () => {
      const results = interpreter.checkAllCovenants();
      expect(results.length).toBe(2);
    });
  });

  describe('Basket Operations', () => {
    it('should calculate basket capacity', () => {
      const capacity = interpreter.getBasketCapacity('GeneralInvestments');
      expect(capacity).toBe(25000000);
    });

    it('should calculate GreaterOf basket capacity', () => {
      // GreaterOf($10M, 5% * $340M) = GreaterOf($10M, $17M) = $17M
      const capacity = interpreter.getBasketCapacity('RestrictedPayments');
      expect(capacity).toBe(17000000);
    });

    it('should track basket utilization', () => {
      const initialAvailable = interpreter.getBasketAvailable('GeneralInvestments');
      expect(initialAvailable).toBe(25000000);

      interpreter.useBasket('GeneralInvestments', 5000000, 'Test investment');
      
      const afterUse = interpreter.getBasketAvailable('GeneralInvestments');
      expect(afterUse).toBe(20000000);
    });

    it('should prevent over-utilization', () => {
      expect(() => {
        interpreter.useBasket('GeneralInvestments', 30000000, 'Too much');
      }).toThrow(/Insufficient basket capacity/);
    });
  });

  describe('Condition Evaluation', () => {
    it('should evaluate NoDefault condition (no defaults)', () => {
      const result = interpreter.evaluateBoolean('NoDefault');
      expect(result).toBe(true);
    });

    it('should evaluate NoDefault condition (with default)', () => {
      interpreter.setEventDefault('EventOfDefault');
      const result = interpreter.evaluateBoolean('NoDefault');
      expect(result).toBe(false);
    });
  });

  describe('Prohibition Checking', () => {
    it('should permit investment within basket', () => {
      const result = interpreter.checkProhibition('Investments', 10000000);
      expect(result.permitted).toBe(true);
    });

    it('should prohibit investment exceeding basket', () => {
      const result = interpreter.checkProhibition('Investments', 30000000);
      expect(result.permitted).toBe(false);
    });

    it('should prohibit investment when in default', () => {
      interpreter.setEventDefault('EventOfDefault');
      const result = interpreter.checkProhibition('Investments', 10000000);
      expect(result.permitted).toBe(false);
    });
  });

  describe('Simulation', () => {
    it('should simulate pro forma changes', () => {
      // Add $50M debt and see if still compliant
      const result = interpreter.simulate({ funded_debt: 206000000 });
      
      const maxLeverage = result.covenants.find(c => c.name === 'MaxLeverage');
      expect(maxLeverage).toBeDefined();
      // New leverage = (206M + 5M) / 44.7M = 4.72x > 4.50x
      expect(maxLeverage!.compliant).toBe(false);
    });

    it('should not modify original state', () => {
      const originalLeverage = interpreter.checkCovenant('MaxLeverage');
      interpreter.simulate({ funded_debt: 500000000 });
      const afterSimLeverage = interpreter.checkCovenant('MaxLeverage');
      
      expect(afterSimLeverage.actual).toBe(originalLeverage.actual);
    });
  });
});

// ==================== GROWER/BUILDER BASKET TESTS ====================

describe('Grower Baskets', () => {
  it('should parse FLOOR clause', async () => {
    const source = `
      BASKET EBITDABasket
        CAPACITY 10% * EBITDA
        FLOOR $5_000_000
    `;
    const ast = await parseOrThrow(source);
    const basket = ast.statements.find(s => s.type === 'Basket') as any;
    expect(basket.floor).toBeDefined();
    expect(basket.floor.value).toBe(5000000);
  });

  it('should calculate grower basket capacity', async () => {
    const source = `
      DEFINE EBITDA AS net_income

      BASKET EBITDABasket
        CAPACITY 10% * EBITDA
    `;
    const ast = await parseOrThrow(source);
    const interpreter = new CreditLangInterpreter(ast);
    interpreter.loadFinancials({ net_income: 50000000 });

    // 10% of $50M = $5M
    const capacity = interpreter.getBasketCapacity('EBITDABasket');
    expect(capacity).toBe(5000000);
  });

  it('should apply floor when capacity is below minimum', async () => {
    const source = `
      DEFINE EBITDA AS net_income

      BASKET EBITDABasket
        CAPACITY 10% * EBITDA
        FLOOR $10_000_000
    `;
    const ast = await parseOrThrow(source);
    const interpreter = new CreditLangInterpreter(ast);
    interpreter.loadFinancials({ net_income: 50000000 });

    // 10% of $50M = $5M, but floor is $10M
    const capacity = interpreter.getBasketCapacity('EBITDABasket');
    expect(capacity).toBe(10000000);
  });

  it('should not apply floor when capacity exceeds minimum', async () => {
    const source = `
      DEFINE EBITDA AS net_income

      BASKET EBITDABasket
        CAPACITY 10% * EBITDA
        FLOOR $2_000_000
    `;
    const ast = await parseOrThrow(source);
    const interpreter = new CreditLangInterpreter(ast);
    interpreter.loadFinancials({ net_income: 50000000 });

    // 10% of $50M = $5M > floor of $2M
    const capacity = interpreter.getBasketCapacity('EBITDABasket');
    expect(capacity).toBe(5000000);
  });

  it('should report grower basket status with details', async () => {
    const source = `
      DEFINE EBITDA AS net_income

      BASKET EBITDABasket
        CAPACITY 10% * EBITDA
        FLOOR $10_000_000
    `;
    const ast = await parseOrThrow(source);
    const interpreter = new CreditLangInterpreter(ast);
    interpreter.loadFinancials({ net_income: 50000000 });

    const status = interpreter.getBasketStatus('EBITDABasket');
    expect(status.basketType).toBe('grower');
    expect(status.baseCapacity).toBe(5000000);
    expect(status.floor).toBe(10000000);
    expect(status.capacity).toBe(10000000);
  });

  it('should identify grower baskets', async () => {
    const source = `
      BASKET Fixed CAPACITY $10_000_000

      BASKET Grower
        CAPACITY 10% * total_assets
        FLOOR $5_000_000
    `;
    const ast = await parseOrThrow(source);
    const interpreter = new CreditLangInterpreter(ast);
    interpreter.loadFinancials({ total_assets: 100000000 });

    const growerNames = interpreter.getGrowerBasketNames();
    expect(growerNames).toContain('Grower');
    expect(growerNames).not.toContain('Fixed');
  });
});

describe('Builder Baskets', () => {
  it('should parse BUILDS_FROM clause', async () => {
    const source = `
      BASKET RetainedEarnings
        BUILDS_FROM 50% * net_income
        STARTING $10_000_000
    `;
    const ast = await parseOrThrow(source);
    const basket = ast.statements.find(s => s.type === 'Basket') as any;
    expect(basket.buildsFrom).toBeDefined();
    expect(basket.starting).toBeDefined();
    expect(basket.starting.value).toBe(10000000);
  });

  it('should parse MAXIMUM clause', async () => {
    const source = `
      BASKET RetainedEarnings
        BUILDS_FROM 50% * net_income
        STARTING $10_000_000
        MAXIMUM $50_000_000
    `;
    const ast = await parseOrThrow(source);
    const basket = ast.statements.find(s => s.type === 'Basket') as any;
    expect(basket.maximum).toBeDefined();
    expect(basket.maximum.value).toBe(50000000);
  });

  it('should start with initial capacity', async () => {
    const source = `
      BASKET RetainedEarnings
        BUILDS_FROM 50% * net_income
        STARTING $10_000_000
    `;
    const ast = await parseOrThrow(source);
    const interpreter = new CreditLangInterpreter(ast);
    interpreter.loadFinancials({ net_income: 5000000 });

    const capacity = interpreter.getBasketCapacity('RetainedEarnings');
    expect(capacity).toBe(10000000);
  });

  it('should accumulate capacity over time', async () => {
    const source = `
      BASKET RetainedEarnings
        BUILDS_FROM 50% * net_income
        STARTING $10_000_000
    `;
    const ast = await parseOrThrow(source);
    const interpreter = new CreditLangInterpreter(ast);
    interpreter.loadFinancials({ net_income: 8000000 });

    // Initial capacity
    expect(interpreter.getBasketCapacity('RetainedEarnings')).toBe(10000000);

    // Accumulate Q1 earnings (50% of $8M = $4M)
    const accumulated = interpreter.accumulateBuilderBasket('RetainedEarnings', 'Q1 2024 earnings');
    expect(accumulated).toBe(4000000);

    // New capacity = $10M + $4M = $14M
    expect(interpreter.getBasketCapacity('RetainedEarnings')).toBe(14000000);

    // Accumulate Q2 earnings
    interpreter.accumulateBuilderBasket('RetainedEarnings', 'Q2 2024 earnings');
    expect(interpreter.getBasketCapacity('RetainedEarnings')).toBe(18000000);
  });

  it('should respect maximum cap', async () => {
    const source = `
      BASKET RetainedEarnings
        BUILDS_FROM 50% * net_income
        STARTING $10_000_000
        MAXIMUM $15_000_000
    `;
    const ast = await parseOrThrow(source);
    const interpreter = new CreditLangInterpreter(ast);
    interpreter.loadFinancials({ net_income: 20000000 });

    // Accumulate (50% of $20M = $10M), but max is $15M
    interpreter.accumulateBuilderBasket('RetainedEarnings', 'Q1 2024 earnings');

    // Should be capped at $15M
    expect(interpreter.getBasketCapacity('RetainedEarnings')).toBe(15000000);

    // Further accumulation should not increase capacity
    interpreter.accumulateBuilderBasket('RetainedEarnings', 'Q2 2024 earnings');
    expect(interpreter.getBasketCapacity('RetainedEarnings')).toBe(15000000);
  });

  it('should report builder basket status with details', async () => {
    const source = `
      BASKET RetainedEarnings
        BUILDS_FROM 50% * net_income
        STARTING $10_000_000
        MAXIMUM $50_000_000
    `;
    const ast = await parseOrThrow(source);
    const interpreter = new CreditLangInterpreter(ast);
    interpreter.loadFinancials({ net_income: 8000000 });

    interpreter.accumulateBuilderBasket('RetainedEarnings', 'Q1 earnings');

    const status = interpreter.getBasketStatus('RetainedEarnings');
    expect(status.basketType).toBe('builder');
    expect(status.accumulated).toBe(4000000);
    expect(status.maximum).toBe(50000000);
    expect(status.capacity).toBe(14000000);
  });

  it('should track accumulation in ledger', async () => {
    const source = `
      BASKET RetainedEarnings
        BUILDS_FROM 50% * net_income
        STARTING $10_000_000
    `;
    const ast = await parseOrThrow(source);
    const interpreter = new CreditLangInterpreter(ast);
    interpreter.loadFinancials({ net_income: 8000000 });

    interpreter.accumulateBuilderBasket('RetainedEarnings', 'Q1 2024 earnings');
    interpreter.useBasket('RetainedEarnings', 5000000, 'Investment');

    const ledger = interpreter.getBasketLedger();
    expect(ledger.length).toBe(2);
    expect(ledger[0].entryType).toBe('accumulation');
    expect(ledger[0].amount).toBe(4000000);
    expect(ledger[1].entryType).toBe('usage');
    expect(ledger[1].amount).toBe(5000000);
  });

  it('should identify builder baskets', async () => {
    const source = `
      BASKET Fixed CAPACITY $10_000_000

      BASKET Builder
        BUILDS_FROM 50% * net_income
        STARTING $5_000_000
    `;
    const ast = await parseOrThrow(source);
    const interpreter = new CreditLangInterpreter(ast);
    interpreter.loadFinancials({ net_income: 5000000 });

    const builderNames = interpreter.getBuilderBasketNames();
    expect(builderNames).toContain('Builder');
    expect(builderNames).not.toContain('Fixed');
  });

  it('should throw error when accumulating non-builder basket', async () => {
    const source = `
      BASKET Fixed CAPACITY $10_000_000
    `;
    const ast = await parseOrThrow(source);
    const interpreter = new CreditLangInterpreter(ast);

    expect(() => {
      interpreter.accumulateBuilderBasket('Fixed', 'Test');
    }).toThrow(/not a builder basket/);
  });
});

// ==================== INTEGRATION TESTS ====================

describe('Integration', () => {
  it('should handle a complete credit agreement', async () => {
    const source = `
      // Sample Corporate Credit Agreement
      
      DEFINE EBITDA AS
        net_income + interest_expense + tax_expense + depreciation + amortization
      
      DEFINE TotalDebt AS
        funded_debt + capital_leases
      
      DEFINE Leverage AS
        TotalDebt / EBITDA
      
      COVENANT MaxLeverage
        REQUIRES Leverage <= 4.50
        TESTED QUARTERLY
      
      COVENANT MinInterestCoverage
        REQUIRES EBITDA / interest_expense >= 2.50
        TESTED QUARTERLY
      
      BASKET GeneralInvestments
        CAPACITY $25_000_000
      
      CONDITION NoDefault AS
        NOT EXISTS(EventOfDefault)
      
      CONDITION ProFormaCompliance AS
        COMPLIANT(MaxLeverage) AND COMPLIANT(MinInterestCoverage)
      
      PROHIBIT Investments
        EXCEPT WHEN
          | amount <= AVAILABLE(GeneralInvestments)
          | AND NoDefault
    `;

    const ast = await parseOrThrow(source);
    const interpreter = new CreditLangInterpreter(ast);
    
    interpreter.loadFinancials({
      net_income: 22000000,
      interest_expense: 8200000,
      tax_expense: 7500000,
      depreciation: 4800000,
      amortization: 2200000,
      funded_debt: 156000000,
      capital_leases: 5000000,
      cash: 28400000,
      total_assets: 340000000,
    });

    const status = interpreter.getStatus();
    
    expect(status.overallCompliant).toBe(true);
    expect(status.covenants.length).toBe(2);
    expect(status.baskets.length).toBe(1);
    
    // Check ProFormaCompliance condition
    expect(interpreter.evaluateBoolean('ProFormaCompliance')).toBe(true);
    
    // Test prohibition
    const queryResult = interpreter.checkProhibition('Investments', 10000000);
    expect(queryResult.permitted).toBe(true);
  });
});

// ==================== PARSE ERROR TESTS ====================

describe('Parse Errors', () => {
  it('should return error with location for unknown keyword', async () => {
    const source = 'COVENAT MaxLeverage REQUIRES Leverage <= 4.5';
    const result = await parse(source);

    expect(result.success).toBe(false);
    expect(result.error).toBeDefined();
    expect(result.error?.location).toBeDefined();
    expect(result.error?.location?.start.line).toBe(1);
    expect(result.error?.location?.start.column).toBe(1);
  });

  it('should capture expected tokens', async () => {
    const source = 'COVENAT MaxLeverage';
    const result = await parse(source);

    expect(result.success).toBe(false);
    expect(result.error?.expected).toBeDefined();
    expect(result.error?.expected?.length).toBeGreaterThan(0);
  });

  it('should capture what was found', async () => {
    const source = 'COVENAT MaxLeverage';
    const result = await parse(source);

    expect(result.success).toBe(false);
    // Peggy reports the first character as "found"
    expect(result.error?.found).toBeDefined();
  });

  it('should include source in result for context display', async () => {
    const source = 'INVALID SYNTAX HERE';
    const result = await parse(source);

    expect(result.success).toBe(false);
    expect(result.source).toBe(source);
  });

  it('should provide location for mid-file errors', async () => {
    const source = `
DEFINE EBITDA AS 100

COVENAT MaxLeverage REQUIRES x > 1
`;
    const result = await parse(source);

    expect(result.success).toBe(false);
    expect(result.error?.location?.start.line).toBe(4);
  });

  it('should provide location for expression errors', async () => {
    const source = `
DEFINE EBITDA AS
  net_income + + interest
`;
    const result = await parse(source);

    expect(result.success).toBe(false);
    expect(result.error?.location).toBeDefined();
  });

  it('should have expected list include valid keywords', async () => {
    const source = 'BADKEYWORD Test';
    const result = await parse(source);

    expect(result.success).toBe(false);
    // Expected should include valid top-level keywords
    const expectedLower = result.error?.expected?.map(e => e.toLowerCase()) ?? [];
    const hasValidKeyword = expectedLower.some(e =>
      e.includes('define') || e.includes('covenant') || e.includes('basket')
    );
    expect(hasValidKeyword).toBe(true);
  });
});

// ==================== SEMANTIC VALIDATION TESTS ====================

import { validate } from '../src/validator.js';

describe('Semantic Validation', () => {
  it('should pass for valid program', async () => {
    const source = `
      DEFINE EBITDA AS net_income
      COVENANT MaxLeverage REQUIRES EBITDA > 0
      BASKET GeneralInvestments CAPACITY $25_000_000
      CONDITION NoDefault AS COMPLIANT(MaxLeverage)
    `;
    const ast = await parseOrThrow(source);
    const result = validate(ast);

    expect(result.valid).toBe(true);
    expect(result.errors.length).toBe(0);
  });

  it('should error on undefined basket in AVAILABLE()', async () => {
    const source = `
      PROHIBIT Investments
        EXCEPT WHEN
          | amount <= AVAILABLE(NonExistentBasket)
    `;
    const ast = await parseOrThrow(source);
    const result = validate(ast);

    expect(result.valid).toBe(false);
    expect(result.errors.length).toBe(1);
    expect(result.errors[0]!.message).toContain('NonExistentBasket');
    expect(result.errors[0]!.expectedType).toBe('basket');
  });

  it('should error on undefined covenant in COMPLIANT()', async () => {
    const source = `
      CONDITION Test AS
        COMPLIANT(NonExistentCovenant)
    `;
    const ast = await parseOrThrow(source);
    const result = validate(ast);

    expect(result.valid).toBe(false);
    expect(result.errors.length).toBe(1);
    expect(result.errors[0]!.message).toContain('NonExistentCovenant');
    expect(result.errors[0]!.expectedType).toBe('covenant');
  });

  it('should error on undefined condition in SUBJECT TO', async () => {
    const source = `
      BASKET Test
        CAPACITY $1_000_000
        SUBJECT TO UndefinedCondition
    `;
    const ast = await parseOrThrow(source);
    const result = validate(ast);

    expect(result.valid).toBe(false);
    expect(result.errors.length).toBe(1);
    expect(result.errors[0]!.message).toContain('UndefinedCondition');
    expect(result.errors[0]!.expectedType).toBe('condition');
  });

  it('should warn on undefined identifier (possible financial data)', async () => {
    const source = `
      DEFINE Test AS undefined_field
    `;
    const ast = await parseOrThrow(source);
    const result = validate(ast);

    // Not an error because it might be financial data
    expect(result.valid).toBe(true);
    expect(result.errors.length).toBe(0);
    expect(result.warnings.length).toBeGreaterThan(0);
    expect(result.warnings[0]!.message).toContain('undefined_field');
  });

  it('should resolve references to defined terms', async () => {
    const source = `
      DEFINE EBITDA AS net_income
      DEFINE Leverage AS total_debt / EBITDA
    `;
    const ast = await parseOrThrow(source);
    const result = validate(ast);

    // EBITDA reference in Leverage should be resolved
    // Only net_income and total_debt should generate warnings
    expect(result.valid).toBe(true);
    expect(result.errors.length).toBe(0);
    const warningMessages = result.warnings.map(w => w.reference);
    expect(warningMessages).toContain('net_income');
    expect(warningMessages).toContain('total_debt');
    expect(warningMessages).not.toContain('EBITDA');
  });

  // Note: Unknown functions are caught at parse time by the grammar
  // which only allows specific function names. No semantic validation test needed.

  it('should validate GreaterOf arguments', async () => {
    const source = `
      BASKET Test
        CAPACITY GreaterOf($1_000_000, 5% * EBITDA)
    `;
    const ast = await parseOrThrow(source);
    const result = validate(ast);

    // EBITDA is undefined, so there should be a warning
    expect(result.valid).toBe(true);
    expect(result.warnings.length).toBeGreaterThan(0);
    expect(result.warnings.some(w => w.reference === 'EBITDA')).toBe(true);
  });

  it('should allow amount in PROHIBIT EXCEPT WHEN context', async () => {
    const source = `
      BASKET TestBasket CAPACITY $1_000_000
      PROHIBIT TestAction
        EXCEPT WHEN
          | amount <= AVAILABLE(TestBasket)
    `;
    const ast = await parseOrThrow(source);
    const result = validate(ast);

    // amount is a special binding, should not generate warning
    expect(result.valid).toBe(true);
    expect(result.warnings.some(w => w.reference === 'amount')).toBe(false);
  });

  it('should warn on EXISTS() with undefined event', async () => {
    const source = `
      CONDITION Test AS EXISTS(UndefinedEvent)
    `;
    const ast = await parseOrThrow(source);
    const result = validate(ast);

    // EXISTS with undefined event is a warning (might be runtime state)
    expect(result.valid).toBe(true);
    expect(result.warnings.length).toBe(1);
    expect(result.warnings[0]!.reference).toBe('UndefinedEvent');
    expect(result.warnings[0]!.expectedType).toBe('event');
  });

  it('should not warn on EXISTS() with defined event', async () => {
    const source = `
      EVENT TestEvent TRIGGERS WHEN x > 0
      CONDITION Test AS EXISTS(TestEvent)
    `;
    const ast = await parseOrThrow(source);
    const result = validate(ast);

    // EXISTS with defined event should not generate warnings for the event
    const existsWarnings = result.warnings.filter(w => w.reference === 'TestEvent');
    expect(existsWarnings.length).toBe(0);
  });

  it('should validate complex expressions', async () => {
    const source = `
      BASKET TestBasket CAPACITY $1_000_000
      COVENANT MaxLev REQUIRES x <= 4.5
      CONDITION NoDefault AS COMPLIANT(MaxLev)
      PROHIBIT Dividends
        EXCEPT WHEN
          | amount <= AVAILABLE(TestBasket)
          | AND NoDefault
    `;
    const ast = await parseOrThrow(source);
    const result = validate(ast);

    expect(result.valid).toBe(true);
    expect(result.errors.length).toBe(0);
    // Only x should generate a warning (undefined financial data)
    const warningRefs = result.warnings.map(w => w.reference);
    expect(warningRefs).toContain('x');
    expect(warningRefs).not.toContain('NoDefault');
    expect(warningRefs).not.toContain('MaxLev');
    expect(warningRefs).not.toContain('TestBasket');
  });

  it('should validate EXCLUDING items', async () => {
    const source = `
      DEFINE EBITDA AS net_income
        EXCLUDING extraordinary_items
    `;
    const ast = await parseOrThrow(source);
    const result = validate(ast);

    expect(result.valid).toBe(true);
    // extraordinary_items is not defined, should warn
    const excludingWarning = result.warnings.find(w => w.reference === 'extraordinary_items');
    expect(excludingWarning).toBeDefined();
    expect(excludingWarning!.context).toContain('DEFINE EBITDA');
  });

  it('should validate builder basket BUILDS_FROM expressions', async () => {
    const source = `
      DEFINE NetIncome AS revenue - expenses
      BASKET RetainedEarnings
        BUILDS_FROM 50% * NetIncome
        STARTING $10_000_000
        MAXIMUM $75_000_000
    `;
    const ast = await parseOrThrow(source);
    const result = validate(ast);

    expect(result.valid).toBe(true);
    // NetIncome reference should be resolved (no warning)
    const netIncomeWarning = result.warnings.find(w => w.reference === 'NetIncome');
    expect(netIncomeWarning).toBeUndefined();
    // revenue and expenses should have warnings
    expect(result.warnings.some(w => w.reference === 'revenue')).toBe(true);
    expect(result.warnings.some(w => w.reference === 'expenses')).toBe(true);
  });

  it('should validate grower basket FLOOR expressions', async () => {
    const source = `
      BASKET Test
        CAPACITY 10% * undefined_metric
        FLOOR $5_000_000
    `;
    const ast = await parseOrThrow(source);
    const result = validate(ast);

    expect(result.valid).toBe(true);
    expect(result.warnings.some(w => w.reference === 'undefined_metric')).toBe(true);
  });
});

// ==================== BASKET LEDGER TESTS ====================

describe('Basket Ledger', () => {
  it('should return empty ledger initially', async () => {
    const source = `
      BASKET TestBasket CAPACITY $10_000_000
    `;
    const ast = await parseOrThrow(source);
    const interpreter = new CreditLangInterpreter(ast);

    const ledger = interpreter.getBasketLedger();
    expect(ledger.length).toBe(0);
  });

  it('should record usage entries in ledger', async () => {
    const source = `
      BASKET TestBasket CAPACITY $10_000_000
    `;
    const ast = await parseOrThrow(source);
    const interpreter = new CreditLangInterpreter(ast);

    interpreter.useBasket('TestBasket', 5000000, 'Q1 Investment');

    const ledger = interpreter.getBasketLedger();
    expect(ledger.length).toBe(1);
    expect(ledger[0]!.basket).toBe('TestBasket');
    expect(ledger[0]!.amount).toBe(5000000);
    expect(ledger[0]!.entryType).toBe('usage');
    expect(ledger[0]!.description).toBe('Q1 Investment');
  });

  it('should record accumulation entries in ledger', async () => {
    const source = `
      BASKET Builder
        BUILDS_FROM 50% * net_income
        STARTING $1_000_000
    `;
    const ast = await parseOrThrow(source);
    const interpreter = new CreditLangInterpreter(ast);
    interpreter.loadFinancials({ net_income: 10000000 });

    interpreter.accumulateBuilderBasket('Builder', 'Q1 2024 earnings');

    const ledger = interpreter.getBasketLedger();
    expect(ledger.length).toBe(1);
    expect(ledger[0]!.basket).toBe('Builder');
    expect(ledger[0]!.amount).toBe(5000000);
    expect(ledger[0]!.entryType).toBe('accumulation');
  });

  it('should track multiple entries in order', async () => {
    const source = `
      BASKET Builder
        BUILDS_FROM 50% * net_income
        STARTING $5_000_000
    `;
    const ast = await parseOrThrow(source);
    const interpreter = new CreditLangInterpreter(ast);
    interpreter.loadFinancials({ net_income: 4000000 });

    interpreter.accumulateBuilderBasket('Builder', 'Q1 earnings');
    interpreter.useBasket('Builder', 3000000, 'Investment A');
    interpreter.accumulateBuilderBasket('Builder', 'Q2 earnings');
    interpreter.useBasket('Builder', 2000000, 'Investment B');

    const ledger = interpreter.getBasketLedger();
    expect(ledger.length).toBe(4);
    expect(ledger[0]!.entryType).toBe('accumulation');
    expect(ledger[1]!.entryType).toBe('usage');
    expect(ledger[2]!.entryType).toBe('accumulation');
    expect(ledger[3]!.entryType).toBe('usage');
  });

  it('should include timestamps in ledger entries', async () => {
    const source = `
      BASKET TestBasket CAPACITY $10_000_000
    `;
    const ast = await parseOrThrow(source);
    const interpreter = new CreditLangInterpreter(ast);

    const before = new Date();
    interpreter.useBasket('TestBasket', 1000000, 'Test');
    const after = new Date();

    const ledger = interpreter.getBasketLedger();
    expect(ledger[0]!.timestamp.getTime()).toBeGreaterThanOrEqual(before.getTime());
    expect(ledger[0]!.timestamp.getTime()).toBeLessThanOrEqual(after.getTime());
  });
});

// ==================== CURE RIGHTS TESTS ====================

describe('Cure Rights', () => {
  describe('Grammar', () => {
    it('should parse CURE clause with MAX_USES', async () => {
      const source = `
        COVENANT MaxLeverage
          REQUIRES Leverage <= 4.50
          TESTED QUARTERLY
          CURE EquityCure MAX_USES 3 OVER life_of_facility
      `;
      const ast = await parseOrThrow(source);
      const covenant = ast.statements.find(s => s.type === 'Covenant') as any;

      expect(covenant.cure).toBeDefined();
      expect(covenant.cure.type).toBe('EquityCure');
      expect(covenant.cure.details.maxUses).toBe(3);
      expect(covenant.cure.details.overPeriod).toBe('life_of_facility');
    });

    it('should parse CURE clause with MAX_AMOUNT', async () => {
      const source = `
        COVENANT MaxLeverage
          REQUIRES Leverage <= 4.50
          CURE EquityCure MAX_AMOUNT $20_000_000
      `;
      const ast = await parseOrThrow(source);
      const covenant = ast.statements.find(s => s.type === 'Covenant') as any;

      expect(covenant.cure.details.maxAmount).toBeDefined();
      expect(covenant.cure.details.maxAmount.value).toBe(20000000);
    });

    it('should parse CURE clause with CURE_PERIOD', async () => {
      const source = `
        COVENANT MaxLeverage
          REQUIRES Leverage <= 4.50
          CURE EquityCure CURE_PERIOD 30 DAYS
      `;
      const ast = await parseOrThrow(source);
      const covenant = ast.statements.find(s => s.type === 'Covenant') as any;

      expect(covenant.cure.details.curePeriod).toBeDefined();
      expect(covenant.cure.details.curePeriod.amount).toBe(30);
      expect(covenant.cure.details.curePeriod.unit).toBe('days');
    });

    it('should parse combined CURE clauses', async () => {
      const source = `
        COVENANT MaxLeverage
          REQUIRES Leverage <= 4.50
          CURE EquityCure MAX_USES 3 OVER life_of_facility MAX_AMOUNT $20_000_000
      `;
      const ast = await parseOrThrow(source);
      const covenant = ast.statements.find(s => s.type === 'Covenant') as any;

      expect(covenant.cure.details.maxUses).toBe(3);
      expect(covenant.cure.details.maxAmount.value).toBe(20000000);
    });

    it('should parse PaymentCure mechanism', async () => {
      const source = `
        COVENANT MinCoverage
          REQUIRES coverage >= 1.25
          CURE PaymentCure MAX_USES 2 OVER life_of_facility
      `;
      const ast = await parseOrThrow(source);
      const covenant = ast.statements.find(s => s.type === 'Covenant') as any;

      expect(covenant.cure.type).toBe('PaymentCure');
    });
  });

  describe('Interpreter', () => {
    it('should check cure availability when compliant', async () => {
      const source = `
        DEFINE Leverage AS total_debt / ebitda
        COVENANT MaxLeverage
          REQUIRES Leverage <= 4.50
          CURE EquityCure MAX_USES 3 OVER life_of_facility
      `;
      const ast = await parseOrThrow(source);
      const interpreter = new CreditLangInterpreter(ast);
      interpreter.loadFinancials({ total_debt: 90000000, ebitda: 30000000 }); // 3x leverage

      const result = interpreter.checkCovenantWithCure('MaxLeverage');
      expect(result.compliant).toBe(true);
      expect(result.cureAvailable).toBeUndefined(); // Not needed when compliant
    });

    it('should check cure availability when breached', async () => {
      const source = `
        DEFINE Leverage AS total_debt / ebitda
        COVENANT MaxLeverage
          REQUIRES Leverage <= 4.50
          CURE EquityCure MAX_USES 3 OVER life_of_facility
      `;
      const ast = await parseOrThrow(source);
      const interpreter = new CreditLangInterpreter(ast);
      interpreter.loadFinancials({ total_debt: 150000000, ebitda: 30000000 }); // 5x leverage

      const result = interpreter.checkCovenantWithCure('MaxLeverage');
      expect(result.compliant).toBe(false);
      expect(result.cureAvailable).toBe(true);
      expect(result.shortfall).toBeCloseTo(0.5, 1); // 5x - 4.5x = 0.5x shortfall
    });

    it('should apply equity cure successfully', async () => {
      const source = `
        DEFINE Leverage AS total_debt / ebitda
        COVENANT MaxLeverage
          REQUIRES Leverage <= 4.50
          CURE EquityCure MAX_USES 3 OVER life_of_facility
      `;
      const ast = await parseOrThrow(source);
      const interpreter = new CreditLangInterpreter(ast);
      interpreter.loadFinancials({ total_debt: 150000000, ebitda: 30000000 }); // 5x leverage

      const result = interpreter.applyCure('MaxLeverage', 10000000);
      expect(result.success).toBe(true);
    });

    it('should reject cure when uses exhausted', async () => {
      const source = `
        DEFINE Leverage AS total_debt / ebitda
        COVENANT MaxLeverage
          REQUIRES Leverage <= 4.50
          CURE EquityCure MAX_USES 2 OVER life_of_facility
      `;
      const ast = await parseOrThrow(source);
      const interpreter = new CreditLangInterpreter(ast);
      interpreter.loadFinancials({ total_debt: 150000000, ebitda: 30000000 });

      // Use both cures
      interpreter.applyCure('MaxLeverage', 10000000);
      interpreter.applyCure('MaxLeverage', 10000000);

      // Third should fail
      const result = interpreter.applyCure('MaxLeverage', 10000000);
      expect(result.success).toBe(false);
      expect(result.reason).toContain('No cure uses remaining');
    });

    it('should reject cure when amount exceeds max', async () => {
      const source = `
        DEFINE Leverage AS total_debt / ebitda
        COVENANT MaxLeverage
          REQUIRES Leverage <= 4.50
          CURE EquityCure MAX_AMOUNT $5_000_000
      `;
      const ast = await parseOrThrow(source);
      const interpreter = new CreditLangInterpreter(ast);
      interpreter.loadFinancials({ total_debt: 150000000, ebitda: 30000000 });

      const result = interpreter.applyCure('MaxLeverage', 10000000);
      expect(result.success).toBe(false);
      expect(result.reason).toContain('exceeds maximum cure');
    });

    it('should calculate shortfall for leverage covenant', async () => {
      const source = `
        DEFINE Leverage AS total_debt / ebitda
        COVENANT MaxLeverage
          REQUIRES Leverage <= 4.00
          CURE EquityCure
      `;
      const ast = await parseOrThrow(source);
      const interpreter = new CreditLangInterpreter(ast);
      interpreter.loadFinancials({ total_debt: 150000000, ebitda: 30000000 }); // 5x

      const result = interpreter.checkCovenantWithCure('MaxLeverage');
      expect(result.shortfall).toBeCloseTo(1.0, 1); // 5x - 4x = 1x shortfall
    });

    it('should calculate shortfall for coverage covenant', async () => {
      const source = `
        DEFINE Coverage AS ebitda / interest
        COVENANT MinCoverage
          REQUIRES Coverage >= 2.50
          CURE PaymentCure
      `;
      const ast = await parseOrThrow(source);
      const interpreter = new CreditLangInterpreter(ast);
      interpreter.loadFinancials({ ebitda: 20000000, interest: 10000000 }); // 2x

      const result = interpreter.checkCovenantWithCure('MinCoverage');
      expect(result.shortfall).toBeCloseTo(0.5, 1); // 2.5x - 2x = 0.5x shortfall
    });

    it('should track cure usage across multiple cures', async () => {
      const source = `
        DEFINE Leverage AS total_debt / ebitda
        COVENANT MaxLeverage
          REQUIRES Leverage <= 4.50
          CURE EquityCure MAX_USES 5 OVER life_of_facility
      `;
      const ast = await parseOrThrow(source);
      const interpreter = new CreditLangInterpreter(ast);
      interpreter.loadFinancials({ total_debt: 150000000, ebitda: 30000000 });

      interpreter.applyCure('MaxLeverage', 10000000);
      interpreter.applyCure('MaxLeverage', 10000000);

      const usage = interpreter.getCureUsage();
      expect(usage.length).toBe(1);
      expect(usage[0]!.mechanism).toBe('EquityCure');
      expect(usage[0]!.totalUses).toBe(2);
      expect(usage[0]!.usesRemaining).toBe(3);
    });

    it('should reject cure on compliant covenant', async () => {
      const source = `
        DEFINE Leverage AS total_debt / ebitda
        COVENANT MaxLeverage
          REQUIRES Leverage <= 4.50
          CURE EquityCure
      `;
      const ast = await parseOrThrow(source);
      const interpreter = new CreditLangInterpreter(ast);
      interpreter.loadFinancials({ total_debt: 90000000, ebitda: 30000000 }); // 3x

      const result = interpreter.applyCure('MaxLeverage', 10000000);
      expect(result.success).toBe(false);
      expect(result.reason).toContain('already compliant');
    });

    it('should identify covenants with cure mechanisms', async () => {
      const source = `
        COVENANT WithCure
          REQUIRES x <= 5
          CURE EquityCure

        COVENANT WithoutCure
          REQUIRES y >= 1
      `;
      const ast = await parseOrThrow(source);
      const interpreter = new CreditLangInterpreter(ast);

      const withCure = interpreter.getCovenantsWithCure();
      expect(withCure).toContain('WithCure');
      expect(withCure).not.toContain('WithoutCure');
    });
  });
});

// ==================== AMENDMENT TESTS ====================

describe('Amendments', () => {
  describe('Grammar', () => {
    it('should parse basic AMENDMENT statement', async () => {
      const source = `
        AMENDMENT 1
          EFFECTIVE 2024-06-15
          DESCRIPTION "First Amendment"

          ADDS BASKET NewBasket
            CAPACITY $10_000_000
      `;
      const ast = await parseOrThrow(source);
      const amendment = ast.statements.find(s => s.type === 'Amendment') as any;

      expect(amendment).toBeDefined();
      expect(amendment.number).toBe(1);
      expect(amendment.effective.value).toBe('2024-06-15');
      expect(amendment.description).toBe('First Amendment');
      expect(amendment.directives.length).toBe(1);
    });

    it('should parse REPLACES directive', async () => {
      const source = `
        AMENDMENT 1
          REPLACES COVENANT MaxLeverage WITH
            COVENANT MaxLeverage
              REQUIRES Leverage <= 5.00
              TESTED QUARTERLY
      `;
      const ast = await parseOrThrow(source);
      const amendment = ast.statements.find(s => s.type === 'Amendment') as any;

      expect(amendment.directives[0].directive).toBe('replace');
      expect(amendment.directives[0].targetType).toBe('Covenant');
      expect(amendment.directives[0].targetName).toBe('MaxLeverage');
      expect(amendment.directives[0].replacement.type).toBe('Covenant');
    });

    it('should parse ADDS directive', async () => {
      const source = `
        AMENDMENT 1
          ADDS BASKET AdditionalInvestments
            CAPACITY $15_000_000
      `;
      const ast = await parseOrThrow(source);
      const amendment = ast.statements.find(s => s.type === 'Amendment') as any;

      expect(amendment.directives[0].directive).toBe('add');
      expect(amendment.directives[0].statement.type).toBe('Basket');
      expect(amendment.directives[0].statement.name).toBe('AdditionalInvestments');
    });

    it('should parse DELETES directive', async () => {
      const source = `
        AMENDMENT 1
          DELETES CONDITION OldCondition
      `;
      const ast = await parseOrThrow(source);
      const amendment = ast.statements.find(s => s.type === 'Amendment') as any;

      expect(amendment.directives[0].directive).toBe('delete');
      expect(amendment.directives[0].targetType).toBe('Condition');
      expect(amendment.directives[0].targetName).toBe('OldCondition');
    });

    it('should parse MODIFIES directive', async () => {
      const source = `
        AMENDMENT 1
          MODIFIES BASKET GeneralInvestments
            CAPACITY $35_000_000
      `;
      const ast = await parseOrThrow(source);
      const amendment = ast.statements.find(s => s.type === 'Amendment') as any;

      expect(amendment.directives[0].directive).toBe('modify');
      expect(amendment.directives[0].targetType).toBe('Basket');
      expect(amendment.directives[0].targetName).toBe('GeneralInvestments');
      expect(amendment.directives[0].modifications[0].type).toBe('capacity');
    });

    it('should parse multiple directives in one amendment', async () => {
      const source = `
        AMENDMENT 2
          EFFECTIVE 2024-09-01

          MODIFIES BASKET GeneralInvestments
            CAPACITY $40_000_000

          ADDS BASKET NewBasket
            CAPACITY $5_000_000

          DELETES CONDITION OldCondition
      `;
      const ast = await parseOrThrow(source);
      const amendment = ast.statements.find(s => s.type === 'Amendment') as any;

      expect(amendment.number).toBe(2);
      expect(amendment.directives.length).toBe(3);
      expect(amendment.directives[0].directive).toBe('modify');
      expect(amendment.directives[1].directive).toBe('add');
      expect(amendment.directives[2].directive).toBe('delete');
    });
  });

  describe('Interpreter', () => {
    it('should apply REPLACES directive', async () => {
      const source = `
        DEFINE Leverage AS total_debt / ebitda

        COVENANT MaxLeverage
          REQUIRES Leverage <= 4.50
          TESTED QUARTERLY
      `;
      const amendmentSource = `
        AMENDMENT 1
          REPLACES COVENANT MaxLeverage WITH
            COVENANT MaxLeverage
              REQUIRES Leverage <= 5.00
              TESTED QUARTERLY
      `;

      const ast = await parseOrThrow(source);
      const amendmentAst = await parseOrThrow(amendmentSource);
      const interpreter = new CreditLangInterpreter(ast);
      interpreter.loadFinancials({ total_debt: 230000000, ebitda: 50000000 }); // 4.6x leverage

      // Before amendment: breach (4.6x > 4.5x)
      let result = interpreter.checkCovenant('MaxLeverage');
      expect(result.compliant).toBe(false);

      // Apply amendment
      const amendment = amendmentAst.statements.find(s => s.type === 'Amendment') as any;
      interpreter.applyAmendment(amendment);

      // After amendment: compliant (4.6x <= 5.0x)
      result = interpreter.checkCovenant('MaxLeverage');
      expect(result.compliant).toBe(true);
      expect(result.threshold).toBe(5.0);
    });

    it('should apply ADDS directive', async () => {
      const source = `
        BASKET ExistingBasket
          CAPACITY $10_000_000
      `;
      const amendmentSource = `
        AMENDMENT 1
          ADDS BASKET NewBasket
            CAPACITY $15_000_000
      `;

      const ast = await parseOrThrow(source);
      const amendmentAst = await parseOrThrow(amendmentSource);
      const interpreter = new CreditLangInterpreter(ast);

      // Before amendment
      expect(interpreter.getBasketNames()).toContain('ExistingBasket');
      expect(interpreter.getBasketNames()).not.toContain('NewBasket');

      // Apply amendment
      const amendment = amendmentAst.statements.find(s => s.type === 'Amendment') as any;
      interpreter.applyAmendment(amendment);

      // After amendment
      expect(interpreter.getBasketNames()).toContain('NewBasket');
      expect(interpreter.getBasketCapacity('NewBasket')).toBe(15000000);
    });

    it('should apply DELETES directive', async () => {
      const source = `
        CONDITION OldCondition AS
          x > 0

        CONDITION KeepThis AS
          y > 0
      `;
      const amendmentSource = `
        AMENDMENT 1
          DELETES CONDITION OldCondition
      `;

      const ast = await parseOrThrow(source);
      const amendmentAst = await parseOrThrow(amendmentSource);
      const interpreter = new CreditLangInterpreter(ast);

      // Before
      expect(interpreter.getConditionNames()).toContain('OldCondition');
      expect(interpreter.getConditionNames()).toContain('KeepThis');

      // Apply
      const amendment = amendmentAst.statements.find(s => s.type === 'Amendment') as any;
      interpreter.applyAmendment(amendment);

      // After
      expect(interpreter.getConditionNames()).not.toContain('OldCondition');
      expect(interpreter.getConditionNames()).toContain('KeepThis');
    });

    it('should throw error on deleting non-existent statement', async () => {
      const source = `
        BASKET SomeBasket CAPACITY $10_000_000
      `;
      const amendmentSource = `
        AMENDMENT 1
          DELETES CONDITION NonExistent
      `;

      const ast = await parseOrThrow(source);
      const amendmentAst = await parseOrThrow(amendmentSource);
      const interpreter = new CreditLangInterpreter(ast);

      const amendment = amendmentAst.statements.find(s => s.type === 'Amendment') as any;
      expect(() => interpreter.applyAmendment(amendment)).toThrow(/not found/);
    });

    it('should apply MODIFIES directive to basket capacity', async () => {
      const source = `
        BASKET GeneralInvestments
          CAPACITY $25_000_000
      `;
      const amendmentSource = `
        AMENDMENT 1
          MODIFIES BASKET GeneralInvestments
            CAPACITY $35_000_000
      `;

      const ast = await parseOrThrow(source);
      const amendmentAst = await parseOrThrow(amendmentSource);
      const interpreter = new CreditLangInterpreter(ast);

      // Before
      expect(interpreter.getBasketCapacity('GeneralInvestments')).toBe(25000000);

      // Apply
      const amendment = amendmentAst.statements.find(s => s.type === 'Amendment') as any;
      interpreter.applyAmendment(amendment);

      // After
      expect(interpreter.getBasketCapacity('GeneralInvestments')).toBe(35000000);
    });

    it('should apply multiple amendments in order', async () => {
      const source = `
        BASKET TestBasket CAPACITY $10_000_000
      `;
      const amendment1Source = `
        AMENDMENT 1
          MODIFIES BASKET TestBasket
            CAPACITY $20_000_000
      `;
      const amendment2Source = `
        AMENDMENT 2
          MODIFIES BASKET TestBasket
            CAPACITY $30_000_000
      `;

      const ast = await parseOrThrow(source);
      const amendment1Ast = await parseOrThrow(amendment1Source);
      const amendment2Ast = await parseOrThrow(amendment2Source);
      const interpreter = new CreditLangInterpreter(ast);

      expect(interpreter.getBasketCapacity('TestBasket')).toBe(10000000);

      const amendment1 = amendment1Ast.statements.find(s => s.type === 'Amendment') as any;
      interpreter.applyAmendment(amendment1);
      expect(interpreter.getBasketCapacity('TestBasket')).toBe(20000000);

      const amendment2 = amendment2Ast.statements.find(s => s.type === 'Amendment') as any;
      interpreter.applyAmendment(amendment2);
      expect(interpreter.getBasketCapacity('TestBasket')).toBe(30000000);
    });

    it('should track applied amendments', async () => {
      const source = `
        BASKET TestBasket CAPACITY $10_000_000
      `;
      const amendmentSource = `
        AMENDMENT 1
          EFFECTIVE 2024-06-15
          DESCRIPTION "Capacity increase"
          MODIFIES BASKET TestBasket
            CAPACITY $20_000_000
      `;

      const ast = await parseOrThrow(source);
      const amendmentAst = await parseOrThrow(amendmentSource);
      const interpreter = new CreditLangInterpreter(ast);

      expect(interpreter.getAppliedAmendments().length).toBe(0);

      const amendment = amendmentAst.statements.find(s => s.type === 'Amendment') as any;
      interpreter.applyAmendment(amendment);

      const applied = interpreter.getAppliedAmendments();
      expect(applied.length).toBe(1);
      expect(applied[0].number).toBe(1);
      expect(applied[0].description).toBe('Capacity increase');
    });

    it('should throw error on replacing non-existent statement', async () => {
      const source = `
        BASKET SomeBasket CAPACITY $10_000_000
      `;
      const amendmentSource = `
        AMENDMENT 1
          REPLACES COVENANT NonExistent WITH
            COVENANT NonExistent
              REQUIRES x <= 5
      `;

      const ast = await parseOrThrow(source);
      const amendmentAst = await parseOrThrow(amendmentSource);
      const interpreter = new CreditLangInterpreter(ast);

      const amendment = amendmentAst.statements.find(s => s.type === 'Amendment') as any;
      expect(() => interpreter.applyAmendment(amendment)).toThrow(/not found/);
    });
  });
});

// ==================== CLOSING ENUMS TESTS ====================

import {
  TransactionType,
  DocumentType,
  DocumentStatus,
  PartyRole,
  ConditionStatus,
  DefinedTermCategory,
  DocumentCategory,
  isTransactionType,
  isDocumentType,
  isDocumentStatus,
  isPartyRole,
  isConditionStatus,
  getTransactionTypeLabel,
  getDocumentStatusLabel,
  getPartyRoleLabel,
  getConditionStatusLabel,
} from '../src/closing-enums.js';

describe('Closing Enums', () => {
  describe('TransactionType', () => {
    it('should have all expected transaction types', () => {
      expect(TransactionType.REVOLVING_CREDIT).toBe('revolving_credit');
      expect(TransactionType.TERM_LOAN_A).toBe('term_loan_a');
      expect(TransactionType.TERM_LOAN_B).toBe('term_loan_b');
      expect(TransactionType.DELAYED_DRAW).toBe('delayed_draw');
      expect(TransactionType.BRIDGE_LOAN).toBe('bridge_loan');
      expect(TransactionType.ABL).toBe('asset_based_loan');
      expect(TransactionType.MULTI_TRANCHE).toBe('multi_tranche');
    });

    it('should validate transaction types', () => {
      expect(isTransactionType('revolving_credit')).toBe(true);
      expect(isTransactionType('term_loan_a')).toBe(true);
      expect(isTransactionType('invalid_type')).toBe(false);
    });

    it('should provide human-readable labels', () => {
      expect(getTransactionTypeLabel(TransactionType.REVOLVING_CREDIT)).toBe('Revolving Credit');
      expect(getTransactionTypeLabel(TransactionType.ABL)).toBe('Asset-Based Loan');
    });
  });

  describe('DocumentType', () => {
    it('should have core agreement documents', () => {
      expect(DocumentType.CREDIT_AGREEMENT).toBe('credit_agreement');
      expect(DocumentType.AMENDMENT).toBe('amendment');
      expect(DocumentType.WAIVER).toBe('waiver');
    });

    it('should have corporate documents', () => {
      expect(DocumentType.OFFICERS_CERTIFICATE).toBe('officers_certificate');
      expect(DocumentType.SECRETARY_CERTIFICATE).toBe('secretary_certificate');
      expect(DocumentType.GOOD_STANDING).toBe('good_standing');
    });

    it('should have security documents', () => {
      expect(DocumentType.SECURITY_AGREEMENT).toBe('security_agreement');
      expect(DocumentType.PLEDGE_AGREEMENT).toBe('pledge_agreement');
      expect(DocumentType.GUARANTY).toBe('guaranty');
    });

    it('should validate document types', () => {
      expect(isDocumentType('credit_agreement')).toBe(true);
      expect(isDocumentType('legal_opinion')).toBe(true);
      expect(isDocumentType('fake_document')).toBe(false);
    });
  });

  describe('DocumentStatus', () => {
    it('should have all lifecycle statuses', () => {
      expect(DocumentStatus.NOT_STARTED).toBe('not_started');
      expect(DocumentStatus.DRAFTING).toBe('drafting');
      expect(DocumentStatus.FINAL).toBe('final');
      expect(DocumentStatus.EXECUTED).toBe('executed');
    });

    it('should validate document statuses', () => {
      expect(isDocumentStatus('drafting')).toBe(true);
      expect(isDocumentStatus('executed')).toBe(true);
      expect(isDocumentStatus('invalid_status')).toBe(false);
    });

    it('should provide human-readable labels', () => {
      expect(getDocumentStatusLabel(DocumentStatus.NOT_STARTED)).toBe('Not Started');
      expect(getDocumentStatusLabel(DocumentStatus.OUT_FOR_REVIEW)).toBe('Out for Review');
    });
  });

  describe('PartyRole', () => {
    it('should have all party roles', () => {
      expect(PartyRole.BORROWER).toBe('borrower');
      expect(PartyRole.ADMINISTRATIVE_AGENT).toBe('administrative_agent');
      expect(PartyRole.LENDER).toBe('lender');
    });

    it('should validate party roles', () => {
      expect(isPartyRole('borrower')).toBe(true);
      expect(isPartyRole('lender')).toBe(true);
      expect(isPartyRole('fake_role')).toBe(false);
    });

    it('should provide human-readable labels', () => {
      expect(getPartyRoleLabel(PartyRole.ADMINISTRATIVE_AGENT)).toBe('Administrative Agent');
      expect(getPartyRoleLabel(PartyRole.SWINGLINE_LENDER)).toBe('Swingline Lender');
    });
  });

  describe('ConditionStatus', () => {
    it('should have all condition statuses', () => {
      expect(ConditionStatus.PENDING).toBe('pending');
      expect(ConditionStatus.SATISFIED).toBe('satisfied');
      expect(ConditionStatus.WAIVED).toBe('waived');
    });

    it('should validate condition statuses', () => {
      expect(isConditionStatus('satisfied')).toBe(true);
      expect(isConditionStatus('waived')).toBe(true);
      expect(isConditionStatus('invalid')).toBe(false);
    });

    it('should provide human-readable labels', () => {
      expect(getConditionStatusLabel(ConditionStatus.IN_PROGRESS)).toBe('In Progress');
      expect(getConditionStatusLabel(ConditionStatus.NOT_APPLICABLE)).toBe('N/A');
    });
  });

  describe('DefinedTermCategory', () => {
    it('should have all term categories', () => {
      expect(DefinedTermCategory.PARTY).toBe('party');
      expect(DefinedTermCategory.DOCUMENT).toBe('document');
      expect(DefinedTermCategory.FACILITY).toBe('facility');
      expect(DefinedTermCategory.COLLATERAL).toBe('collateral');
      expect(DefinedTermCategory.GENERAL).toBe('general');
    });
  });

  describe('DocumentCategory', () => {
    it('should have all document categories', () => {
      expect(DocumentCategory.CORE_AGREEMENT).toBe('Core Agreement');
      expect(DocumentCategory.CORPORATE_DOCUMENTS).toBe('Corporate Documents');
      expect(DocumentCategory.SECURITY_DOCUMENTS).toBe('Security Documents');
      expect(DocumentCategory.LEGAL_OPINIONS).toBe('Legal Opinions');
    });
  });
});

// ==================== ONTOLOGY TESTS ====================

import {
  loadBuiltinOntology,
  validateOntology,
  getDocumentsByCategory,
  getConditionBySection,
  getDocumentCategories,
  getConditionCategories,
  getDocumentByKey,
  type OntologyConfig,
} from '../src/ontology.js';

describe('Ontology System', () => {
  let ontology: OntologyConfig;

  beforeEach(() => {
    ontology = loadBuiltinOntology('credit-agreement-v1');
  });

  describe('Loading', () => {
    it('should load built-in credit-agreement-v1 ontology', () => {
      expect(ontology.name).toBe('credit-agreement-v1');
      expect(ontology.version).toBe('1.0.0');
    });

    it('should have document templates', () => {
      expect(ontology.documentTemplates.length).toBeGreaterThan(0);
    });

    it('should have condition templates', () => {
      expect(ontology.conditionTemplates.length).toBeGreaterThan(0);
    });

    it('should have covenant templates', () => {
      expect(ontology.covenantTemplates).toBeDefined();
      expect(ontology.covenantTemplates!.length).toBeGreaterThan(0);
    });

    it('should have basket templates', () => {
      expect(ontology.basketTemplates).toBeDefined();
      expect(ontology.basketTemplates!.length).toBeGreaterThan(0);
    });
  });

  describe('Document Templates', () => {
    it('should have credit agreement template', () => {
      const creditAgreement = getDocumentByKey(ontology, 'credit_agreement');
      expect(creditAgreement).toBeDefined();
      expect(creditAgreement!.documentType).toBe('credit_agreement');
      expect(creditAgreement!.category).toBe('Core Agreement');
    });

    it('should have officers certificate template', () => {
      const cert = getDocumentByKey(ontology, 'officers_certificate');
      expect(cert).toBeDefined();
      expect(cert!.defaultResponsibleRole).toBe('borrower');
    });

    it('should get documents by category', () => {
      const corporateDocs = getDocumentsByCategory(ontology, 'Corporate Documents');
      expect(corporateDocs.length).toBeGreaterThan(0);
      expect(corporateDocs.every(d => d.category === 'Corporate Documents')).toBe(true);
    });

    it('should get all document categories', () => {
      const categories = getDocumentCategories(ontology);
      expect(categories).toContain('Core Agreement');
      expect(categories).toContain('Corporate Documents');
      expect(categories).toContain('Security Documents');
    });
  });

  describe('Condition Templates', () => {
    it('should have corporate documents condition', () => {
      const condition = getConditionBySection(ontology, '4.01(a)');
      expect(condition).toBeDefined();
      expect(condition!.title).toBe('Corporate Documents');
    });

    it('should have expected document keys', () => {
      const condition = getConditionBySection(ontology, '4.01(a)');
      expect(condition!.expectedDocumentKeys).toContain('officers_certificate');
      expect(condition!.expectedDocumentKeys).toContain('secretary_certificate');
    });

    it('should get all condition categories', () => {
      const categories = getConditionCategories(ontology);
      expect(categories).toContain('Corporate Documents');
      expect(categories).toContain('Security Documents');
      expect(categories).toContain('Legal Opinions');
    });
  });

  describe('Validation', () => {
    it('should validate ontology with no errors', () => {
      const errors = validateOntology(ontology);
      expect(errors.length).toBe(0);
    });

    it('should detect invalid document references', () => {
      const invalidOntology: OntologyConfig = {
        name: 'test',
        documentTemplates: [],
        conditionTemplates: [{
          sectionReference: '1.01',
          title: 'Test',
          description: 'Test',
          category: 'Test',
          expectedDocumentKeys: ['nonexistent_doc'],
        }],
      };

      const errors = validateOntology(invalidOntology);
      expect(errors.length).toBe(1);
      expect(errors[0]).toContain('nonexistent_doc');
    });
  });

  describe('Covenant Templates', () => {
    it('should have total leverage template', () => {
      const totalLeverage = ontology.covenantTemplates!.find(c => c.key === 'total_leverage');
      expect(totalLeverage).toBeDefined();
      expect(totalLeverage!.metric).toBe('TotalLeverage');
      expect(totalLeverage!.defaultOperator).toBe('<=');
    });

    it('should have common thresholds by transaction type', () => {
      const totalLeverage = ontology.covenantTemplates!.find(c => c.key === 'total_leverage');
      expect(totalLeverage!.commonThresholds).toBeDefined();
      expect(totalLeverage!.commonThresholds!.leveraged).toBe(5.0);
    });
  });

  describe('Basket Templates', () => {
    it('should have general investment basket template', () => {
      const basket = ontology.basketTemplates!.find(b => b.key === 'general_investment');
      expect(basket).toBeDefined();
      expect(basket!.basketType).toBe('grower');
    });

    it('should have common capacities', () => {
      const basket = ontology.basketTemplates!.find(b => b.key === 'general_investment');
      expect(basket!.commonCapacities).toBeDefined();
      expect(basket!.commonCapacities!.leveraged).toContain('GreaterOf');
    });
  });
});

// ==================== DEFINED TERMS TESTS ====================

import {
  parseDefinedTerm,
  parseDefinedTerms,
  loadDefinedTermsFromJson,
  createTermsRegistry,
  findTerm,
  findTermsByCategory,
  findReferencingTerms,
  buildCrossReferenceGraph,
  findCircularReferences,
  validateCrossReferences,
  findDuplicateTerms,
  isCalculableTerm,
  extractPotentialIdentifiers,
  type DefinedTerm,
  type DefinedTermsRegistry,
} from '../src/defined-terms.js';

describe('Defined Terms System', () => {
  const sampleTerms: DefinedTerm[] = [
    {
      term: 'EBITDA',
      definition: 'means Net Income plus Interest Expense plus Tax Expense plus Depreciation and Amortization',
      source: 'credit_agreement',
      sectionReference: 'Section 1.01',
      category: 'financial',
      crossReferences: ['Net Income', 'Interest Expense', 'Tax Expense'],
    },
    {
      term: 'Net Income',
      definition: 'means the net income of the Borrower and its Subsidiaries determined in accordance with GAAP',
      source: 'credit_agreement',
      sectionReference: 'Section 1.01',
      category: 'financial',
      crossReferences: ['Borrower', 'GAAP'],
    },
    {
      term: 'Borrower',
      definition: 'ABC Corporation, a Delaware corporation',
      source: 'credit_agreement',
      sectionReference: 'Section 1.01',
      category: 'party',
      crossReferences: [],
    },
  ];

  describe('Parsing', () => {
    it('should parse a raw defined term', () => {
      const raw = {
        term: 'Test',
        definition: 'Test definition',
        source: 'test_source',
        section_reference: 'Section 1.01',
        category: 'general',
        cross_references: ['Other Term'],
        notes: 'Test notes',
      };

      const parsed = parseDefinedTerm(raw);
      expect(parsed.term).toBe('Test');
      expect(parsed.sectionReference).toBe('Section 1.01');
      expect(parsed.crossReferences).toContain('Other Term');
      expect(parsed.notes).toBe('Test notes');
    });

    it('should parse multiple raw terms', () => {
      const rawTerms = [
        { term: 'A', definition: 'A def', source: 's', section_reference: '1', category: 'g', cross_references: [] },
        { term: 'B', definition: 'B def', source: 's', section_reference: '2', category: 'g', cross_references: [] },
      ];

      const parsed = parseDefinedTerms(rawTerms);
      expect(parsed.length).toBe(2);
      expect(parsed[0]!.term).toBe('A');
      expect(parsed[1]!.term).toBe('B');
    });

    it('should load terms from JSON string', () => {
      const json = JSON.stringify([
        { term: 'Test', definition: 'Def', source: 's', section_reference: '1', category: 'g', cross_references: [] }
      ]);

      const terms = loadDefinedTermsFromJson(json);
      expect(terms.length).toBe(1);
      expect(terms[0]!.term).toBe('Test');
    });
  });

  describe('Registry', () => {
    let registry: DefinedTermsRegistry;

    beforeEach(() => {
      registry = createTermsRegistry(sampleTerms, 'test_agreement', '1.0');
    });

    it('should create a registry from terms', () => {
      expect(registry.source).toBe('test_agreement');
      expect(registry.version).toBe('1.0');
      expect(registry.terms.length).toBe(3);
      expect(registry.lastUpdated).toBeDefined();
    });

    it('should find term by name', () => {
      const term = findTerm(registry, 'EBITDA');
      expect(term).toBeDefined();
      expect(term!.definition).toContain('Net Income');
    });

    it('should find term case-insensitively', () => {
      const term = findTerm(registry, 'ebitda');
      expect(term).toBeDefined();
      expect(term!.term).toBe('EBITDA');
    });

    it('should find terms by category', () => {
      const financialTerms = findTermsByCategory(registry, 'financial');
      expect(financialTerms.length).toBe(2);
      expect(financialTerms.every(t => t.category === 'financial')).toBe(true);
    });

    it('should find referencing terms', () => {
      const referencingTerms = findReferencingTerms(registry, 'Net Income');
      expect(referencingTerms.length).toBe(1);
      expect(referencingTerms[0]!.term).toBe('EBITDA');
    });
  });

  describe('Cross-Reference Analysis', () => {
    let registry: DefinedTermsRegistry;

    beforeEach(() => {
      registry = createTermsRegistry(sampleTerms, 'test', '1.0');
    });

    it('should build cross-reference graph', () => {
      const graph = buildCrossReferenceGraph(registry);
      expect(graph.length).toBeGreaterThan(0);

      const ebitdaRefs = graph.filter(r => r.fromTerm === 'EBITDA');
      expect(ebitdaRefs.length).toBe(3);
    });

    it('should detect circular references', () => {
      const circularTerms: DefinedTerm[] = [
        { term: 'A', definition: 'refs B', source: 's', sectionReference: '1', category: 'g', crossReferences: ['B'] },
        { term: 'B', definition: 'refs C', source: 's', sectionReference: '2', category: 'g', crossReferences: ['C'] },
        { term: 'C', definition: 'refs A', source: 's', sectionReference: '3', category: 'g', crossReferences: ['A'] },
      ];
      const circularRegistry = createTermsRegistry(circularTerms, 'test', '1.0');

      const cycles = findCircularReferences(circularRegistry);
      expect(cycles.length).toBeGreaterThan(0);
    });

    it('should not detect cycles where none exist', () => {
      const cycles = findCircularReferences(registry);
      expect(cycles.length).toBe(0);
    });
  });

  describe('Validation', () => {
    it('should validate cross-references', () => {
      const invalidTerms: DefinedTerm[] = [
        { term: 'Test', definition: 'refs undefined', source: 's', sectionReference: '1', category: 'g', crossReferences: ['UndefinedTerm'] },
      ];
      const registry = createTermsRegistry(invalidTerms, 'test', '1.0');

      const errors = validateCrossReferences(registry);
      expect(errors.length).toBe(1);
      expect(errors[0]).toContain('UndefinedTerm');
    });

    it('should detect duplicate terms', () => {
      const duplicateTerms: DefinedTerm[] = [
        { term: 'Test', definition: 'def 1', source: 's', sectionReference: '1', category: 'g', crossReferences: [] },
        { term: 'TEST', definition: 'def 2', source: 's', sectionReference: '2', category: 'g', crossReferences: [] },
      ];
      const registry = createTermsRegistry(duplicateTerms, 'test', '1.0');

      const duplicates = findDuplicateTerms(registry);
      expect(duplicates.length).toBe(1);
    });
  });

  describe('CreditLang Integration', () => {
    it('should identify calculable terms by category', () => {
      const financialTerm: DefinedTerm = {
        term: 'EBITDA',
        definition: 'calculated value',
        source: 's',
        sectionReference: '1',
        category: 'financial',
        crossReferences: [],
      };

      expect(isCalculableTerm(financialTerm)).toBe(true);
    });

    it('should identify calculable terms by definition keywords', () => {
      const calculableTerm: DefinedTerm = {
        term: 'Leverage',
        definition: 'means the ratio of Total Debt divided by EBITDA',
        source: 's',
        sectionReference: '1',
        category: 'general',
        crossReferences: [],
      };

      expect(isCalculableTerm(calculableTerm)).toBe(true);
    });

    it('should not identify non-calculable terms', () => {
      const partyTerm: DefinedTerm = {
        term: 'Borrower',
        definition: 'ABC Corporation, a Delaware corporation',
        source: 's',
        sectionReference: '1',
        category: 'party',
        crossReferences: [],
      };

      expect(isCalculableTerm(partyTerm)).toBe(false);
    });

    it('should extract potential identifiers from definition', () => {
      const term: DefinedTerm = {
        term: 'EBITDA',
        definition: 'means Net Income plus Interest Expense',
        source: 's',
        sectionReference: '1',
        category: 'financial',
        crossReferences: ['Net Income', 'Interest Expense'],
      };

      const identifiers = extractPotentialIdentifiers(term);
      expect(identifiers).toContain('Net Income');
      expect(identifiers).toContain('Interest Expense');
    });
  });
});
