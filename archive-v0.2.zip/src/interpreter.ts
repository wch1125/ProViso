// CreditLang Interpreter
// Evaluates parsed AST against financial data

import {
  Program,
  Statement,
  Expression,
  DefineStatement,
  CovenantStatement,
  BasketStatement,
  ConditionStatement,
  ProhibitStatement,
  EventStatement,
  AmendmentStatement,
  AmendmentDirective,
  ModificationClause,
  FinancialData,
  CovenantResult,
  CovenantResultWithCure,
  BasketStatus,
  BasketLedgerEntry,
  QueryResult,
  ReasoningStep,
  SimulationResult,
  StatusReport,
  CureState,
  CureUsage,
  CureResult,
  isObjectExpression,
  isComparisonExpression,
  isFunctionCallExpression,
} from './types.js';

export class CreditLangInterpreter {
  private definitions: Map<string, DefineStatement> = new Map();
  private covenants: Map<string, CovenantStatement> = new Map();
  private baskets: Map<string, BasketStatement> = new Map();
  private conditions: Map<string, ConditionStatement> = new Map();
  private prohibitions: Map<string, ProhibitStatement> = new Map();
  private events: Map<string, EventStatement> = new Map();

  private financialData: FinancialData = {};
  private basketLedger: BasketLedgerEntry[] = [];
  private basketUtilization: Map<string, number> = new Map();
  // Accumulated capacity for builder baskets
  private basketAccumulation: Map<string, number> = new Map();

  private eventDefaults: Set<string> = new Set();

  // Amendment tracking
  private appliedAmendments: AmendmentStatement[] = [];

  // Cure rights tracking
  private cureStates: Map<string, CureState> = new Map();
  private cureUsage: Map<string, number> = new Map(); // mechanism type -> total uses

  // Evaluation context for temporary bindings (e.g., 'amount' in prohibition checks)
  private evaluationContext: { bindings?: Record<string, number> } = {};

  constructor(private ast: Program) {
    this.loadStatements();
  }

  private loadStatements(): void {
    for (const stmt of this.ast.statements) {
      this.loadStatement(stmt);
    }
  }

  private loadStatement(stmt: Statement): void {
    switch (stmt.type) {
      case 'Define':
        this.definitions.set(stmt.name, stmt);
        break;
      case 'Covenant':
        this.covenants.set(stmt.name, stmt);
        break;
      case 'Basket':
        this.baskets.set(stmt.name, stmt);
        if (!this.basketUtilization.has(stmt.name)) {
          this.basketUtilization.set(stmt.name, 0);
        }
        break;
      case 'Condition':
        this.conditions.set(stmt.name, stmt);
        break;
      case 'Prohibit':
        this.prohibitions.set(stmt.target, stmt);
        break;
      case 'Event':
        this.events.set(stmt.name, stmt);
        break;
      case 'Amendment':
        // Amendments are processed separately via applyAmendment
        break;
      case 'Load':
        if (stmt.source.type === 'inline' && stmt.source.data) {
          this.loadFinancials(stmt.source.data as FinancialData);
        }
        break;
    }
  }

  loadFinancials(data: FinancialData): void {
    this.financialData = { ...this.financialData, ...data };
  }

  loadFinancialsFromFile(data: Record<string, unknown>): void {
    // Flatten nested structures if needed
    if (data.financials && typeof data.financials === 'object') {
      this.financialData = { ...this.financialData, ...(data.financials as FinancialData) };
    }
    if (data.adjustments && typeof data.adjustments === 'object') {
      this.financialData = { ...this.financialData, ...(data.adjustments as FinancialData) };
    }
    // Also load top-level values
    for (const [key, value] of Object.entries(data)) {
      if (typeof value === 'number') {
        this.financialData[key] = value;
      }
    }
  }

  // ==================== EXPRESSION EVALUATION ====================

  evaluate(expr: Expression): number {
    if (typeof expr === 'string') {
      // It's an identifier
      return this.resolveIdentifier(expr);
    }

    if (typeof expr === 'number') {
      return expr;
    }

    if (!isObjectExpression(expr)) {
      throw new Error(`Cannot evaluate expression: ${JSON.stringify(expr)}`);
    }

    switch (expr.type) {
      case 'Number':
        return expr.value;

      case 'Currency':
        return expr.value;

      case 'Percentage':
        return expr.value / 100;

      case 'Ratio':
        return expr.value;

      case 'BinaryExpression': {
        const left = this.evaluate(expr.left);
        const right = this.evaluate(expr.right);
        switch (expr.operator) {
          case '+': return left + right;
          case '-': return left - right;
          case '*': return left * right;
          case '/': return right !== 0 ? left / right : Infinity;
          default:
            throw new Error(`Unknown operator: ${expr.operator}`);
        }
      }

      case 'UnaryExpression':
        if (expr.operator === '-') {
          return -this.evaluate(expr.argument);
        }
        throw new Error(`Unknown unary operator: ${expr.operator}`);

      case 'FunctionCall':
        return this.evaluateFunction(expr.name, expr.arguments);

      case 'Comparison':
        throw new Error('Comparison expressions should be evaluated with evaluateBoolean');
    }
  }

  private resolveIdentifier(name: string): number {
    // Check evaluation context first (for temporary bindings like 'amount')
    if (this.evaluationContext.bindings && name in this.evaluationContext.bindings) {
      return this.evaluationContext.bindings[name]!;
    }

    // Check definitions
    const def = this.definitions.get(name);
    if (def) {
      return this.evaluateDefinition(def);
    }

    // Check financial data
    if (name in this.financialData) {
      return this.financialData[name]!;
    }

    // Common aliases
    const aliases: Record<string, string> = {
      'EBITDA': 'ebitda',
      'TotalDebt': 'total_debt',
      'InterestExpense': 'interest_expense',
      'NetIncome': 'net_income',
      'TotalAssets': 'total_assets',
    };

    const aliasedName = aliases[name];
    if (aliasedName && aliasedName in this.financialData) {
      return this.financialData[aliasedName]!;
    }

    throw new Error(`Undefined identifier: ${name}`);
  }

  private evaluateDefinition(def: DefineStatement): number {
    let value = this.evaluate(def.expression);

    // Apply modifiers
    if (def.modifiers.excluding) {
      for (const item of def.modifiers.excluding) {
        if (item in this.financialData) {
          value -= this.financialData[item]!;
        }
      }
    }

    if (def.modifiers.cap) {
      const cap = this.evaluate(def.modifiers.cap);
      value = Math.min(value, cap);
    }

    return value;
  }

  private evaluateFunction(name: string, args: Expression[]): number {
    switch (name) {
      case 'AVAILABLE':
        if (args.length !== 1 || typeof args[0] !== 'string') {
          throw new Error('AVAILABLE requires a basket name');
        }
        return this.getBasketAvailable(args[0]);

      case 'GreaterOf':
        if (args.length !== 2) {
          throw new Error('GreaterOf requires two arguments');
        }
        return Math.max(this.evaluate(args[0]!), this.evaluate(args[1]!));

      case 'LesserOf':
        if (args.length !== 2) {
          throw new Error('LesserOf requires two arguments');
        }
        return Math.min(this.evaluate(args[0]!), this.evaluate(args[1]!));

      case 'COMPLIANT':
        if (args.length !== 1 || typeof args[0] !== 'string') {
          throw new Error('COMPLIANT requires a covenant name');
        }
        return this.checkCovenant(args[0]).compliant ? 1 : 0;

      case 'EXISTS':
        if (args.length !== 1 || typeof args[0] !== 'string') {
          throw new Error('EXISTS requires an identifier');
        }
        // Check if an event/default exists
        return this.eventDefaults.has(args[0]) ? 1 : 0;

      case 'NOT':
        if (args.length !== 1) {
          throw new Error('NOT requires one argument');
        }
        return this.evaluateBoolean(args[0]!) ? 0 : 1;

      default:
        throw new Error(`Unknown function: ${name}`);
    }
  }

  // ==================== BOOLEAN EVALUATION ====================

  evaluateBoolean(expr: Expression): boolean {
    if (typeof expr === 'string') {
      // Check conditions
      const cond = this.conditions.get(expr);
      if (cond) {
        return this.evaluateBoolean(cond.expression);
      }
      // Check if identifier resolves to truthy value
      try {
        return this.resolveIdentifier(expr) !== 0;
      } catch {
        return false;
      }
    }

    if (!isObjectExpression(expr)) {
      return Boolean(expr);
    }

    switch (expr.type) {
      case 'Comparison': {
        const left = this.evaluate(expr.left);
        const right = this.evaluate(expr.right);
        switch (expr.operator) {
          case '<=': return left <= right;
          case '>=': return left >= right;
          case '<': return left < right;
          case '>': return left > right;
          case '=': return left === right;
          case '!=': return left !== right;
          default: return false;
        }
      }

      case 'BinaryExpression':
        if (expr.operator === 'AND') {
          return this.evaluateBoolean(expr.left) && this.evaluateBoolean(expr.right);
        }
        if (expr.operator === 'OR') {
          return this.evaluateBoolean(expr.left) || this.evaluateBoolean(expr.right);
        }
        // Numeric binary expression - evaluate as truthy
        return this.evaluate(expr) !== 0;

      case 'UnaryExpression':
        if (expr.operator === 'NOT') {
          return !this.evaluateBoolean(expr.argument);
        }
        return this.evaluate(expr) !== 0;

      case 'FunctionCall':
        return this.evaluate(expr) !== 0;

      default:
        return this.evaluate(expr) !== 0;
    }
  }

  // ==================== COVENANT CHECKING ====================

  checkCovenant(name: string): CovenantResult {
    const covenant = this.covenants.get(name);
    if (!covenant) {
      throw new Error(`Unknown covenant: ${name}`);
    }

    if (!covenant.requires) {
      throw new Error(`Covenant ${name} has no REQUIRES clause`);
    }

    if (!isComparisonExpression(covenant.requires)) {
      // Boolean condition
      const compliant = this.evaluateBoolean(covenant.requires);
      return {
        name,
        compliant,
        actual: compliant ? 1 : 0,
        threshold: 1,
        operator: '=',
      };
    }

    const actual = this.evaluate(covenant.requires.left);
    const threshold = this.evaluate(covenant.requires.right);
    let compliant: boolean;

    switch (covenant.requires.operator) {
      case '<=': compliant = actual <= threshold; break;
      case '>=': compliant = actual >= threshold; break;
      case '<': compliant = actual < threshold; break;
      case '>': compliant = actual > threshold; break;
      case '=': compliant = actual === threshold; break;
      case '!=': compliant = actual !== threshold; break;
      default: compliant = false;
    }

    let headroom: number | undefined;
    if (covenant.requires.operator === '<=') {
      headroom = threshold - actual;
    } else if (covenant.requires.operator === '>=') {
      headroom = actual - threshold;
    }

    return {
      name,
      compliant,
      actual,
      threshold,
      operator: covenant.requires.operator,
      headroom,
    };
  }

  checkAllCovenants(): CovenantResult[] {
    const results: CovenantResult[] = [];
    for (const name of this.covenants.keys()) {
      results.push(this.checkCovenant(name));
    }
    return results;
  }

  // ==================== BASKET OPERATIONS ====================

  /**
   * Determines the type of basket based on its configuration
   */
  private getBasketType(basket: BasketStatement): 'fixed' | 'grower' | 'builder' {
    if (basket.buildsFrom) {
      return 'builder';
    }
    // A grower basket has a floor or uses a percentage/dynamic expression for capacity
    if (basket.floor) {
      return 'grower';
    }
    return 'fixed';
  }

  /**
   * Calculate the capacity for a grower basket
   * Grower baskets have capacity that scales with financial metrics (e.g., 10% * EBITDA)
   * with an optional floor (minimum capacity)
   */
  private getGrowerBasketCapacity(basket: BasketStatement): { capacity: number; baseCapacity: number; floor?: number } {
    let baseCapacity = 0;

    if (basket.capacity) {
      baseCapacity = this.evaluate(basket.capacity);
    }

    // Add any PLUS components
    for (const plus of basket.plus) {
      baseCapacity += this.evaluate(plus);
    }

    let capacity = baseCapacity;

    // Apply floor if present
    const floor = basket.floor ? this.evaluate(basket.floor) : undefined;
    if (floor !== undefined) {
      capacity = Math.max(capacity, floor);
    }

    return { capacity, baseCapacity, floor };
  }

  /**
   * Calculate the capacity for a builder basket
   * Builder baskets accumulate capacity over time from specified sources
   * with optional starting amount and maximum cap
   */
  private getBuilderBasketCapacity(basket: BasketStatement): { capacity: number; accumulated: number; maximum?: number } {
    // Get starting amount
    const starting = basket.starting ? this.evaluate(basket.starting) : 0;

    // Get accumulated amount (from previous accumulate() calls)
    const accumulated = this.basketAccumulation.get(basket.name) ?? 0;

    let capacity = starting + accumulated;

    // Apply maximum cap if present
    const maximum = basket.maximum ? this.evaluate(basket.maximum) : undefined;
    if (maximum !== undefined) {
      capacity = Math.min(capacity, maximum);
    }

    // Add any PLUS components (additional one-time capacity)
    for (const plus of basket.plus) {
      capacity += this.evaluate(plus);
    }

    return { capacity, accumulated, maximum };
  }

  getBasketCapacity(name: string): number {
    const basket = this.baskets.get(name);
    if (!basket) {
      throw new Error(`Unknown basket: ${name}`);
    }

    const basketType = this.getBasketType(basket);

    switch (basketType) {
      case 'builder':
        return this.getBuilderBasketCapacity(basket).capacity;
      case 'grower':
        return this.getGrowerBasketCapacity(basket).capacity;
      default: {
        // Fixed basket - original logic
        let capacity = 0;
        if (basket.capacity) {
          capacity = this.evaluate(basket.capacity);
        }
        for (const plus of basket.plus) {
          capacity += this.evaluate(plus);
        }
        return capacity;
      }
    }
  }

  getBasketUsed(name: string): number {
    return this.basketUtilization.get(name) ?? 0;
  }

  getBasketAvailable(name: string): number {
    return this.getBasketCapacity(name) - this.getBasketUsed(name);
  }

  getBasketStatus(name: string): BasketStatus {
    const basket = this.baskets.get(name);
    if (!basket) {
      throw new Error(`Unknown basket: ${name}`);
    }

    const basketType = this.getBasketType(basket);
    const capacity = this.getBasketCapacity(name);
    const used = this.getBasketUsed(name);

    const status: BasketStatus = {
      name,
      capacity,
      used,
      available: capacity - used,
      basketType,
    };

    // Add type-specific details
    if (basketType === 'grower') {
      const growerDetails = this.getGrowerBasketCapacity(basket);
      status.baseCapacity = growerDetails.baseCapacity;
      status.floor = growerDetails.floor;
    } else if (basketType === 'builder') {
      const builderDetails = this.getBuilderBasketCapacity(basket);
      status.accumulated = builderDetails.accumulated;
      status.starting = basket.starting ? this.evaluate(basket.starting) : 0;
      status.maximum = builderDetails.maximum;
    }

    return status;
  }

  getAllBasketStatuses(): BasketStatus[] {
    const statuses: BasketStatus[] = [];
    for (const name of this.baskets.keys()) {
      statuses.push(this.getBasketStatus(name));
    }
    return statuses;
  }

  useBasket(name: string, amount: number, description: string): void {
    const available = this.getBasketAvailable(name);
    if (amount > available) {
      throw new Error(`Insufficient basket capacity: ${name} has $${available} available, requested $${amount}`);
    }

    const current = this.basketUtilization.get(name) ?? 0;
    this.basketUtilization.set(name, current + amount);

    this.basketLedger.push({
      timestamp: new Date(),
      basket: name,
      amount,
      description,
      entryType: 'usage',
    });
  }

  /**
   * Accumulate capacity to a builder basket
   * This is called periodically (e.g., quarterly) to add capacity based on the BUILDS_FROM expression
   */
  accumulateBuilderBasket(name: string, description: string): number {
    const basket = this.baskets.get(name);
    if (!basket) {
      throw new Error(`Unknown basket: ${name}`);
    }

    if (!basket.buildsFrom) {
      throw new Error(`Basket ${name} is not a builder basket (no BUILDS_FROM clause)`);
    }

    // Evaluate the BUILDS_FROM expression
    const accumulationAmount = this.evaluate(basket.buildsFrom);

    // Add to current accumulation
    const current = this.basketAccumulation.get(name) ?? 0;
    let newTotal = current + accumulationAmount;

    // Apply maximum cap if present
    if (basket.maximum) {
      const starting = basket.starting ? this.evaluate(basket.starting) : 0;
      const maximum = this.evaluate(basket.maximum);
      // The maximum applies to the total capacity (starting + accumulated)
      const maxAccumulation = maximum - starting;
      newTotal = Math.min(newTotal, maxAccumulation);
    }

    this.basketAccumulation.set(name, newTotal);

    // Record in ledger
    this.basketLedger.push({
      timestamp: new Date(),
      basket: name,
      amount: accumulationAmount,
      description,
      entryType: 'accumulation',
    });

    return accumulationAmount;
  }

  /**
   * Get all builder basket names
   */
  getBuilderBasketNames(): string[] {
    const names: string[] = [];
    for (const [name, basket] of this.baskets) {
      if (this.getBasketType(basket) === 'builder') {
        names.push(name);
      }
    }
    return names;
  }

  /**
   * Get all grower basket names
   */
  getGrowerBasketNames(): string[] {
    const names: string[] = [];
    for (const [name, basket] of this.baskets) {
      if (this.getBasketType(basket) === 'grower') {
        names.push(name);
      }
    }
    return names;
  }

  // ==================== PROHIBITION CHECKING ====================

  checkProhibition(action: string, amount?: number): QueryResult {
    const prohibition = this.prohibitions.get(action);
    const reasoning: ReasoningStep[] = [];
    const warnings: string[] = [];

    if (!prohibition) {
      // No prohibition found - permitted by default
      return {
        permitted: true,
        reasoning: [{
          rule: 'Default',
          evaluation: `No prohibition found for ${action}`,
          passed: true,
        }],
        warnings: [],
      };
    }

    // Set evaluation context if amount is provided
    if (amount !== undefined) {
      this.evaluationContext = { bindings: { amount } };
    }

    try {
      // Action is prohibited by default
      reasoning.push({
        rule: `Prohibit ${action}`,
        evaluation: `${action} is generally prohibited`,
        passed: false,
      });

      // Check exceptions
      for (const exception of prohibition.exceptions) {
        if (exception.type === 'ExceptWhen' && exception.conditions) {
          let allConditionsMet = true;

          for (const cond of exception.conditions) {
            const condMet = this.evaluateBoolean(cond);
            reasoning.push({
              rule: this.describeCondition(cond),
              evaluation: condMet ? 'PASS' : 'FAIL',
              passed: condMet,
            });

            if (!condMet) {
              allConditionsMet = false;
            }
          }

          if (allConditionsMet) {
            return {
              permitted: true,
              reasoning,
              warnings,
            };
          }
        }
      }

      return {
        permitted: false,
        reasoning,
        warnings: ['All exception conditions must be satisfied'],
      };
    } finally {
      // Clear evaluation context
      this.evaluationContext = {};
    }
  }

  private describeCondition(cond: Expression): string {
    if (typeof cond === 'string') {
      return cond;
    }
    if (!isObjectExpression(cond)) {
      return String(cond);
    }
    if (isComparisonExpression(cond)) {
      return `${this.describeExpr(cond.left)} ${cond.operator} ${this.describeExpr(cond.right)}`;
    }
    if (isFunctionCallExpression(cond)) {
      return `${cond.name}(${cond.arguments.map((a) => this.describeExpr(a)).join(', ')})`;
    }
    return JSON.stringify(cond);
  }

  private describeExpr(expr: Expression): string {
    if (typeof expr === 'string') return expr;
    if (typeof expr === 'number') return expr.toString();
    if (!isObjectExpression(expr)) return '...';

    switch (expr.type) {
      case 'Currency': return `$${expr.value.toLocaleString()}`;
      case 'Number': return expr.value.toString();
      case 'Ratio': return `${expr.value}x`;
      case 'Percentage': return `${expr.value}%`;
      case 'FunctionCall': return `${expr.name}(...)`;
      default: return '...';
    }
  }

  // ==================== SIMULATION ====================

  simulate(changes: Partial<FinancialData>): SimulationResult {
    // Save current state
    const savedData = { ...this.financialData };

    // Apply changes (filter out undefined values)
    for (const [key, value] of Object.entries(changes)) {
      if (value !== undefined) {
        this.financialData[key] = value;
      }
    }

    // Evaluate
    const covenants = this.checkAllCovenants();
    const baskets = this.getAllBasketStatuses();

    // Restore state
    this.financialData = savedData;

    return { covenants, baskets };
  }

  // ==================== STATUS REPORT ====================

  getStatus(): StatusReport {
    const covenants = this.checkAllCovenants();
    const baskets = this.getAllBasketStatuses();
    const overallCompliant = covenants.every(c => c.compliant);

    return {
      timestamp: new Date(),
      covenants,
      baskets,
      overallCompliant,
    };
  }

  // ==================== UTILITIES ====================

  getDefinedTerms(): string[] {
    return Array.from(this.definitions.keys());
  }

  getCovenantNames(): string[] {
    return Array.from(this.covenants.keys());
  }

  getBasketNames(): string[] {
    return Array.from(this.baskets.keys());
  }

  getConditionNames(): string[] {
    return Array.from(this.conditions.keys());
  }

  getProhibitionTargets(): string[] {
    return Array.from(this.prohibitions.keys());
  }

  setEventDefault(name: string): void {
    this.eventDefaults.add(name);
  }

  clearEventDefault(name: string): void {
    this.eventDefaults.delete(name);
  }

  hasEventDefault(name: string): boolean {
    return this.eventDefaults.has(name);
  }

  getBasketLedger(): BasketLedgerEntry[] {
    return [...this.basketLedger];
  }

  // ==================== CURE RIGHTS ====================

  /**
   * Check a covenant with cure rights information
   */
  checkCovenantWithCure(name: string): CovenantResultWithCure {
    const result = this.checkCovenant(name) as CovenantResultWithCure;
    const covenant = this.covenants.get(name);

    if (!result.compliant && covenant?.cure) {
      result.cureAvailable = this.canApplyCure(name);
      result.shortfall = this.calculateShortfall(result);
      result.cureState = this.cureStates.get(name);
      result.cureMechanism = covenant.cure;
    }

    return result;
  }

  /**
   * Check all covenants with cure information
   */
  checkAllCovenantsWithCure(): CovenantResultWithCure[] {
    const results: CovenantResultWithCure[] = [];
    for (const name of this.covenants.keys()) {
      results.push(this.checkCovenantWithCure(name));
    }
    return results;
  }

  /**
   * Check if cure mechanism is available for a covenant
   */
  canApplyCure(covenantName: string): boolean {
    const covenant = this.covenants.get(covenantName);
    if (!covenant?.cure) return false;

    const maxUses = covenant.cure.details?.maxUses;
    if (maxUses === undefined) return true;

    const used = this.cureUsage.get(covenant.cure.type) ?? 0;
    return used < maxUses;
  }

  /**
   * Apply a cure to a breached covenant
   */
  applyCure(covenantName: string, amount: number): CureResult {
    const covenant = this.covenants.get(covenantName);
    if (!covenant) {
      return { success: false, reason: `Unknown covenant: ${covenantName}` };
    }

    if (!covenant.cure) {
      return { success: false, reason: `Covenant ${covenantName} has no cure mechanism` };
    }

    // Check if cure is available
    if (!this.canApplyCure(covenantName)) {
      return { success: false, reason: 'No cure uses remaining' };
    }

    // Check amount is within limits
    if (covenant.cure.details?.maxAmount) {
      const maxAmount = this.evaluate(covenant.cure.details.maxAmount);
      if (amount > maxAmount) {
        return { success: false, reason: `Amount exceeds maximum cure of $${maxAmount.toLocaleString()}` };
      }
    }

    // Check the covenant status
    const covenantResult = this.checkCovenant(covenantName);
    if (covenantResult.compliant) {
      return { success: false, reason: 'Covenant is already compliant, no cure needed' };
    }

    // Calculate shortfall
    const shortfall = this.calculateShortfall(covenantResult);
    if (amount < shortfall) {
      return { success: false, reason: `Cure amount ($${amount.toLocaleString()}) is less than shortfall ($${shortfall.toLocaleString()})` };
    }

    // Track usage
    const used = this.cureUsage.get(covenant.cure.type) ?? 0;
    this.cureUsage.set(covenant.cure.type, used + 1);

    // Update or create cure state
    let state = this.cureStates.get(covenantName);
    if (!state) {
      state = {
        covenantName,
        breachDate: new Date(),
        cureDeadline: this.calculateCureDeadline(covenant),
        status: 'breach',
        cureAttempts: [],
      };
      this.cureStates.set(covenantName, state);
    }

    state.status = 'cured';
    state.cureAttempts.push({
      date: new Date(),
      mechanism: covenant.cure.type,
      amount,
      successful: true,
    });

    return { success: true, curedAmount: amount };
  }

  /**
   * Calculate the cure deadline based on covenant cure period
   */
  private calculateCureDeadline(covenant: CovenantStatement): Date {
    const deadline = new Date();
    const curePeriod = covenant.cure?.details?.curePeriod;

    if (curePeriod) {
      switch (curePeriod.unit) {
        case 'days':
          deadline.setDate(deadline.getDate() + curePeriod.amount);
          break;
        case 'months':
          deadline.setMonth(deadline.getMonth() + curePeriod.amount);
          break;
        case 'years':
          deadline.setFullYear(deadline.getFullYear() + curePeriod.amount);
          break;
      }
    } else {
      // Default 30-day cure period
      deadline.setDate(deadline.getDate() + 30);
    }

    return deadline;
  }

  /**
   * Calculate the shortfall amount needed to cure a covenant
   */
  calculateShortfall(result: CovenantResult): number {
    if (result.compliant) return 0;

    // For leverage covenant (actual <= threshold), shortfall is actual - threshold
    // This represents how much EBITDA increase (or debt decrease) is needed
    if (result.operator === '<=') {
      return result.actual - result.threshold;
    }
    // For coverage covenant (actual >= threshold), shortfall is threshold - actual
    if (result.operator === '>=') {
      return result.threshold - result.actual;
    }

    return Math.abs(result.actual - result.threshold);
  }

  /**
   * Get cure usage summary across all mechanisms
   */
  getCureUsage(): CureUsage[] {
    const usageMap = new Map<string, CureUsage>();

    for (const [, covenant] of this.covenants) {
      if (covenant.cure) {
        const mechanismType = covenant.cure.type;
        const maxUses = covenant.cure.details?.maxUses ?? Infinity;

        if (!usageMap.has(mechanismType)) {
          const totalUses = this.cureUsage.get(mechanismType) ?? 0;
          usageMap.set(mechanismType, {
            mechanism: mechanismType,
            usesRemaining: maxUses === Infinity ? Infinity : maxUses - totalUses,
            totalUses,
            maxUses,
            period: covenant.cure.details?.overPeriod ?? 'unlimited',
          });
        }
      }
    }

    return Array.from(usageMap.values());
  }

  /**
   * Get cure state for a specific covenant
   */
  getCureState(covenantName: string): CureState | undefined {
    return this.cureStates.get(covenantName);
  }

  /**
   * Record a covenant breach (starts cure period)
   */
  recordBreach(covenantName: string): void {
    const covenant = this.covenants.get(covenantName);
    if (!covenant) {
      throw new Error(`Unknown covenant: ${covenantName}`);
    }

    if (!this.cureStates.has(covenantName)) {
      this.cureStates.set(covenantName, {
        covenantName,
        breachDate: new Date(),
        cureDeadline: this.calculateCureDeadline(covenant),
        status: 'breach',
        cureAttempts: [],
      });
    }
  }

  /**
   * Get covenants that have cure mechanisms
   */
  getCovenantsWithCure(): string[] {
    const names: string[] = [];
    for (const [name, covenant] of this.covenants) {
      if (covenant.cure) {
        names.push(name);
      }
    }
    return names;
  }

  // ==================== AMENDMENTS ====================

  /**
   * Apply an amendment to the current agreement state
   */
  applyAmendment(amendment: AmendmentStatement): void {
    for (const directive of amendment.directives) {
      this.applyDirective(directive);
    }
    this.appliedAmendments.push(amendment);
  }

  private applyDirective(directive: AmendmentDirective): void {
    switch (directive.directive) {
      case 'replace':
        this.replaceStatement(directive.targetType, directive.targetName, directive.replacement);
        break;
      case 'add':
        this.loadStatement(directive.statement);
        break;
      case 'delete':
        this.deleteStatement(directive.targetType, directive.targetName);
        break;
      case 'modify':
        this.modifyStatement(directive.targetType, directive.targetName, directive.modifications);
        break;
    }
  }

  private replaceStatement(type: string, name: string, stmt: Statement): void {
    // First delete the old statement
    this.deleteStatement(type, name);
    // Then add the new one
    this.loadStatement(stmt);
  }

  private deleteStatement(type: string, name: string): void {
    switch (type) {
      case 'Define':
        if (!this.definitions.has(name)) {
          throw new Error(`Cannot delete: DEFINE ${name} not found`);
        }
        this.definitions.delete(name);
        break;
      case 'Covenant':
        if (!this.covenants.has(name)) {
          throw new Error(`Cannot delete: COVENANT ${name} not found`);
        }
        this.covenants.delete(name);
        break;
      case 'Basket':
        if (!this.baskets.has(name)) {
          throw new Error(`Cannot delete: BASKET ${name} not found`);
        }
        this.baskets.delete(name);
        this.basketUtilization.delete(name);
        this.basketAccumulation.delete(name);
        break;
      case 'Condition':
        if (!this.conditions.has(name)) {
          throw new Error(`Cannot delete: CONDITION ${name} not found`);
        }
        this.conditions.delete(name);
        break;
      case 'Prohibit':
        if (!this.prohibitions.has(name)) {
          throw new Error(`Cannot delete: PROHIBIT ${name} not found`);
        }
        this.prohibitions.delete(name);
        break;
      case 'Event':
        if (!this.events.has(name)) {
          throw new Error(`Cannot delete: EVENT ${name} not found`);
        }
        this.events.delete(name);
        break;
    }
  }

  private modifyStatement(type: string, name: string, modifications: ModificationClause[]): void {
    switch (type) {
      case 'Basket': {
        const basket = this.baskets.get(name);
        if (!basket) {
          throw new Error(`Cannot modify: BASKET ${name} not found`);
        }
        for (const mod of modifications) {
          switch (mod.type) {
            case 'capacity':
              basket.capacity = mod.value;
              break;
            case 'floor':
              basket.floor = mod.value;
              break;
            case 'maximum':
              basket.maximum = mod.value;
              break;
          }
        }
        break;
      }
      case 'Covenant': {
        const covenant = this.covenants.get(name);
        if (!covenant) {
          throw new Error(`Cannot modify: COVENANT ${name} not found`);
        }
        for (const mod of modifications) {
          switch (mod.type) {
            case 'requires':
              covenant.requires = mod.value;
              break;
            case 'tested':
              covenant.tested = mod.value as 'quarterly' | 'annually' | 'monthly';
              break;
          }
        }
        break;
      }
      default:
        throw new Error(`Modification not supported for ${type}`);
    }
  }

  /**
   * Get list of applied amendments
   */
  getAppliedAmendments(): AmendmentStatement[] {
    return [...this.appliedAmendments];
  }

  /**
   * Get event names
   */
  getEventNames(): string[] {
    return Array.from(this.events.keys());
  }
}
