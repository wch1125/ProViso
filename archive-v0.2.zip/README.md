# CreditLang

**Domain-Specific Language for Credit Agreements**

CreditLang is an executable DSL that allows credit agreements to be expressed as code. The source files read like legal documents but run like programs—answering compliance questions, tracking basket utilization, and simulating proposed transactions.

## Quick Start

```bash
# Install dependencies
npm install

# Build the grammar and TypeScript
npm run build

# Run tests
npm test

# Check compliance status
npx ts-node src/cli.ts status examples/corporate_revolver.crl -d examples/q3_2024_financials.json

# Simulate a transaction (e.g., adding $44M debt)
npx ts-node src/cli.ts simulate examples/corporate_revolver.crl \
  -d examples/q3_2024_financials.json \
  -c '{"funded_debt": 200000000}'
```

## Example Output

```
╔══════════════════════════════════════════════════════════╗
║                  CREDITLANG STATUS REPORT                 ║
╚══════════════════════════════════════════════════════════╝

FINANCIAL COVENANTS
────────────────────────────────────────────────────────────
  ✓ MaxLeverage               3.60x <= 4.50x (headroom: 0.90x)
  ✓ MinInterestCoverage       5.45x >= 2.50x (headroom: 2.95x)
  ✓ MinLiquidity              $28.4M >= $15.0M

BASKET AVAILABILITY
────────────────────────────────────────────────────────────
  GeneralInvestments    [░░░░░░░░░░░░░░░░░░░░] $25.0M available
  RestrictedPayments    [░░░░░░░░░░░░░░░░░░░░] $17.0M available
  PermittedAcquisitions [░░░░░░░░░░░░░░░░░░░░] $75.0M available

════════════════════════════════════════════════════════════
OVERALL STATUS: ✓ COMPLIANT
════════════════════════════════════════════════════════════
```

## Language Syntax

### Definitions

```
DEFINE EBITDA AS
  net_income + interest_expense + tax_expense + depreciation + amortization
  EXCLUDING extraordinary_items

DEFINE TotalDebt AS
  funded_debt + capital_leases

DEFINE Leverage AS
  TotalDebt / EBITDA
```

### Financial Covenants

```
COVENANT MaxLeverage
  REQUIRES Leverage <= 4.50
  TESTED QUARTERLY

COVENANT MinInterestCoverage
  REQUIRES EBITDA / interest_expense >= 2.50
  TESTED QUARTERLY
```

### Baskets

```
BASKET GeneralInvestments
  CAPACITY $25_000_000

BASKET RestrictedPayments
  CAPACITY GreaterOf($10_000_000, 5% * total_assets)
```

### Conditions

```
CONDITION NoDefault AS
  NOT EXISTS(EventOfDefault) AND NOT EXISTS(UnmaturedDefault)

CONDITION ProFormaCompliance AS
  COMPLIANT(MaxLeverage) AND COMPLIANT(MinInterestCoverage)
```

### Prohibitions with Exceptions

```
PROHIBIT Dividends
  EXCEPT WHEN
    | amount <= AVAILABLE(RestrictedPayments)
    | AND NoDefault
    | AND COMPLIANT(MaxLeverage)
```

### Events

```
EVENT CrossDefault
  TRIGGERS WHEN external_debt_default > 10_000_000
  CONSEQUENCE EventOfDefault
```

### Grower Baskets

Capacity that scales with financial metrics:

```
BASKET EBITDABasket
  CAPACITY 10% * EBITDA
  FLOOR $5_000_000

BASKET AssetBasedBasket
  CAPACITY GreaterOf($15_000_000, 7.5% * total_assets)
  FLOOR $10_000_000
```

### Builder Baskets

Capacity that accumulates over time:

```
BASKET RetainedEarnings
  BUILDS_FROM 50% * net_income
  STARTING $10_000_000
  MAXIMUM $75_000_000
```

### Cure Rights

Allow equity cures for covenant breaches:

```
COVENANT MaxLeverage
  REQUIRES Leverage <= 4.50
  TESTED QUARTERLY
  CURE EquityCure MAX_USES 3 OVER life_of_facility MAX_AMOUNT $20_000_000
  BREACH -> UnmaturedDefault
```

### Amendments

Modify agreements over time with overlay files:

```
// amendments/001_2024-06-15.crl
AMENDMENT 1
  EFFECTIVE 2024-06-15
  DESCRIPTION "First Amendment - Covenant Relief"

  REPLACES COVENANT MaxLeverage WITH
    COVENANT MaxLeverage
      REQUIRES Leverage <= 5.00
      TESTED QUARTERLY

  ADDS BASKET AdditionalInvestments
    CAPACITY $15_000_000

  MODIFIES BASKET GeneralInvestments
    CAPACITY $35_000_000

  DELETES CONDITION OldCondition
```

## CLI Commands

| Command | Description |
|---------|-------------|
| `parse <file>` | Parse a .crl file and output AST |
| `validate <file>` | Validate syntax and semantic errors |
| `check <file>` | Check covenant compliance |
| `baskets <file>` | Show basket utilization |
| `simulate <file>` | Simulate pro forma changes |
| `status <file>` | Full compliance status report |
| `query <file> <action>` | Check if an action is permitted |
| `accumulate <file> [basket]` | Accumulate capacity in builder baskets |
| `ledger <file>` | View basket transaction ledger |
| `cure <file> <covenant> <amount>` | Apply cure to a breached covenant |
| `amendments <file>` | List applied amendments |

### Common Options

- `-d, --data <file>` - Financial data JSON file
- `-a, --amendments <files...>` - Amendment files to apply in order
- `-v, --verbose` - Show detailed information

### Examples

```bash
# Check status with amendments applied
npx ts-node src/cli.ts status examples/corporate_revolver.crl \
  -d examples/q3_2024_financials.json \
  -a amendments/001.crl amendments/002.crl

# View basket ledger
npx ts-node src/cli.ts ledger examples/corporate_revolver.crl \
  -d examples/q3_2024_financials.json \
  --basket RetainedEarnings

# Apply equity cure to a breached covenant
npx ts-node src/cli.ts cure examples/corporate_revolver.crl MaxLeverage 15000000 \
  -d examples/q3_2024_financials.json
```

## Project Structure

```
creditlang/
├── grammar/
│   └── creditlang.pegjs    # PEG grammar definition
├── src/
│   ├── cli.ts              # Command-line interface
│   ├── parser.ts           # Parser wrapper
│   ├── interpreter.ts      # Runtime/evaluator
│   ├── types.ts            # TypeScript type definitions
│   └── index.ts            # Main exports
├── examples/
│   ├── corporate_revolver.crl      # Sample credit agreement
│   └── q3_2024_financials.json     # Sample financial data
└── tests/
    └── creditlang.test.ts  # Test suite
```

## Development

```bash
# Build grammar only
npm run build:grammar

# Build TypeScript only
npm run build:ts

# Run tests in watch mode
npm run test:watch

# Type checking
npm run typecheck

# Linting
npm run lint

# Formatting
npm run format
```

## Roadmap

**v0.1** - Core MVP
- [x] Parser for basic syntax
- [x] DEFINE statements with arithmetic
- [x] Financial covenants (ratio-based)
- [x] Simple baskets (fixed capacity)
- [x] GreaterOf / LesserOf functions
- [x] EXCLUDING modifier
- [x] Pro forma simulation
- [x] CLI interface

**v0.2 (Current)** - Enhanced Baskets & Amendments
- [x] Grower baskets (capacity scales with metrics)
- [x] Builder baskets (capacity accumulates over time)
- [x] Basket ledger with transaction history
- [x] Amendment overlay system
- [x] Cure rights mechanics
- [x] Semantic validation
- [x] Enhanced error messages

**v0.3** - Project Finance Module
- [ ] Phase state machine (Construction → COD → Operations)
- [ ] Milestone tracking with longstops
- [ ] Conditions precedent checklists
- [ ] Waterfall execution
- [ ] Reserve account logic

**v1.0** - Production Ready
- [ ] Web UI dashboard
- [ ] Multi-party access control
- [ ] API endpoints
- [ ] Integration with accounting systems

## License

MIT

## Author

Haslun Studio
