// CreditLang Type Definitions

// ==================== AST NODES ====================

export interface Program {
  type: 'Program';
  statements: Statement[];
}

export type Statement =
  | DefineStatement
  | CovenantStatement
  | BasketStatement
  | ConditionStatement
  | ProhibitStatement
  | EventStatement
  | LoadStatement
  | CommentStatement
  | AmendmentStatement
  | PhaseStatement
  | TransitionStatement
  | MilestoneStatement
  | ReserveStatement
  | WaterfallStatement
  | ConditionsPrecedentStatement;

export interface DefineStatement {
  type: 'Define';
  name: string;
  expression: Expression;
  modifiers: DefineModifiers;
}

export interface DefineModifiers {
  excluding?: string[];
  cap?: Expression;
}

export interface CovenantStatement {
  type: 'Covenant';
  name: string;
  requires: Expression | null;
  tested: Frequency | null;
  cure: CureMechanism | null;
  breach: string | null;
}

export type Frequency = 'quarterly' | 'annually' | 'monthly';

export interface CureMechanism {
  type: 'EquityCure' | 'PaymentCure';
  details: CureDetails;
}

export interface CureDetails {
  maxUses?: number;
  overPeriod?: string;
  maxAmount?: Expression;
  curePeriod?: Duration;
}

export interface BasketStatement {
  type: 'Basket';
  name: string;
  capacity: Expression | null;
  plus: Expression[];
  subjectTo: string[] | null;
  // Grower basket: minimum floor for the capacity
  floor: Expression | null;
  // Builder basket: expression that adds to capacity over time
  buildsFrom: Expression | null;
  // Builder basket: starting capacity amount
  starting: Expression | null;
  // Builder basket: maximum capacity cap
  maximum: Expression | null;
}

export interface ConditionStatement {
  type: 'Condition';
  name: string;
  expression: Expression;
}

export interface ProhibitStatement {
  type: 'Prohibit';
  target: string;
  exceptions: ExceptClause[];
}

export type ExceptClause = ExceptWhenClause | NotwithstandingClause;

export interface ExceptWhenClause {
  type: 'ExceptWhen';
  conditions: Expression[];
  notwithstanding?: string;
}

export interface NotwithstandingClause {
  type: 'Notwithstanding';
  reference: string;
}

export interface EventStatement {
  type: 'Event';
  name: string;
  triggers: Expression | null;
  gracePeriod: Duration | null;
  consequence: string | null;
}

export interface LoadStatement {
  type: 'Load';
  source: LoadSource;
}

export type LoadSource = FileSource | InlineSource;

export interface FileSource {
  type: 'file';
  path: string;
}

export interface InlineSource {
  type: 'inline';
  data: Record<string, unknown>;
}

export interface CommentStatement {
  type: 'Comment';
  text: string;
}

// ==================== EXPRESSIONS ====================

export type Expression =
  | string // Identifier
  | number
  | NumberLiteral
  | CurrencyLiteral
  | PercentageLiteral
  | RatioLiteral
  | BinaryExpression
  | UnaryExpression
  | ComparisonExpression
  | FunctionCallExpression
  | TrailingExpression;

export interface NumberLiteral {
  type: 'Number';
  value: number;
}

export interface CurrencyLiteral {
  type: 'Currency';
  value: number;
}

export interface PercentageLiteral {
  type: 'Percentage';
  value: number;
  unit?: 'bps';
}

export interface RatioLiteral {
  type: 'Ratio';
  value: number;
}

export interface BinaryExpression {
  type: 'BinaryExpression';
  operator: '+' | '-' | '*' | '/' | 'AND' | 'OR';
  left: Expression;
  right: Expression;
}

export interface UnaryExpression {
  type: 'UnaryExpression';
  operator: '-' | 'NOT';
  argument: Expression;
}

export interface ComparisonExpression {
  type: 'Comparison';
  operator: '<=' | '>=' | '<' | '>' | '=' | '!=';
  left: Expression;
  right: Expression;
}

export interface FunctionCallExpression {
  type: 'FunctionCall';
  name: string;
  arguments: Expression[];
}

/**
 * Trailing expression for period-based calculations.
 * Example: TRAILING 4 QUARTERS OF EBITDA
 */
export interface TrailingExpression {
  type: 'Trailing';
  /** Number of periods to include */
  count: number;
  /** Type of periods (quarters, months, years) */
  period: 'quarters' | 'months' | 'years';
  /** Expression to evaluate for each period */
  expression: Expression;
}

/**
 * Type guard for TrailingExpression
 */
export function isTrailingExpression(expr: Expression): expr is TrailingExpression {
  return isObjectExpression(expr) && expr.type === 'Trailing';
}

export interface Duration {
  type: 'Duration';
  amount: number;
  unit: 'days' | 'months' | 'years';
}

// ==================== TYPE GUARDS ====================

/**
 * Union type of all object-based expressions (excludes string and number primitives)
 */
export type ObjectExpression =
  | NumberLiteral
  | CurrencyLiteral
  | PercentageLiteral
  | RatioLiteral
  | BinaryExpression
  | UnaryExpression
  | ComparisonExpression
  | FunctionCallExpression
  | TrailingExpression;

/**
 * Check if an expression is an object-based expression (not a string identifier or number)
 */
export function isObjectExpression(expr: Expression): expr is ObjectExpression {
  return expr !== null && typeof expr === 'object';
}

/**
 * Check if an expression is a ComparisonExpression
 */
export function isComparisonExpression(expr: Expression): expr is ComparisonExpression {
  return isObjectExpression(expr) && expr.type === 'Comparison';
}

/**
 * Check if an expression is a BinaryExpression
 */
export function isBinaryExpression(expr: Expression): expr is BinaryExpression {
  return isObjectExpression(expr) && expr.type === 'BinaryExpression';
}

/**
 * Check if an expression is a UnaryExpression
 */
export function isUnaryExpression(expr: Expression): expr is UnaryExpression {
  return isObjectExpression(expr) && expr.type === 'UnaryExpression';
}

/**
 * Check if an expression is a FunctionCallExpression
 */
export function isFunctionCallExpression(expr: Expression): expr is FunctionCallExpression {
  return isObjectExpression(expr) && expr.type === 'FunctionCall';
}

// ==================== RUNTIME TYPES ====================

/**
 * Simple financial data - a flat record of metric names to values.
 * This is the original format and is still fully supported.
 */
export type SimpleFinancialData = Record<string, number>;

/**
 * Period-specific financial data with period identification.
 */
export interface PeriodData {
  /** Period identifier (e.g., "2024-Q1", "2024-Q2", "2024-12") */
  period: string;
  /** Type of period for interpretation */
  periodType: 'quarterly' | 'monthly' | 'annual';
  /** ISO date string for the period end date (e.g., "2024-03-31") */
  periodEnd: string;
  /** Financial data for this period */
  data: Record<string, number>;
}

/**
 * Multi-period financial data with multiple periods.
 */
export interface MultiPeriodFinancialData {
  /** Array of period data, typically in chronological order */
  periods: PeriodData[];
  /** Optional pre-calculated trailing values (e.g., trailing["LTM"]["EBITDA"]) */
  trailing?: Record<string, Record<string, number>>;
}

/**
 * Financial data can be either simple (flat) or multi-period.
 * The interpreter detects which format is used and handles it appropriately.
 */
export type FinancialData = SimpleFinancialData | MultiPeriodFinancialData;

/**
 * Type guard to check if financial data is multi-period format.
 */
export function isMultiPeriodData(data: unknown): data is MultiPeriodFinancialData {
  return (
    typeof data === 'object' &&
    data !== null &&
    'periods' in data &&
    Array.isArray((data as MultiPeriodFinancialData).periods)
  );
}

/**
 * Type guard to check if data is a PeriodData object.
 */
export function isPeriodData(data: unknown): data is PeriodData {
  return (
    typeof data === 'object' &&
    data !== null &&
    'period' in data &&
    'periodType' in data &&
    'periodEnd' in data &&
    'data' in data
  );
}

/**
 * Type guard to check if financial data is simple (flat) format.
 */
export function isSimpleFinancialData(data: unknown): data is SimpleFinancialData {
  if (typeof data !== 'object' || data === null) return false;
  // Simple data has no 'periods' key and all values are numbers
  if ('periods' in data) return false;
  return Object.values(data).every((v) => typeof v === 'number');
}

export interface CovenantResult {
  name: string;
  compliant: boolean;
  actual: number;
  threshold: number;
  operator: string;
  headroom?: number;
}

export interface BasketStatus {
  name: string;
  capacity: number;
  used: number;
  available: number;
  // For grower baskets: the calculated base capacity before floor
  baseCapacity?: number;
  // For grower baskets: the floor that was applied
  floor?: number;
  // For builder baskets: accumulated amount
  accumulated?: number;
  // For builder baskets: starting capacity
  starting?: number;
  // For builder baskets: maximum cap
  maximum?: number;
  // Basket classification
  basketType?: 'fixed' | 'grower' | 'builder';
}

export interface BasketLedgerEntry {
  timestamp: Date;
  basket: string;
  amount: number;
  description: string;
  // For builder baskets: whether this is an accumulation (+) or usage (-)
  entryType?: 'usage' | 'accumulation';
}

export interface QueryResult {
  permitted: boolean;
  reasoning: ReasoningStep[];
  warnings: string[];
}

export interface ReasoningStep {
  rule: string;
  evaluation: string;
  passed: boolean;
}

export interface SimulationResult {
  covenants: CovenantResult[];
  baskets: BasketStatus[];
}

export interface StatusReport {
  timestamp: Date;
  covenants: CovenantResult[];
  baskets: BasketStatus[];
  overallCompliant: boolean;
  /** Current phase (if phases are defined) */
  currentPhase?: string;
  /** Covenants that are suspended in the current phase */
  suspendedCovenants?: string[];
}

// ==================== PARSER TYPES ====================

export interface ParseErrorLocation {
  start: { line: number; column: number; offset?: number };
  end: { line: number; column: number; offset?: number };
}

export interface ParseError {
  message: string;
  location?: ParseErrorLocation;
  /** What the parser expected at the error position */
  expected?: string[];
  /** What was actually found at the error position */
  found?: string | null;
}

export interface ParseResult {
  success: boolean;
  ast?: Program;
  error?: ParseError;
  /** The source that was parsed (for error context display) */
  source?: string;
}

// ==================== VALIDATION TYPES ====================

export type ValidationSeverity = 'error' | 'warning';

export interface ValidationIssue {
  severity: ValidationSeverity;
  message: string;
  /** The name of the undefined or problematic reference */
  reference?: string;
  /** Where the issue occurred */
  context?: string;
  /** What type of reference was expected */
  expectedType?: 'define' | 'covenant' | 'basket' | 'condition' | 'event' | 'identifier';
}

export interface ValidationResult {
  valid: boolean;
  errors: ValidationIssue[];
  warnings: ValidationIssue[];
}

// ==================== CURE RIGHTS TYPES ====================

export type CureStatus = 'breach' | 'unmatured_default' | 'cured' | 'event_of_default';

export interface CureState {
  covenantName: string;
  breachDate: Date;
  cureDeadline: Date;
  status: CureStatus;
  cureAttempts: CureAttempt[];
}

export interface CureAttempt {
  date: Date;
  mechanism: string;
  amount: number;
  successful: boolean;
}

export interface CureUsage {
  mechanism: string;
  usesRemaining: number;
  totalUses: number;
  maxUses: number;
  period: string;
}

export interface CureResult {
  success: boolean;
  reason?: string;
  curedAmount?: number;
}

export interface CovenantResultWithCure extends CovenantResult {
  cureAvailable?: boolean;
  cureState?: CureState;
  shortfall?: number;
  cureMechanism?: CureMechanism;
}

// ==================== AMENDMENT TYPES ====================

export interface AmendmentStatement {
  type: 'Amendment';
  number: number;
  effective: DateLiteral | null;
  description: string | null;
  directives: AmendmentDirective[];
}

export interface DateLiteral {
  type: 'Date';
  value: string; // ISO format: YYYY-MM-DD
}

export type AmendmentDirective =
  | ReplaceDirective
  | AddDirective
  | DeleteDirective
  | ModifyDirective;

export interface ReplaceDirective {
  directive: 'replace';
  targetType: StatementTypeName;
  targetName: string;
  replacement: Statement;
}

export interface AddDirective {
  directive: 'add';
  statement: Statement;
}

export interface DeleteDirective {
  directive: 'delete';
  targetType: StatementTypeName;
  targetName: string;
}

export interface ModifyDirective {
  directive: 'modify';
  targetType: StatementTypeName;
  targetName: string;
  modifications: ModificationClause[];
}

export type StatementTypeName = 'Covenant' | 'Basket' | 'Condition' | 'Define' | 'Prohibit' | 'Event' | 'Phase' | 'Transition';

export interface ModificationClause {
  type: 'capacity' | 'floor' | 'maximum' | 'requires' | 'tested';
  value: Expression;
}

// ==================== PHASE TYPES ====================

/**
 * Phase statement defining a project phase with specific covenant rules.
 * Project finance deals have distinct phases (Construction, Operations, etc.)
 * with different covenants active or suspended.
 */
export interface PhaseStatement {
  type: 'Phase';
  /** Name of the phase (e.g., 'Construction', 'Operations') */
  name: string;
  /** Event/condition that ends this phase (e.g., 'COD_Achieved') */
  until: string | null;
  /** Event/condition that starts this phase */
  from: string | null;
  /** Covenants suspended during this phase */
  covenantsSuspended: string[];
  /** Covenants active during this phase */
  covenantsActive: string[];
  /** Covenants required during this phase */
  requiredCovenants: string[];
}

/**
 * Transition statement defining conditions for phase transitions.
 */
export interface TransitionStatement {
  type: 'Transition';
  /** Name of the transition event (e.g., 'COD_Achieved') */
  name: string;
  /** Condition that triggers this transition */
  when: TransitionCondition | Expression | null;
}

/**
 * Condition for phase transitions - can be ALL_OF or ANY_OF
 */
export type TransitionCondition = AllOfCondition | AnyOfCondition;

export interface AllOfCondition {
  type: 'AllOf';
  conditions: string[];
}

export interface AnyOfCondition {
  type: 'AnyOf';
  conditions: string[];
}

/**
 * Type guard for AllOfCondition
 */
export function isAllOfCondition(cond: unknown): cond is AllOfCondition {
  return (
    typeof cond === 'object' &&
    cond !== null &&
    'type' in cond &&
    (cond as AllOfCondition).type === 'AllOf'
  );
}

/**
 * Type guard for AnyOfCondition
 */
export function isAnyOfCondition(cond: unknown): cond is AnyOfCondition {
  return (
    typeof cond === 'object' &&
    cond !== null &&
    'type' in cond &&
    (cond as AnyOfCondition).type === 'AnyOf'
  );
}

/**
 * Runtime phase state for project finance deals.
 * Tracks current position in the project lifecycle.
 */
export type PhaseState =
  | 'pre_closing'
  | 'construction'
  | 'cod'
  | 'operations'
  | 'maturity'
  | 'default';

/**
 * Record of a phase transition event.
 */
export interface PhaseHistoryEntry {
  /** Phase that was entered */
  phase: string;
  /** When this phase was entered */
  enteredAt: Date;
  /** Transition event that triggered entry (null for initial phase) */
  triggeredBy: string | null;
}

/**
 * Result of checking phase transition conditions.
 */
export interface TransitionResult {
  /** Name of the transition */
  name: string;
  /** Whether the transition conditions are met */
  triggered: boolean;
  /** Individual condition results */
  conditions: { name: string; met: boolean }[];
  /** Target phase if transition triggers */
  targetPhase?: string;
}

// ==================== MILESTONE TYPES ====================

/**
 * Milestone statement for project finance construction tracking.
 * Milestones have target dates, longstop dates (deadlines), and can trigger events.
 */
export interface MilestoneStatement {
  type: 'Milestone';
  /** Name of the milestone (e.g., 'FoundationComplete') */
  name: string;
  /** Target date for achieving the milestone (ISO format: YYYY-MM-DD) */
  targetDate: string | null;
  /** Longstop date - deadline after which milestone is breached (ISO format) */
  longstopDate: string | null;
  /** Events triggered when milestone is achieved */
  triggers: string[];
  /** Prerequisites - other milestones or conditions that must be met first */
  requires: string | AllOfCondition | AnyOfCondition | null;
}

/**
 * Status of a milestone based on current date and achievement.
 */
export type MilestoneStatus =
  | 'pending'    // Not yet achieved, before target date
  | 'achieved'   // Successfully completed
  | 'at_risk'    // Past target date but before longstop
  | 'breached';  // Past longstop date without achievement

/**
 * Result of milestone status check.
 */
export interface MilestoneResult {
  name: string;
  status: MilestoneStatus;
  targetDate: string | null;
  longstopDate: string | null;
  achievedDate?: string;
  /** Days until target (negative if past) */
  daysToTarget: number;
  /** Days until longstop (negative if past) */
  daysToLongstop: number;
  /** Prerequisite check results */
  prerequisites: { name: string; met: boolean }[];
}

// ==================== RESERVE TYPES ====================

/**
 * Reserve account statement for project finance.
 * Reserves hold funds for specific purposes (debt service, maintenance, etc.)
 */
export interface ReserveStatement {
  type: 'Reserve';
  /** Name of the reserve account */
  name: string;
  /** Target balance expression (e.g., 6 * monthly_debt_service) */
  target: Expression | null;
  /** Minimum required balance expression */
  minimum: Expression | null;
  /** Sources that can fund this reserve */
  fundedBy: string[];
  /** What the reserve can be released to (e.g., Waterfall) */
  releasedTo: string | null;
  /** What purposes the reserve can be released for */
  releasedFor: string | null;
}

/**
 * Current status of a reserve account.
 */
export interface ReserveStatus {
  name: string;
  balance: number;
  target: number;
  minimum: number;
  /** Percentage of target funded (0-100+) */
  fundedPercent: number;
  /** Whether balance is below minimum */
  belowMinimum: boolean;
  /** Amount available for release (balance - minimum) */
  availableForRelease: number;
}

// ==================== WATERFALL TYPES ====================

/**
 * Waterfall statement for project finance cash flow distribution.
 * Cash flows through tiers in priority order.
 */
export interface WaterfallStatement {
  type: 'Waterfall';
  /** Name of the waterfall */
  name: string;
  /** Execution frequency */
  frequency: 'monthly' | 'quarterly' | 'annually';
  /** Ordered list of payment tiers */
  tiers: WaterfallTier[];
}

/**
 * A single tier in a waterfall.
 */
export interface WaterfallTier {
  /** Priority order (1 = highest) */
  priority: number;
  /** Display name for the tier */
  name: string;
  /** Reserve account to pay into (for reserve replenishment) */
  payTo: string | null;
  /** Amount to pay (expression) */
  payAmount: Expression | null;
  /** Source of funds */
  from: 'Revenue' | 'REMAINDER';
  /** Condition to stop paying (for reserve caps) */
  until: Expression | null;
  /** Reserve to draw from if tier can't be fully paid */
  shortfall: string | null;
  /** Gate condition (e.g., IF COMPLIANT) */
  condition: Expression | null;
}

/**
 * Result of executing a waterfall.
 */
export interface WaterfallResult {
  /** Name of the waterfall executed */
  name: string;
  /** Starting revenue/funds */
  totalRevenue: number;
  /** Total distributed across all tiers */
  totalDistributed: number;
  /** Remaining after all tiers */
  remainder: number;
  /** Results for each tier */
  tiers: WaterfallTierResult[];
}

/**
 * Result for a single waterfall tier.
 */
export interface WaterfallTierResult {
  priority: number;
  name: string;
  /** Amount requested by this tier */
  requested: number;
  /** Amount actually paid */
  paid: number;
  /** Shortfall (requested - paid) */
  shortfall: number;
  /** Amount drawn from reserve to cover shortfall */
  reserveDrawn: number;
  /** Whether tier was blocked by condition */
  blocked: boolean;
  /** Reason for blocking */
  blockReason?: string;
}

// ==================== CONDITIONS PRECEDENT TYPES ====================

/**
 * Conditions Precedent statement for tracking closing/draw requirements.
 */
export interface ConditionsPrecedentStatement {
  type: 'ConditionsPrecedent';
  /** Name of the CP checklist (e.g., 'InitialFunding', 'Draw3') */
  name: string;
  /** Credit agreement section reference */
  section: string | null;
  /** List of condition precedent items */
  conditions: CPItem[];
}

/**
 * A single condition precedent item.
 */
export interface CPItem {
  /** Identifier for the CP */
  name: string;
  /** Human-readable description */
  description: string | null;
  /** Party responsible for satisfying this CP */
  responsible: string | null;
  /** Current status */
  status: CPStatus;
  /** Events/conditions satisfied when this CP is complete */
  satisfies: string[];
}

/**
 * Status of a condition precedent.
 */
export type CPStatus = 'pending' | 'satisfied' | 'waived' | 'not_applicable';

/**
 * Summary of conditions precedent checklist.
 */
export interface CPChecklistResult {
  name: string;
  section: string | null;
  totalConditions: number;
  satisfied: number;
  pending: number;
  waived: number;
  /** Whether all required conditions are satisfied or waived */
  complete: boolean;
  conditions: CPItemResult[];
}

/**
 * Status of a single CP item.
 */
export interface CPItemResult {
  name: string;
  description: string | null;
  responsible: string | null;
  status: CPStatus;
  satisfies: string[];
}
