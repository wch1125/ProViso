// CreditLang Test Suite
import { describe, it, expect, beforeEach } from 'vitest';
import { parse, parseOrThrow } from '../src/parser.js';
import { CreditLangInterpreter } from '../src/interpreter.js';
import { Program } from '../src/types.js';

// ==================== PARSER TESTS ====================

describe('Parser', () => {
  it('should parse DEFINE statements', async () => {
    const source = `
      DEFINE EBITDA AS
        net_income + interest_expense + tax_expense
    `;
    const ast = await parseOrThrow(source);
    expect(ast.type).toBe('Program');
    expect(ast.statements.length).toBeGreaterThan(0);
    
    const define = ast.statements.find(s => s.type === 'Define');
    expect(define).toBeDefined();
    expect((define as any).name).toBe('EBITDA');
  });

  it('should parse COVENANT statements', async () => {
    const source = `
      COVENANT MaxLeverage
        REQUIRES Leverage <= 4.50
        TESTED QUARTERLY
    `;
    const ast = await parseOrThrow(source);
    const covenant = ast.statements.find(s => s.type === 'Covenant');
    expect(covenant).toBeDefined();
    expect((covenant as any).name).toBe('MaxLeverage');
    expect((covenant as any).tested).toBe('quarterly');
  });

  it('should parse BASKET statements', async () => {
    const source = `
      BASKET GeneralInvestments
        CAPACITY $25_000_000
    `;
    const ast = await parseOrThrow(source);
    const basket = ast.statements.find(s => s.type === 'Basket');
    expect(basket).toBeDefined();
    expect((basket as any).name).toBe('GeneralInvestments');
  });

  it('should parse currency with underscores', async () => {
    const source = `
      BASKET Test
        CAPACITY $1_000_000
    `;
    const ast = await parseOrThrow(source);
    const basket = ast.statements.find(s => s.type === 'Basket') as any;
    expect(basket.capacity.value).toBe(1000000);
  });

  it('should parse GreaterOf function', async () => {
    const source = `
      BASKET RestrictedPayments
        CAPACITY GreaterOf($10_000_000, 5% * total_assets)
    `;
    const ast = await parseOrThrow(source);
    const basket = ast.statements.find(s => s.type === 'Basket') as any;
    expect(basket.capacity.type).toBe('FunctionCall');
    expect(basket.capacity.name).toBe('GreaterOf');
  });

  it('should parse CONDITION statements', async () => {
    const source = `
      CONDITION NoDefault AS
        NOT EXISTS(EventOfDefault)
    `;
    const ast = await parseOrThrow(source);
    const condition = ast.statements.find(s => s.type === 'Condition');
    expect(condition).toBeDefined();
    expect((condition as any).name).toBe('NoDefault');
  });

  it('should parse PROHIBIT with EXCEPT WHEN', async () => {
    const source = `
      PROHIBIT Dividends
        EXCEPT WHEN
          | amount <= AVAILABLE(RestrictedPayments)
          | AND NoDefault
    `;
    const ast = await parseOrThrow(source);
    const prohibit = ast.statements.find(s => s.type === 'Prohibit');
    expect(prohibit).toBeDefined();
    expect((prohibit as any).target).toBe('Dividends');
    expect((prohibit as any).exceptions.length).toBeGreaterThan(0);
  });

  it('should parse EVENT statements', async () => {
    const source = `
      EVENT CrossDefault
        TRIGGERS WHEN external_debt_default > 10_000_000
        CONSEQUENCE EventOfDefault
    `;
    const ast = await parseOrThrow(source);
    const event = ast.statements.find(s => s.type === 'Event');
    expect(event).toBeDefined();
    expect((event as any).name).toBe('CrossDefault');
  });

  it('should parse comments', async () => {
    const source = `
      // This is a comment
      DEFINE Test AS 100
    `;
    const ast = await parseOrThrow(source);
    expect(ast.statements.length).toBe(2);
  });
});

// ==================== INTERPRETER TESTS ====================

describe('Interpreter', () => {
  let interpreter: CreditLangInterpreter;

  const sampleSource = `
    DEFINE EBITDA AS
      net_income + interest_expense + tax_expense + depreciation + amortization
      EXCLUDING extraordinary_items

    DEFINE TotalDebt AS
      funded_debt + capital_leases

    DEFINE Leverage AS
      TotalDebt / EBITDA

    COVENANT MaxLeverage
      REQUIRES Leverage <= 4.50
      TESTED QUARTERLY

    COVENANT MinLiquidity
      REQUIRES cash >= 15_000_000
      TESTED QUARTERLY

    BASKET GeneralInvestments
      CAPACITY $25_000_000

    BASKET RestrictedPayments
      CAPACITY GreaterOf($10_000_000, 5% * total_assets)

    CONDITION NoDefault AS
      NOT EXISTS(EventOfDefault)

    PROHIBIT Investments
      EXCEPT WHEN
        | amount <= AVAILABLE(GeneralInvestments)
        | AND NoDefault
  `;

  const sampleFinancials = {
    net_income: 22000000,
    interest_expense: 8200000,
    tax_expense: 7500000,
    depreciation: 4800000,
    amortization: 2200000,
    extraordinary_items: 0,
    funded_debt: 156000000,
    capital_leases: 5000000,
    cash: 28400000,
    total_assets: 340000000,
  };

  beforeEach(async () => {
    const ast = await parseOrThrow(sampleSource);
    interpreter = new CreditLangInterpreter(ast);
    interpreter.loadFinancials(sampleFinancials);
  });

  describe('Expression Evaluation', () => {
    it('should evaluate EBITDA correctly', () => {
      // EBITDA = net_income + interest + tax + depreciation + amortization - extraordinary
      // = 22M + 8.2M + 7.5M + 4.8M + 2.2M - 0 = 44.7M
      const ebitda = interpreter['evaluate']('EBITDA');
      expect(ebitda).toBe(44700000);
    });

    it('should evaluate TotalDebt correctly', () => {
      // TotalDebt = funded_debt + capital_leases = 156M + 5M = 161M
      const totalDebt = interpreter['evaluate']('TotalDebt');
      expect(totalDebt).toBe(161000000);
    });

    it('should evaluate Leverage correctly', () => {
      // Leverage = TotalDebt / EBITDA = 161M / 44.7M ≈ 3.60
      const leverage = interpreter['evaluate']('Leverage');
      expect(leverage).toBeCloseTo(3.60, 1);
    });
  });

  describe('Covenant Checking', () => {
    it('should check MaxLeverage covenant', () => {
      const result = interpreter.checkCovenant('MaxLeverage');
      expect(result.compliant).toBe(true);
      expect(result.actual).toBeCloseTo(3.60, 1);
      expect(result.threshold).toBe(4.50);
      expect(result.headroom).toBeCloseTo(0.90, 1);
    });

    it('should check MinLiquidity covenant', () => {
      const result = interpreter.checkCovenant('MinLiquidity');
      expect(result.compliant).toBe(true);
      expect(result.actual).toBe(28400000);
      expect(result.threshold).toBe(15000000);
    });

    it('should return all covenants', () => {
      const results = interpreter.checkAllCovenants();
      expect(results.length).toBe(2);
    });
  });

  describe('Basket Operations', () => {
    it('should calculate basket capacity', () => {
      const capacity = interpreter.getBasketCapacity('GeneralInvestments');
      expect(capacity).toBe(25000000);
    });

    it('should calculate GreaterOf basket capacity', () => {
      // GreaterOf($10M, 5% * $340M) = GreaterOf($10M, $17M) = $17M
      const capacity = interpreter.getBasketCapacity('RestrictedPayments');
      expect(capacity).toBe(17000000);
    });

    it('should track basket utilization', () => {
      const initialAvailable = interpreter.getBasketAvailable('GeneralInvestments');
      expect(initialAvailable).toBe(25000000);

      interpreter.useBasket('GeneralInvestments', 5000000, 'Test investment');
      
      const afterUse = interpreter.getBasketAvailable('GeneralInvestments');
      expect(afterUse).toBe(20000000);
    });

    it('should prevent over-utilization', () => {
      expect(() => {
        interpreter.useBasket('GeneralInvestments', 30000000, 'Too much');
      }).toThrow(/Insufficient basket capacity/);
    });
  });

  describe('Condition Evaluation', () => {
    it('should evaluate NoDefault condition (no defaults)', () => {
      const result = interpreter.evaluateBoolean('NoDefault');
      expect(result).toBe(true);
    });

    it('should evaluate NoDefault condition (with default)', () => {
      interpreter.setEventDefault('EventOfDefault');
      const result = interpreter.evaluateBoolean('NoDefault');
      expect(result).toBe(false);
    });
  });

  describe('Prohibition Checking', () => {
    it('should permit investment within basket', () => {
      const result = interpreter.checkProhibition('Investments', 10000000);
      expect(result.permitted).toBe(true);
    });

    it('should prohibit investment exceeding basket', () => {
      const result = interpreter.checkProhibition('Investments', 30000000);
      expect(result.permitted).toBe(false);
    });

    it('should prohibit investment when in default', () => {
      interpreter.setEventDefault('EventOfDefault');
      const result = interpreter.checkProhibition('Investments', 10000000);
      expect(result.permitted).toBe(false);
    });
  });

  describe('Simulation', () => {
    it('should simulate pro forma changes', () => {
      // Add $50M debt and see if still compliant
      const result = interpreter.simulate({ funded_debt: 206000000 });
      
      const maxLeverage = result.covenants.find(c => c.name === 'MaxLeverage');
      expect(maxLeverage).toBeDefined();
      // New leverage = (206M + 5M) / 44.7M = 4.72x > 4.50x
      expect(maxLeverage!.compliant).toBe(false);
    });

    it('should not modify original state', () => {
      const originalLeverage = interpreter.checkCovenant('MaxLeverage');
      interpreter.simulate({ funded_debt: 500000000 });
      const afterSimLeverage = interpreter.checkCovenant('MaxLeverage');
      
      expect(afterSimLeverage.actual).toBe(originalLeverage.actual);
    });
  });
});

// ==================== GROWER/BUILDER BASKET TESTS ====================

describe('Grower Baskets', () => {
  it('should parse FLOOR clause', async () => {
    const source = `
      BASKET EBITDABasket
        CAPACITY 10% * EBITDA
        FLOOR $5_000_000
    `;
    const ast = await parseOrThrow(source);
    const basket = ast.statements.find(s => s.type === 'Basket') as any;
    expect(basket.floor).toBeDefined();
    expect(basket.floor.value).toBe(5000000);
  });

  it('should calculate grower basket capacity', async () => {
    const source = `
      DEFINE EBITDA AS net_income

      BASKET EBITDABasket
        CAPACITY 10% * EBITDA
    `;
    const ast = await parseOrThrow(source);
    const interpreter = new CreditLangInterpreter(ast);
    interpreter.loadFinancials({ net_income: 50000000 });

    // 10% of $50M = $5M
    const capacity = interpreter.getBasketCapacity('EBITDABasket');
    expect(capacity).toBe(5000000);
  });

  it('should apply floor when capacity is below minimum', async () => {
    const source = `
      DEFINE EBITDA AS net_income

      BASKET EBITDABasket
        CAPACITY 10% * EBITDA
        FLOOR $10_000_000
    `;
    const ast = await parseOrThrow(source);
    const interpreter = new CreditLangInterpreter(ast);
    interpreter.loadFinancials({ net_income: 50000000 });

    // 10% of $50M = $5M, but floor is $10M
    const capacity = interpreter.getBasketCapacity('EBITDABasket');
    expect(capacity).toBe(10000000);
  });

  it('should not apply floor when capacity exceeds minimum', async () => {
    const source = `
      DEFINE EBITDA AS net_income

      BASKET EBITDABasket
        CAPACITY 10% * EBITDA
        FLOOR $2_000_000
    `;
    const ast = await parseOrThrow(source);
    const interpreter = new CreditLangInterpreter(ast);
    interpreter.loadFinancials({ net_income: 50000000 });

    // 10% of $50M = $5M > floor of $2M
    const capacity = interpreter.getBasketCapacity('EBITDABasket');
    expect(capacity).toBe(5000000);
  });

  it('should report grower basket status with details', async () => {
    const source = `
      DEFINE EBITDA AS net_income

      BASKET EBITDABasket
        CAPACITY 10% * EBITDA
        FLOOR $10_000_000
    `;
    const ast = await parseOrThrow(source);
    const interpreter = new CreditLangInterpreter(ast);
    interpreter.loadFinancials({ net_income: 50000000 });

    const status = interpreter.getBasketStatus('EBITDABasket');
    expect(status.basketType).toBe('grower');
    expect(status.baseCapacity).toBe(5000000);
    expect(status.floor).toBe(10000000);
    expect(status.capacity).toBe(10000000);
  });

  it('should identify grower baskets', async () => {
    const source = `
      BASKET Fixed CAPACITY $10_000_000

      BASKET Grower
        CAPACITY 10% * total_assets
        FLOOR $5_000_000
    `;
    const ast = await parseOrThrow(source);
    const interpreter = new CreditLangInterpreter(ast);
    interpreter.loadFinancials({ total_assets: 100000000 });

    const growerNames = interpreter.getGrowerBasketNames();
    expect(growerNames).toContain('Grower');
    expect(growerNames).not.toContain('Fixed');
  });
});

describe('Builder Baskets', () => {
  it('should parse BUILDS_FROM clause', async () => {
    const source = `
      BASKET RetainedEarnings
        BUILDS_FROM 50% * net_income
        STARTING $10_000_000
    `;
    const ast = await parseOrThrow(source);
    const basket = ast.statements.find(s => s.type === 'Basket') as any;
    expect(basket.buildsFrom).toBeDefined();
    expect(basket.starting).toBeDefined();
    expect(basket.starting.value).toBe(10000000);
  });

  it('should parse MAXIMUM clause', async () => {
    const source = `
      BASKET RetainedEarnings
        BUILDS_FROM 50% * net_income
        STARTING $10_000_000
        MAXIMUM $50_000_000
    `;
    const ast = await parseOrThrow(source);
    const basket = ast.statements.find(s => s.type === 'Basket') as any;
    expect(basket.maximum).toBeDefined();
    expect(basket.maximum.value).toBe(50000000);
  });

  it('should start with initial capacity', async () => {
    const source = `
      BASKET RetainedEarnings
        BUILDS_FROM 50% * net_income
        STARTING $10_000_000
    `;
    const ast = await parseOrThrow(source);
    const interpreter = new CreditLangInterpreter(ast);
    interpreter.loadFinancials({ net_income: 5000000 });

    const capacity = interpreter.getBasketCapacity('RetainedEarnings');
    expect(capacity).toBe(10000000);
  });

  it('should accumulate capacity over time', async () => {
    const source = `
      BASKET RetainedEarnings
        BUILDS_FROM 50% * net_income
        STARTING $10_000_000
    `;
    const ast = await parseOrThrow(source);
    const interpreter = new CreditLangInterpreter(ast);
    interpreter.loadFinancials({ net_income: 8000000 });

    // Initial capacity
    expect(interpreter.getBasketCapacity('RetainedEarnings')).toBe(10000000);

    // Accumulate Q1 earnings (50% of $8M = $4M)
    const accumulated = interpreter.accumulateBuilderBasket('RetainedEarnings', 'Q1 2024 earnings');
    expect(accumulated).toBe(4000000);

    // New capacity = $10M + $4M = $14M
    expect(interpreter.getBasketCapacity('RetainedEarnings')).toBe(14000000);

    // Accumulate Q2 earnings
    interpreter.accumulateBuilderBasket('RetainedEarnings', 'Q2 2024 earnings');
    expect(interpreter.getBasketCapacity('RetainedEarnings')).toBe(18000000);
  });

  it('should respect maximum cap', async () => {
    const source = `
      BASKET RetainedEarnings
        BUILDS_FROM 50% * net_income
        STARTING $10_000_000
        MAXIMUM $15_000_000
    `;
    const ast = await parseOrThrow(source);
    const interpreter = new CreditLangInterpreter(ast);
    interpreter.loadFinancials({ net_income: 20000000 });

    // Accumulate (50% of $20M = $10M), but max is $15M
    interpreter.accumulateBuilderBasket('RetainedEarnings', 'Q1 2024 earnings');

    // Should be capped at $15M
    expect(interpreter.getBasketCapacity('RetainedEarnings')).toBe(15000000);

    // Further accumulation should not increase capacity
    interpreter.accumulateBuilderBasket('RetainedEarnings', 'Q2 2024 earnings');
    expect(interpreter.getBasketCapacity('RetainedEarnings')).toBe(15000000);
  });

  it('should report builder basket status with details', async () => {
    const source = `
      BASKET RetainedEarnings
        BUILDS_FROM 50% * net_income
        STARTING $10_000_000
        MAXIMUM $50_000_000
    `;
    const ast = await parseOrThrow(source);
    const interpreter = new CreditLangInterpreter(ast);
    interpreter.loadFinancials({ net_income: 8000000 });

    interpreter.accumulateBuilderBasket('RetainedEarnings', 'Q1 earnings');

    const status = interpreter.getBasketStatus('RetainedEarnings');
    expect(status.basketType).toBe('builder');
    expect(status.accumulated).toBe(4000000);
    expect(status.maximum).toBe(50000000);
    expect(status.capacity).toBe(14000000);
  });

  it('should track accumulation in ledger', async () => {
    const source = `
      BASKET RetainedEarnings
        BUILDS_FROM 50% * net_income
        STARTING $10_000_000
    `;
    const ast = await parseOrThrow(source);
    const interpreter = new CreditLangInterpreter(ast);
    interpreter.loadFinancials({ net_income: 8000000 });

    interpreter.accumulateBuilderBasket('RetainedEarnings', 'Q1 2024 earnings');
    interpreter.useBasket('RetainedEarnings', 5000000, 'Investment');

    const ledger = interpreter.getBasketLedger();
    expect(ledger.length).toBe(2);
    expect(ledger[0].entryType).toBe('accumulation');
    expect(ledger[0].amount).toBe(4000000);
    expect(ledger[1].entryType).toBe('usage');
    expect(ledger[1].amount).toBe(5000000);
  });

  it('should identify builder baskets', async () => {
    const source = `
      BASKET Fixed CAPACITY $10_000_000

      BASKET Builder
        BUILDS_FROM 50% * net_income
        STARTING $5_000_000
    `;
    const ast = await parseOrThrow(source);
    const interpreter = new CreditLangInterpreter(ast);
    interpreter.loadFinancials({ net_income: 5000000 });

    const builderNames = interpreter.getBuilderBasketNames();
    expect(builderNames).toContain('Builder');
    expect(builderNames).not.toContain('Fixed');
  });

  it('should throw error when accumulating non-builder basket', async () => {
    const source = `
      BASKET Fixed CAPACITY $10_000_000
    `;
    const ast = await parseOrThrow(source);
    const interpreter = new CreditLangInterpreter(ast);

    expect(() => {
      interpreter.accumulateBuilderBasket('Fixed', 'Test');
    }).toThrow(/not a builder basket/);
  });
});

// ==================== INTEGRATION TESTS ====================

describe('Integration', () => {
  it('should handle a complete credit agreement', async () => {
    const source = `
      // Sample Corporate Credit Agreement
      
      DEFINE EBITDA AS
        net_income + interest_expense + tax_expense + depreciation + amortization
      
      DEFINE TotalDebt AS
        funded_debt + capital_leases
      
      DEFINE Leverage AS
        TotalDebt / EBITDA
      
      COVENANT MaxLeverage
        REQUIRES Leverage <= 4.50
        TESTED QUARTERLY
      
      COVENANT MinInterestCoverage
        REQUIRES EBITDA / interest_expense >= 2.50
        TESTED QUARTERLY
      
      BASKET GeneralInvestments
        CAPACITY $25_000_000
      
      CONDITION NoDefault AS
        NOT EXISTS(EventOfDefault)
      
      CONDITION ProFormaCompliance AS
        COMPLIANT(MaxLeverage) AND COMPLIANT(MinInterestCoverage)
      
      PROHIBIT Investments
        EXCEPT WHEN
          | amount <= AVAILABLE(GeneralInvestments)
          | AND NoDefault
    `;

    const ast = await parseOrThrow(source);
    const interpreter = new CreditLangInterpreter(ast);
    
    interpreter.loadFinancials({
      net_income: 22000000,
      interest_expense: 8200000,
      tax_expense: 7500000,
      depreciation: 4800000,
      amortization: 2200000,
      funded_debt: 156000000,
      capital_leases: 5000000,
      cash: 28400000,
      total_assets: 340000000,
    });

    const status = interpreter.getStatus();
    
    expect(status.overallCompliant).toBe(true);
    expect(status.covenants.length).toBe(2);
    expect(status.baskets.length).toBe(1);
    
    // Check ProFormaCompliance condition
    expect(interpreter.evaluateBoolean('ProFormaCompliance')).toBe(true);
    
    // Test prohibition
    const queryResult = interpreter.checkProhibition('Investments', 10000000);
    expect(queryResult.permitted).toBe(true);
  });
});

// ==================== PARSE ERROR TESTS ====================

describe('Parse Errors', () => {
  it('should return error with location for unknown keyword', async () => {
    const source = 'COVENAT MaxLeverage REQUIRES Leverage <= 4.5';
    const result = await parse(source);

    expect(result.success).toBe(false);
    expect(result.error).toBeDefined();
    expect(result.error?.location).toBeDefined();
    expect(result.error?.location?.start.line).toBe(1);
    expect(result.error?.location?.start.column).toBe(1);
  });

  it('should capture expected tokens', async () => {
    const source = 'COVENAT MaxLeverage';
    const result = await parse(source);

    expect(result.success).toBe(false);
    expect(result.error?.expected).toBeDefined();
    expect(result.error?.expected?.length).toBeGreaterThan(0);
  });

  it('should capture what was found', async () => {
    const source = 'COVENAT MaxLeverage';
    const result = await parse(source);

    expect(result.success).toBe(false);
    // Peggy reports the first character as "found"
    expect(result.error?.found).toBeDefined();
  });

  it('should include source in result for context display', async () => {
    const source = 'INVALID SYNTAX HERE';
    const result = await parse(source);

    expect(result.success).toBe(false);
    expect(result.source).toBe(source);
  });

  it('should provide location for mid-file errors', async () => {
    const source = `
DEFINE EBITDA AS 100

COVENAT MaxLeverage REQUIRES x > 1
`;
    const result = await parse(source);

    expect(result.success).toBe(false);
    expect(result.error?.location?.start.line).toBe(4);
  });

  it('should provide location for expression errors', async () => {
    const source = `
DEFINE EBITDA AS
  net_income + + interest
`;
    const result = await parse(source);

    expect(result.success).toBe(false);
    expect(result.error?.location).toBeDefined();
  });

  it('should have expected list include valid keywords', async () => {
    const source = 'BADKEYWORD Test';
    const result = await parse(source);

    expect(result.success).toBe(false);
    // Expected should include valid top-level keywords
    const expectedLower = result.error?.expected?.map(e => e.toLowerCase()) ?? [];
    const hasValidKeyword = expectedLower.some(e =>
      e.includes('define') || e.includes('covenant') || e.includes('basket')
    );
    expect(hasValidKeyword).toBe(true);
  });
});

// ==================== SEMANTIC VALIDATION TESTS ====================

import { validate } from '../src/validator.js';

describe('Semantic Validation', () => {
  it('should pass for valid program', async () => {
    const source = `
      DEFINE EBITDA AS net_income
      COVENANT MaxLeverage REQUIRES EBITDA > 0
      BASKET GeneralInvestments CAPACITY $25_000_000
      CONDITION NoDefault AS COMPLIANT(MaxLeverage)
    `;
    const ast = await parseOrThrow(source);
    const result = validate(ast);

    expect(result.valid).toBe(true);
    expect(result.errors.length).toBe(0);
  });

  it('should error on undefined basket in AVAILABLE()', async () => {
    const source = `
      PROHIBIT Investments
        EXCEPT WHEN
          | amount <= AVAILABLE(NonExistentBasket)
    `;
    const ast = await parseOrThrow(source);
    const result = validate(ast);

    expect(result.valid).toBe(false);
    expect(result.errors.length).toBe(1);
    expect(result.errors[0]!.message).toContain('NonExistentBasket');
    expect(result.errors[0]!.expectedType).toBe('basket');
  });

  it('should error on undefined covenant in COMPLIANT()', async () => {
    const source = `
      CONDITION Test AS
        COMPLIANT(NonExistentCovenant)
    `;
    const ast = await parseOrThrow(source);
    const result = validate(ast);

    expect(result.valid).toBe(false);
    expect(result.errors.length).toBe(1);
    expect(result.errors[0]!.message).toContain('NonExistentCovenant');
    expect(result.errors[0]!.expectedType).toBe('covenant');
  });

  it('should error on undefined condition in SUBJECT TO', async () => {
    const source = `
      BASKET Test
        CAPACITY $1_000_000
        SUBJECT TO UndefinedCondition
    `;
    const ast = await parseOrThrow(source);
    const result = validate(ast);

    expect(result.valid).toBe(false);
    expect(result.errors.length).toBe(1);
    expect(result.errors[0]!.message).toContain('UndefinedCondition');
    expect(result.errors[0]!.expectedType).toBe('condition');
  });

  it('should warn on undefined identifier (possible financial data)', async () => {
    const source = `
      DEFINE Test AS undefined_field
    `;
    const ast = await parseOrThrow(source);
    const result = validate(ast);

    // Not an error because it might be financial data
    expect(result.valid).toBe(true);
    expect(result.errors.length).toBe(0);
    expect(result.warnings.length).toBeGreaterThan(0);
    expect(result.warnings[0]!.message).toContain('undefined_field');
  });

  it('should resolve references to defined terms', async () => {
    const source = `
      DEFINE EBITDA AS net_income
      DEFINE Leverage AS total_debt / EBITDA
    `;
    const ast = await parseOrThrow(source);
    const result = validate(ast);

    // EBITDA reference in Leverage should be resolved
    // Only net_income and total_debt should generate warnings
    expect(result.valid).toBe(true);
    expect(result.errors.length).toBe(0);
    const warningMessages = result.warnings.map(w => w.reference);
    expect(warningMessages).toContain('net_income');
    expect(warningMessages).toContain('total_debt');
    expect(warningMessages).not.toContain('EBITDA');
  });

  // Note: Unknown functions are caught at parse time by the grammar
  // which only allows specific function names. No semantic validation test needed.

  it('should validate GreaterOf arguments', async () => {
    const source = `
      BASKET Test
        CAPACITY GreaterOf($1_000_000, 5% * EBITDA)
    `;
    const ast = await parseOrThrow(source);
    const result = validate(ast);

    // EBITDA is undefined, so there should be a warning
    expect(result.valid).toBe(true);
    expect(result.warnings.length).toBeGreaterThan(0);
    expect(result.warnings.some(w => w.reference === 'EBITDA')).toBe(true);
  });

  it('should allow amount in PROHIBIT EXCEPT WHEN context', async () => {
    const source = `
      BASKET TestBasket CAPACITY $1_000_000
      PROHIBIT TestAction
        EXCEPT WHEN
          | amount <= AVAILABLE(TestBasket)
    `;
    const ast = await parseOrThrow(source);
    const result = validate(ast);

    // amount is a special binding, should not generate warning
    expect(result.valid).toBe(true);
    expect(result.warnings.some(w => w.reference === 'amount')).toBe(false);
  });

  it('should warn on EXISTS() with undefined event', async () => {
    const source = `
      CONDITION Test AS EXISTS(UndefinedEvent)
    `;
    const ast = await parseOrThrow(source);
    const result = validate(ast);

    // EXISTS with undefined event is a warning (might be runtime state)
    expect(result.valid).toBe(true);
    expect(result.warnings.length).toBe(1);
    expect(result.warnings[0]!.reference).toBe('UndefinedEvent');
    expect(result.warnings[0]!.expectedType).toBe('event');
  });

  it('should not warn on EXISTS() with defined event', async () => {
    const source = `
      EVENT TestEvent TRIGGERS WHEN x > 0
      CONDITION Test AS EXISTS(TestEvent)
    `;
    const ast = await parseOrThrow(source);
    const result = validate(ast);

    // EXISTS with defined event should not generate warnings for the event
    const existsWarnings = result.warnings.filter(w => w.reference === 'TestEvent');
    expect(existsWarnings.length).toBe(0);
  });

  it('should validate complex expressions', async () => {
    const source = `
      BASKET TestBasket CAPACITY $1_000_000
      COVENANT MaxLev REQUIRES x <= 4.5
      CONDITION NoDefault AS COMPLIANT(MaxLev)
      PROHIBIT Dividends
        EXCEPT WHEN
          | amount <= AVAILABLE(TestBasket)
          | AND NoDefault
    `;
    const ast = await parseOrThrow(source);
    const result = validate(ast);

    expect(result.valid).toBe(true);
    expect(result.errors.length).toBe(0);
    // Only x should generate a warning (undefined financial data)
    const warningRefs = result.warnings.map(w => w.reference);
    expect(warningRefs).toContain('x');
    expect(warningRefs).not.toContain('NoDefault');
    expect(warningRefs).not.toContain('MaxLev');
    expect(warningRefs).not.toContain('TestBasket');
  });

  it('should validate EXCLUDING items', async () => {
    const source = `
      DEFINE EBITDA AS net_income
        EXCLUDING extraordinary_items
    `;
    const ast = await parseOrThrow(source);
    const result = validate(ast);

    expect(result.valid).toBe(true);
    // extraordinary_items is not defined, should warn
    const excludingWarning = result.warnings.find(w => w.reference === 'extraordinary_items');
    expect(excludingWarning).toBeDefined();
    expect(excludingWarning!.context).toContain('DEFINE EBITDA');
  });

  it('should validate builder basket BUILDS_FROM expressions', async () => {
    const source = `
      DEFINE NetIncome AS revenue - expenses
      BASKET RetainedEarnings
        BUILDS_FROM 50% * NetIncome
        STARTING $10_000_000
        MAXIMUM $75_000_000
    `;
    const ast = await parseOrThrow(source);
    const result = validate(ast);

    expect(result.valid).toBe(true);
    // NetIncome reference should be resolved (no warning)
    const netIncomeWarning = result.warnings.find(w => w.reference === 'NetIncome');
    expect(netIncomeWarning).toBeUndefined();
    // revenue and expenses should have warnings
    expect(result.warnings.some(w => w.reference === 'revenue')).toBe(true);
    expect(result.warnings.some(w => w.reference === 'expenses')).toBe(true);
  });

  it('should validate grower basket FLOOR expressions', async () => {
    const source = `
      BASKET Test
        CAPACITY 10% * undefined_metric
        FLOOR $5_000_000
    `;
    const ast = await parseOrThrow(source);
    const result = validate(ast);

    expect(result.valid).toBe(true);
    expect(result.warnings.some(w => w.reference === 'undefined_metric')).toBe(true);
  });
});

// ==================== BASKET LEDGER TESTS ====================

describe('Basket Ledger', () => {
  it('should return empty ledger initially', async () => {
    const source = `
      BASKET TestBasket CAPACITY $10_000_000
    `;
    const ast = await parseOrThrow(source);
    const interpreter = new CreditLangInterpreter(ast);

    const ledger = interpreter.getBasketLedger();
    expect(ledger.length).toBe(0);
  });

  it('should record usage entries in ledger', async () => {
    const source = `
      BASKET TestBasket CAPACITY $10_000_000
    `;
    const ast = await parseOrThrow(source);
    const interpreter = new CreditLangInterpreter(ast);

    interpreter.useBasket('TestBasket', 5000000, 'Q1 Investment');

    const ledger = interpreter.getBasketLedger();
    expect(ledger.length).toBe(1);
    expect(ledger[0]!.basket).toBe('TestBasket');
    expect(ledger[0]!.amount).toBe(5000000);
    expect(ledger[0]!.entryType).toBe('usage');
    expect(ledger[0]!.description).toBe('Q1 Investment');
  });

  it('should record accumulation entries in ledger', async () => {
    const source = `
      BASKET Builder
        BUILDS_FROM 50% * net_income
        STARTING $1_000_000
    `;
    const ast = await parseOrThrow(source);
    const interpreter = new CreditLangInterpreter(ast);
    interpreter.loadFinancials({ net_income: 10000000 });

    interpreter.accumulateBuilderBasket('Builder', 'Q1 2024 earnings');

    const ledger = interpreter.getBasketLedger();
    expect(ledger.length).toBe(1);
    expect(ledger[0]!.basket).toBe('Builder');
    expect(ledger[0]!.amount).toBe(5000000);
    expect(ledger[0]!.entryType).toBe('accumulation');
  });

  it('should track multiple entries in order', async () => {
    const source = `
      BASKET Builder
        BUILDS_FROM 50% * net_income
        STARTING $5_000_000
    `;
    const ast = await parseOrThrow(source);
    const interpreter = new CreditLangInterpreter(ast);
    interpreter.loadFinancials({ net_income: 4000000 });

    interpreter.accumulateBuilderBasket('Builder', 'Q1 earnings');
    interpreter.useBasket('Builder', 3000000, 'Investment A');
    interpreter.accumulateBuilderBasket('Builder', 'Q2 earnings');
    interpreter.useBasket('Builder', 2000000, 'Investment B');

    const ledger = interpreter.getBasketLedger();
    expect(ledger.length).toBe(4);
    expect(ledger[0]!.entryType).toBe('accumulation');
    expect(ledger[1]!.entryType).toBe('usage');
    expect(ledger[2]!.entryType).toBe('accumulation');
    expect(ledger[3]!.entryType).toBe('usage');
  });

  it('should include timestamps in ledger entries', async () => {
    const source = `
      BASKET TestBasket CAPACITY $10_000_000
    `;
    const ast = await parseOrThrow(source);
    const interpreter = new CreditLangInterpreter(ast);

    const before = new Date();
    interpreter.useBasket('TestBasket', 1000000, 'Test');
    const after = new Date();

    const ledger = interpreter.getBasketLedger();
    expect(ledger[0]!.timestamp.getTime()).toBeGreaterThanOrEqual(before.getTime());
    expect(ledger[0]!.timestamp.getTime()).toBeLessThanOrEqual(after.getTime());
  });
});

// ==================== CURE RIGHTS TESTS ====================

describe('Cure Rights', () => {
  describe('Grammar', () => {
    it('should parse CURE clause with MAX_USES', async () => {
      const source = `
        COVENANT MaxLeverage
          REQUIRES Leverage <= 4.50
          TESTED QUARTERLY
          CURE EquityCure MAX_USES 3 OVER life_of_facility
      `;
      const ast = await parseOrThrow(source);
      const covenant = ast.statements.find(s => s.type === 'Covenant') as any;

      expect(covenant.cure).toBeDefined();
      expect(covenant.cure.type).toBe('EquityCure');
      expect(covenant.cure.details.maxUses).toBe(3);
      expect(covenant.cure.details.overPeriod).toBe('life_of_facility');
    });

    it('should parse CURE clause with MAX_AMOUNT', async () => {
      const source = `
        COVENANT MaxLeverage
          REQUIRES Leverage <= 4.50
          CURE EquityCure MAX_AMOUNT $20_000_000
      `;
      const ast = await parseOrThrow(source);
      const covenant = ast.statements.find(s => s.type === 'Covenant') as any;

      expect(covenant.cure.details.maxAmount).toBeDefined();
      expect(covenant.cure.details.maxAmount.value).toBe(20000000);
    });

    it('should parse CURE clause with CURE_PERIOD', async () => {
      const source = `
        COVENANT MaxLeverage
          REQUIRES Leverage <= 4.50
          CURE EquityCure CURE_PERIOD 30 DAYS
      `;
      const ast = await parseOrThrow(source);
      const covenant = ast.statements.find(s => s.type === 'Covenant') as any;

      expect(covenant.cure.details.curePeriod).toBeDefined();
      expect(covenant.cure.details.curePeriod.amount).toBe(30);
      expect(covenant.cure.details.curePeriod.unit).toBe('days');
    });

    it('should parse combined CURE clauses', async () => {
      const source = `
        COVENANT MaxLeverage
          REQUIRES Leverage <= 4.50
          CURE EquityCure MAX_USES 3 OVER life_of_facility MAX_AMOUNT $20_000_000
      `;
      const ast = await parseOrThrow(source);
      const covenant = ast.statements.find(s => s.type === 'Covenant') as any;

      expect(covenant.cure.details.maxUses).toBe(3);
      expect(covenant.cure.details.maxAmount.value).toBe(20000000);
    });

    it('should parse PaymentCure mechanism', async () => {
      const source = `
        COVENANT MinCoverage
          REQUIRES coverage >= 1.25
          CURE PaymentCure MAX_USES 2 OVER life_of_facility
      `;
      const ast = await parseOrThrow(source);
      const covenant = ast.statements.find(s => s.type === 'Covenant') as any;

      expect(covenant.cure.type).toBe('PaymentCure');
    });
  });

  describe('Interpreter', () => {
    it('should check cure availability when compliant', async () => {
      const source = `
        DEFINE Leverage AS total_debt / ebitda
        COVENANT MaxLeverage
          REQUIRES Leverage <= 4.50
          CURE EquityCure MAX_USES 3 OVER life_of_facility
      `;
      const ast = await parseOrThrow(source);
      const interpreter = new CreditLangInterpreter(ast);
      interpreter.loadFinancials({ total_debt: 90000000, ebitda: 30000000 }); // 3x leverage

      const result = interpreter.checkCovenantWithCure('MaxLeverage');
      expect(result.compliant).toBe(true);
      expect(result.cureAvailable).toBeUndefined(); // Not needed when compliant
    });

    it('should check cure availability when breached', async () => {
      const source = `
        DEFINE Leverage AS total_debt / ebitda
        COVENANT MaxLeverage
          REQUIRES Leverage <= 4.50
          CURE EquityCure MAX_USES 3 OVER life_of_facility
      `;
      const ast = await parseOrThrow(source);
      const interpreter = new CreditLangInterpreter(ast);
      interpreter.loadFinancials({ total_debt: 150000000, ebitda: 30000000 }); // 5x leverage

      const result = interpreter.checkCovenantWithCure('MaxLeverage');
      expect(result.compliant).toBe(false);
      expect(result.cureAvailable).toBe(true);
      expect(result.shortfall).toBeCloseTo(0.5, 1); // 5x - 4.5x = 0.5x shortfall
    });

    it('should apply equity cure successfully', async () => {
      const source = `
        DEFINE Leverage AS total_debt / ebitda
        COVENANT MaxLeverage
          REQUIRES Leverage <= 4.50
          CURE EquityCure MAX_USES 3 OVER life_of_facility
      `;
      const ast = await parseOrThrow(source);
      const interpreter = new CreditLangInterpreter(ast);
      interpreter.loadFinancials({ total_debt: 150000000, ebitda: 30000000 }); // 5x leverage

      const result = interpreter.applyCure('MaxLeverage', 10000000);
      expect(result.success).toBe(true);
    });

    it('should reject cure when uses exhausted', async () => {
      const source = `
        DEFINE Leverage AS total_debt / ebitda
        COVENANT MaxLeverage
          REQUIRES Leverage <= 4.50
          CURE EquityCure MAX_USES 2 OVER life_of_facility
      `;
      const ast = await parseOrThrow(source);
      const interpreter = new CreditLangInterpreter(ast);
      interpreter.loadFinancials({ total_debt: 150000000, ebitda: 30000000 });

      // Use both cures
      interpreter.applyCure('MaxLeverage', 10000000);
      interpreter.applyCure('MaxLeverage', 10000000);

      // Third should fail
      const result = interpreter.applyCure('MaxLeverage', 10000000);
      expect(result.success).toBe(false);
      expect(result.reason).toContain('No cure uses remaining');
    });

    it('should reject cure when amount exceeds max', async () => {
      const source = `
        DEFINE Leverage AS total_debt / ebitda
        COVENANT MaxLeverage
          REQUIRES Leverage <= 4.50
          CURE EquityCure MAX_AMOUNT $5_000_000
      `;
      const ast = await parseOrThrow(source);
      const interpreter = new CreditLangInterpreter(ast);
      interpreter.loadFinancials({ total_debt: 150000000, ebitda: 30000000 });

      const result = interpreter.applyCure('MaxLeverage', 10000000);
      expect(result.success).toBe(false);
      expect(result.reason).toContain('exceeds maximum cure');
    });

    it('should calculate shortfall for leverage covenant', async () => {
      const source = `
        DEFINE Leverage AS total_debt / ebitda
        COVENANT MaxLeverage
          REQUIRES Leverage <= 4.00
          CURE EquityCure
      `;
      const ast = await parseOrThrow(source);
      const interpreter = new CreditLangInterpreter(ast);
      interpreter.loadFinancials({ total_debt: 150000000, ebitda: 30000000 }); // 5x

      const result = interpreter.checkCovenantWithCure('MaxLeverage');
      expect(result.shortfall).toBeCloseTo(1.0, 1); // 5x - 4x = 1x shortfall
    });

    it('should calculate shortfall for coverage covenant', async () => {
      const source = `
        DEFINE Coverage AS ebitda / interest
        COVENANT MinCoverage
          REQUIRES Coverage >= 2.50
          CURE PaymentCure
      `;
      const ast = await parseOrThrow(source);
      const interpreter = new CreditLangInterpreter(ast);
      interpreter.loadFinancials({ ebitda: 20000000, interest: 10000000 }); // 2x

      const result = interpreter.checkCovenantWithCure('MinCoverage');
      expect(result.shortfall).toBeCloseTo(0.5, 1); // 2.5x - 2x = 0.5x shortfall
    });

    it('should track cure usage across multiple cures', async () => {
      const source = `
        DEFINE Leverage AS total_debt / ebitda
        COVENANT MaxLeverage
          REQUIRES Leverage <= 4.50
          CURE EquityCure MAX_USES 5 OVER life_of_facility
      `;
      const ast = await parseOrThrow(source);
      const interpreter = new CreditLangInterpreter(ast);
      interpreter.loadFinancials({ total_debt: 150000000, ebitda: 30000000 });

      interpreter.applyCure('MaxLeverage', 10000000);
      interpreter.applyCure('MaxLeverage', 10000000);

      const usage = interpreter.getCureUsage();
      expect(usage.length).toBe(1);
      expect(usage[0]!.mechanism).toBe('EquityCure');
      expect(usage[0]!.totalUses).toBe(2);
      expect(usage[0]!.usesRemaining).toBe(3);
    });

    it('should reject cure on compliant covenant', async () => {
      const source = `
        DEFINE Leverage AS total_debt / ebitda
        COVENANT MaxLeverage
          REQUIRES Leverage <= 4.50
          CURE EquityCure
      `;
      const ast = await parseOrThrow(source);
      const interpreter = new CreditLangInterpreter(ast);
      interpreter.loadFinancials({ total_debt: 90000000, ebitda: 30000000 }); // 3x

      const result = interpreter.applyCure('MaxLeverage', 10000000);
      expect(result.success).toBe(false);
      expect(result.reason).toContain('already compliant');
    });

    it('should identify covenants with cure mechanisms', async () => {
      const source = `
        COVENANT WithCure
          REQUIRES x <= 5
          CURE EquityCure

        COVENANT WithoutCure
          REQUIRES y >= 1
      `;
      const ast = await parseOrThrow(source);
      const interpreter = new CreditLangInterpreter(ast);

      const withCure = interpreter.getCovenantsWithCure();
      expect(withCure).toContain('WithCure');
      expect(withCure).not.toContain('WithoutCure');
    });
  });
});

// ==================== AMENDMENT TESTS ====================

describe('Amendments', () => {
  describe('Grammar', () => {
    it('should parse basic AMENDMENT statement', async () => {
      const source = `
        AMENDMENT 1
          EFFECTIVE 2024-06-15
          DESCRIPTION "First Amendment"

          ADDS BASKET NewBasket
            CAPACITY $10_000_000
      `;
      const ast = await parseOrThrow(source);
      const amendment = ast.statements.find(s => s.type === 'Amendment') as any;

      expect(amendment).toBeDefined();
      expect(amendment.number).toBe(1);
      expect(amendment.effective.value).toBe('2024-06-15');
      expect(amendment.description).toBe('First Amendment');
      expect(amendment.directives.length).toBe(1);
    });

    it('should parse REPLACES directive', async () => {
      const source = `
        AMENDMENT 1
          REPLACES COVENANT MaxLeverage WITH
            COVENANT MaxLeverage
              REQUIRES Leverage <= 5.00
              TESTED QUARTERLY
      `;
      const ast = await parseOrThrow(source);
      const amendment = ast.statements.find(s => s.type === 'Amendment') as any;

      expect(amendment.directives[0].directive).toBe('replace');
      expect(amendment.directives[0].targetType).toBe('Covenant');
      expect(amendment.directives[0].targetName).toBe('MaxLeverage');
      expect(amendment.directives[0].replacement.type).toBe('Covenant');
    });

    it('should parse ADDS directive', async () => {
      const source = `
        AMENDMENT 1
          ADDS BASKET AdditionalInvestments
            CAPACITY $15_000_000
      `;
      const ast = await parseOrThrow(source);
      const amendment = ast.statements.find(s => s.type === 'Amendment') as any;

      expect(amendment.directives[0].directive).toBe('add');
      expect(amendment.directives[0].statement.type).toBe('Basket');
      expect(amendment.directives[0].statement.name).toBe('AdditionalInvestments');
    });

    it('should parse DELETES directive', async () => {
      const source = `
        AMENDMENT 1
          DELETES CONDITION OldCondition
      `;
      const ast = await parseOrThrow(source);
      const amendment = ast.statements.find(s => s.type === 'Amendment') as any;

      expect(amendment.directives[0].directive).toBe('delete');
      expect(amendment.directives[0].targetType).toBe('Condition');
      expect(amendment.directives[0].targetName).toBe('OldCondition');
    });

    it('should parse MODIFIES directive', async () => {
      const source = `
        AMENDMENT 1
          MODIFIES BASKET GeneralInvestments
            CAPACITY $35_000_000
      `;
      const ast = await parseOrThrow(source);
      const amendment = ast.statements.find(s => s.type === 'Amendment') as any;

      expect(amendment.directives[0].directive).toBe('modify');
      expect(amendment.directives[0].targetType).toBe('Basket');
      expect(amendment.directives[0].targetName).toBe('GeneralInvestments');
      expect(amendment.directives[0].modifications[0].type).toBe('capacity');
    });

    it('should parse multiple directives in one amendment', async () => {
      const source = `
        AMENDMENT 2
          EFFECTIVE 2024-09-01

          MODIFIES BASKET GeneralInvestments
            CAPACITY $40_000_000

          ADDS BASKET NewBasket
            CAPACITY $5_000_000

          DELETES CONDITION OldCondition
      `;
      const ast = await parseOrThrow(source);
      const amendment = ast.statements.find(s => s.type === 'Amendment') as any;

      expect(amendment.number).toBe(2);
      expect(amendment.directives.length).toBe(3);
      expect(amendment.directives[0].directive).toBe('modify');
      expect(amendment.directives[1].directive).toBe('add');
      expect(amendment.directives[2].directive).toBe('delete');
    });
  });

  describe('Interpreter', () => {
    it('should apply REPLACES directive', async () => {
      const source = `
        DEFINE Leverage AS total_debt / ebitda

        COVENANT MaxLeverage
          REQUIRES Leverage <= 4.50
          TESTED QUARTERLY
      `;
      const amendmentSource = `
        AMENDMENT 1
          REPLACES COVENANT MaxLeverage WITH
            COVENANT MaxLeverage
              REQUIRES Leverage <= 5.00
              TESTED QUARTERLY
      `;

      const ast = await parseOrThrow(source);
      const amendmentAst = await parseOrThrow(amendmentSource);
      const interpreter = new CreditLangInterpreter(ast);
      interpreter.loadFinancials({ total_debt: 230000000, ebitda: 50000000 }); // 4.6x leverage

      // Before amendment: breach (4.6x > 4.5x)
      let result = interpreter.checkCovenant('MaxLeverage');
      expect(result.compliant).toBe(false);

      // Apply amendment
      const amendment = amendmentAst.statements.find(s => s.type === 'Amendment') as any;
      interpreter.applyAmendment(amendment);

      // After amendment: compliant (4.6x <= 5.0x)
      result = interpreter.checkCovenant('MaxLeverage');
      expect(result.compliant).toBe(true);
      expect(result.threshold).toBe(5.0);
    });

    it('should apply ADDS directive', async () => {
      const source = `
        BASKET ExistingBasket
          CAPACITY $10_000_000
      `;
      const amendmentSource = `
        AMENDMENT 1
          ADDS BASKET NewBasket
            CAPACITY $15_000_000
      `;

      const ast = await parseOrThrow(source);
      const amendmentAst = await parseOrThrow(amendmentSource);
      const interpreter = new CreditLangInterpreter(ast);

      // Before amendment
      expect(interpreter.getBasketNames()).toContain('ExistingBasket');
      expect(interpreter.getBasketNames()).not.toContain('NewBasket');

      // Apply amendment
      const amendment = amendmentAst.statements.find(s => s.type === 'Amendment') as any;
      interpreter.applyAmendment(amendment);

      // After amendment
      expect(interpreter.getBasketNames()).toContain('NewBasket');
      expect(interpreter.getBasketCapacity('NewBasket')).toBe(15000000);
    });

    it('should apply DELETES directive', async () => {
      const source = `
        CONDITION OldCondition AS
          x > 0

        CONDITION KeepThis AS
          y > 0
      `;
      const amendmentSource = `
        AMENDMENT 1
          DELETES CONDITION OldCondition
      `;

      const ast = await parseOrThrow(source);
      const amendmentAst = await parseOrThrow(amendmentSource);
      const interpreter = new CreditLangInterpreter(ast);

      // Before
      expect(interpreter.getConditionNames()).toContain('OldCondition');
      expect(interpreter.getConditionNames()).toContain('KeepThis');

      // Apply
      const amendment = amendmentAst.statements.find(s => s.type === 'Amendment') as any;
      interpreter.applyAmendment(amendment);

      // After
      expect(interpreter.getConditionNames()).not.toContain('OldCondition');
      expect(interpreter.getConditionNames()).toContain('KeepThis');
    });

    it('should throw error on deleting non-existent statement', async () => {
      const source = `
        BASKET SomeBasket CAPACITY $10_000_000
      `;
      const amendmentSource = `
        AMENDMENT 1
          DELETES CONDITION NonExistent
      `;

      const ast = await parseOrThrow(source);
      const amendmentAst = await parseOrThrow(amendmentSource);
      const interpreter = new CreditLangInterpreter(ast);

      const amendment = amendmentAst.statements.find(s => s.type === 'Amendment') as any;
      expect(() => interpreter.applyAmendment(amendment)).toThrow(/not found/);
    });

    it('should apply MODIFIES directive to basket capacity', async () => {
      const source = `
        BASKET GeneralInvestments
          CAPACITY $25_000_000
      `;
      const amendmentSource = `
        AMENDMENT 1
          MODIFIES BASKET GeneralInvestments
            CAPACITY $35_000_000
      `;

      const ast = await parseOrThrow(source);
      const amendmentAst = await parseOrThrow(amendmentSource);
      const interpreter = new CreditLangInterpreter(ast);

      // Before
      expect(interpreter.getBasketCapacity('GeneralInvestments')).toBe(25000000);

      // Apply
      const amendment = amendmentAst.statements.find(s => s.type === 'Amendment') as any;
      interpreter.applyAmendment(amendment);

      // After
      expect(interpreter.getBasketCapacity('GeneralInvestments')).toBe(35000000);
    });

    it('should apply multiple amendments in order', async () => {
      const source = `
        BASKET TestBasket CAPACITY $10_000_000
      `;
      const amendment1Source = `
        AMENDMENT 1
          MODIFIES BASKET TestBasket
            CAPACITY $20_000_000
      `;
      const amendment2Source = `
        AMENDMENT 2
          MODIFIES BASKET TestBasket
            CAPACITY $30_000_000
      `;

      const ast = await parseOrThrow(source);
      const amendment1Ast = await parseOrThrow(amendment1Source);
      const amendment2Ast = await parseOrThrow(amendment2Source);
      const interpreter = new CreditLangInterpreter(ast);

      expect(interpreter.getBasketCapacity('TestBasket')).toBe(10000000);

      const amendment1 = amendment1Ast.statements.find(s => s.type === 'Amendment') as any;
      interpreter.applyAmendment(amendment1);
      expect(interpreter.getBasketCapacity('TestBasket')).toBe(20000000);

      const amendment2 = amendment2Ast.statements.find(s => s.type === 'Amendment') as any;
      interpreter.applyAmendment(amendment2);
      expect(interpreter.getBasketCapacity('TestBasket')).toBe(30000000);
    });

    it('should track applied amendments', async () => {
      const source = `
        BASKET TestBasket CAPACITY $10_000_000
      `;
      const amendmentSource = `
        AMENDMENT 1
          EFFECTIVE 2024-06-15
          DESCRIPTION "Capacity increase"
          MODIFIES BASKET TestBasket
            CAPACITY $20_000_000
      `;

      const ast = await parseOrThrow(source);
      const amendmentAst = await parseOrThrow(amendmentSource);
      const interpreter = new CreditLangInterpreter(ast);

      expect(interpreter.getAppliedAmendments().length).toBe(0);

      const amendment = amendmentAst.statements.find(s => s.type === 'Amendment') as any;
      interpreter.applyAmendment(amendment);

      const applied = interpreter.getAppliedAmendments();
      expect(applied.length).toBe(1);
      expect(applied[0].number).toBe(1);
      expect(applied[0].description).toBe('Capacity increase');
    });

    it('should throw error on replacing non-existent statement', async () => {
      const source = `
        BASKET SomeBasket CAPACITY $10_000_000
      `;
      const amendmentSource = `
        AMENDMENT 1
          REPLACES COVENANT NonExistent WITH
            COVENANT NonExistent
              REQUIRES x <= 5
      `;

      const ast = await parseOrThrow(source);
      const amendmentAst = await parseOrThrow(amendmentSource);
      const interpreter = new CreditLangInterpreter(ast);

      const amendment = amendmentAst.statements.find(s => s.type === 'Amendment') as any;
      expect(() => interpreter.applyAmendment(amendment)).toThrow(/not found/);
    });
  });
});

// ==================== CLOSING ENUMS TESTS ====================

import {
  TransactionType,
  DocumentType,
  DocumentStatus,
  PartyRole,
  ConditionStatus,
  DefinedTermCategory,
  DocumentCategory,
  isTransactionType,
  isDocumentType,
  isDocumentStatus,
  isPartyRole,
  isConditionStatus,
  getTransactionTypeLabel,
  getDocumentStatusLabel,
  getPartyRoleLabel,
  getConditionStatusLabel,
} from '../src/closing-enums.js';

describe('Closing Enums', () => {
  describe('TransactionType', () => {
    it('should have all expected transaction types', () => {
      expect(TransactionType.REVOLVING_CREDIT).toBe('revolving_credit');
      expect(TransactionType.TERM_LOAN_A).toBe('term_loan_a');
      expect(TransactionType.TERM_LOAN_B).toBe('term_loan_b');
      expect(TransactionType.DELAYED_DRAW).toBe('delayed_draw');
      expect(TransactionType.BRIDGE_LOAN).toBe('bridge_loan');
      expect(TransactionType.ABL).toBe('asset_based_loan');
      expect(TransactionType.MULTI_TRANCHE).toBe('multi_tranche');
    });

    it('should validate transaction types', () => {
      expect(isTransactionType('revolving_credit')).toBe(true);
      expect(isTransactionType('term_loan_a')).toBe(true);
      expect(isTransactionType('invalid_type')).toBe(false);
    });

    it('should provide human-readable labels', () => {
      expect(getTransactionTypeLabel(TransactionType.REVOLVING_CREDIT)).toBe('Revolving Credit');
      expect(getTransactionTypeLabel(TransactionType.ABL)).toBe('Asset-Based Loan');
    });
  });

  describe('DocumentType', () => {
    it('should have core agreement documents', () => {
      expect(DocumentType.CREDIT_AGREEMENT).toBe('credit_agreement');
      expect(DocumentType.AMENDMENT).toBe('amendment');
      expect(DocumentType.WAIVER).toBe('waiver');
    });

    it('should have corporate documents', () => {
      expect(DocumentType.OFFICERS_CERTIFICATE).toBe('officers_certificate');
      expect(DocumentType.SECRETARY_CERTIFICATE).toBe('secretary_certificate');
      expect(DocumentType.GOOD_STANDING).toBe('good_standing');
    });

    it('should have security documents', () => {
      expect(DocumentType.SECURITY_AGREEMENT).toBe('security_agreement');
      expect(DocumentType.PLEDGE_AGREEMENT).toBe('pledge_agreement');
      expect(DocumentType.GUARANTY).toBe('guaranty');
    });

    it('should validate document types', () => {
      expect(isDocumentType('credit_agreement')).toBe(true);
      expect(isDocumentType('legal_opinion')).toBe(true);
      expect(isDocumentType('fake_document')).toBe(false);
    });
  });

  describe('DocumentStatus', () => {
    it('should have all lifecycle statuses', () => {
      expect(DocumentStatus.NOT_STARTED).toBe('not_started');
      expect(DocumentStatus.DRAFTING).toBe('drafting');
      expect(DocumentStatus.FINAL).toBe('final');
      expect(DocumentStatus.EXECUTED).toBe('executed');
    });

    it('should validate document statuses', () => {
      expect(isDocumentStatus('drafting')).toBe(true);
      expect(isDocumentStatus('executed')).toBe(true);
      expect(isDocumentStatus('invalid_status')).toBe(false);
    });

    it('should provide human-readable labels', () => {
      expect(getDocumentStatusLabel(DocumentStatus.NOT_STARTED)).toBe('Not Started');
      expect(getDocumentStatusLabel(DocumentStatus.OUT_FOR_REVIEW)).toBe('Out for Review');
    });
  });

  describe('PartyRole', () => {
    it('should have all party roles', () => {
      expect(PartyRole.BORROWER).toBe('borrower');
      expect(PartyRole.ADMINISTRATIVE_AGENT).toBe('administrative_agent');
      expect(PartyRole.LENDER).toBe('lender');
    });

    it('should validate party roles', () => {
      expect(isPartyRole('borrower')).toBe(true);
      expect(isPartyRole('lender')).toBe(true);
      expect(isPartyRole('fake_role')).toBe(false);
    });

    it('should provide human-readable labels', () => {
      expect(getPartyRoleLabel(PartyRole.ADMINISTRATIVE_AGENT)).toBe('Administrative Agent');
      expect(getPartyRoleLabel(PartyRole.SWINGLINE_LENDER)).toBe('Swingline Lender');
    });
  });

  describe('ConditionStatus', () => {
    it('should have all condition statuses', () => {
      expect(ConditionStatus.PENDING).toBe('pending');
      expect(ConditionStatus.SATISFIED).toBe('satisfied');
      expect(ConditionStatus.WAIVED).toBe('waived');
    });

    it('should validate condition statuses', () => {
      expect(isConditionStatus('satisfied')).toBe(true);
      expect(isConditionStatus('waived')).toBe(true);
      expect(isConditionStatus('invalid')).toBe(false);
    });

    it('should provide human-readable labels', () => {
      expect(getConditionStatusLabel(ConditionStatus.IN_PROGRESS)).toBe('In Progress');
      expect(getConditionStatusLabel(ConditionStatus.NOT_APPLICABLE)).toBe('N/A');
    });
  });

  describe('DefinedTermCategory', () => {
    it('should have all term categories', () => {
      expect(DefinedTermCategory.PARTY).toBe('party');
      expect(DefinedTermCategory.DOCUMENT).toBe('document');
      expect(DefinedTermCategory.FACILITY).toBe('facility');
      expect(DefinedTermCategory.COLLATERAL).toBe('collateral');
      expect(DefinedTermCategory.GENERAL).toBe('general');
    });
  });

  describe('DocumentCategory', () => {
    it('should have all document categories', () => {
      expect(DocumentCategory.CORE_AGREEMENT).toBe('Core Agreement');
      expect(DocumentCategory.CORPORATE_DOCUMENTS).toBe('Corporate Documents');
      expect(DocumentCategory.SECURITY_DOCUMENTS).toBe('Security Documents');
      expect(DocumentCategory.LEGAL_OPINIONS).toBe('Legal Opinions');
    });
  });
});

// ==================== ONTOLOGY TESTS ====================

import {
  loadBuiltinOntology,
  validateOntology,
  getDocumentsByCategory,
  getConditionBySection,
  getDocumentCategories,
  getConditionCategories,
  getDocumentByKey,
  type OntologyConfig,
} from '../src/ontology.js';

describe('Ontology System', () => {
  let ontology: OntologyConfig;

  beforeEach(() => {
    ontology = loadBuiltinOntology('credit-agreement-v1');
  });

  describe('Loading', () => {
    it('should load built-in credit-agreement-v1 ontology', () => {
      expect(ontology.name).toBe('credit-agreement-v1');
      expect(ontology.version).toBe('1.0.0');
    });

    it('should have document templates', () => {
      expect(ontology.documentTemplates.length).toBeGreaterThan(0);
    });

    it('should have condition templates', () => {
      expect(ontology.conditionTemplates.length).toBeGreaterThan(0);
    });

    it('should have covenant templates', () => {
      expect(ontology.covenantTemplates).toBeDefined();
      expect(ontology.covenantTemplates!.length).toBeGreaterThan(0);
    });

    it('should have basket templates', () => {
      expect(ontology.basketTemplates).toBeDefined();
      expect(ontology.basketTemplates!.length).toBeGreaterThan(0);
    });
  });

  describe('Document Templates', () => {
    it('should have credit agreement template', () => {
      const creditAgreement = getDocumentByKey(ontology, 'credit_agreement');
      expect(creditAgreement).toBeDefined();
      expect(creditAgreement!.documentType).toBe('credit_agreement');
      expect(creditAgreement!.category).toBe('Core Agreement');
    });

    it('should have officers certificate template', () => {
      const cert = getDocumentByKey(ontology, 'officers_certificate');
      expect(cert).toBeDefined();
      expect(cert!.defaultResponsibleRole).toBe('borrower');
    });

    it('should get documents by category', () => {
      const corporateDocs = getDocumentsByCategory(ontology, 'Corporate Documents');
      expect(corporateDocs.length).toBeGreaterThan(0);
      expect(corporateDocs.every(d => d.category === 'Corporate Documents')).toBe(true);
    });

    it('should get all document categories', () => {
      const categories = getDocumentCategories(ontology);
      expect(categories).toContain('Core Agreement');
      expect(categories).toContain('Corporate Documents');
      expect(categories).toContain('Security Documents');
    });
  });

  describe('Condition Templates', () => {
    it('should have corporate documents condition', () => {
      const condition = getConditionBySection(ontology, '4.01(a)');
      expect(condition).toBeDefined();
      expect(condition!.title).toBe('Corporate Documents');
    });

    it('should have expected document keys', () => {
      const condition = getConditionBySection(ontology, '4.01(a)');
      expect(condition!.expectedDocumentKeys).toContain('officers_certificate');
      expect(condition!.expectedDocumentKeys).toContain('secretary_certificate');
    });

    it('should get all condition categories', () => {
      const categories = getConditionCategories(ontology);
      expect(categories).toContain('Corporate Documents');
      expect(categories).toContain('Security Documents');
      expect(categories).toContain('Legal Opinions');
    });
  });

  describe('Validation', () => {
    it('should validate ontology with no errors', () => {
      const errors = validateOntology(ontology);
      expect(errors.length).toBe(0);
    });

    it('should detect invalid document references', () => {
      const invalidOntology: OntologyConfig = {
        name: 'test',
        documentTemplates: [],
        conditionTemplates: [{
          sectionReference: '1.01',
          title: 'Test',
          description: 'Test',
          category: 'Test',
          expectedDocumentKeys: ['nonexistent_doc'],
        }],
      };

      const errors = validateOntology(invalidOntology);
      expect(errors.length).toBe(1);
      expect(errors[0]).toContain('nonexistent_doc');
    });
  });

  describe('Covenant Templates', () => {
    it('should have total leverage template', () => {
      const totalLeverage = ontology.covenantTemplates!.find(c => c.key === 'total_leverage');
      expect(totalLeverage).toBeDefined();
      expect(totalLeverage!.metric).toBe('TotalLeverage');
      expect(totalLeverage!.defaultOperator).toBe('<=');
    });

    it('should have common thresholds by transaction type', () => {
      const totalLeverage = ontology.covenantTemplates!.find(c => c.key === 'total_leverage');
      expect(totalLeverage!.commonThresholds).toBeDefined();
      expect(totalLeverage!.commonThresholds!.leveraged).toBe(5.0);
    });
  });

  describe('Basket Templates', () => {
    it('should have general investment basket template', () => {
      const basket = ontology.basketTemplates!.find(b => b.key === 'general_investment');
      expect(basket).toBeDefined();
      expect(basket!.basketType).toBe('grower');
    });

    it('should have common capacities', () => {
      const basket = ontology.basketTemplates!.find(b => b.key === 'general_investment');
      expect(basket!.commonCapacities).toBeDefined();
      expect(basket!.commonCapacities!.leveraged).toContain('GreaterOf');
    });
  });
});

// ==================== DEFINED TERMS TESTS ====================

import {
  parseDefinedTerm,
  parseDefinedTerms,
  loadDefinedTermsFromJson,
  createTermsRegistry,
  findTerm,
  findTermsByCategory,
  findReferencingTerms,
  buildCrossReferenceGraph,
  findCircularReferences,
  validateCrossReferences,
  findDuplicateTerms,
  isCalculableTerm,
  extractPotentialIdentifiers,
  type DefinedTerm,
  type DefinedTermsRegistry,
} from '../src/defined-terms.js';

describe('Defined Terms System', () => {
  const sampleTerms: DefinedTerm[] = [
    {
      term: 'EBITDA',
      definition: 'means Net Income plus Interest Expense plus Tax Expense plus Depreciation and Amortization',
      source: 'credit_agreement',
      sectionReference: 'Section 1.01',
      category: 'financial',
      crossReferences: ['Net Income', 'Interest Expense', 'Tax Expense'],
    },
    {
      term: 'Net Income',
      definition: 'means the net income of the Borrower and its Subsidiaries determined in accordance with GAAP',
      source: 'credit_agreement',
      sectionReference: 'Section 1.01',
      category: 'financial',
      crossReferences: ['Borrower', 'GAAP'],
    },
    {
      term: 'Borrower',
      definition: 'ABC Corporation, a Delaware corporation',
      source: 'credit_agreement',
      sectionReference: 'Section 1.01',
      category: 'party',
      crossReferences: [],
    },
  ];

  describe('Parsing', () => {
    it('should parse a raw defined term', () => {
      const raw = {
        term: 'Test',
        definition: 'Test definition',
        source: 'test_source',
        section_reference: 'Section 1.01',
        category: 'general',
        cross_references: ['Other Term'],
        notes: 'Test notes',
      };

      const parsed = parseDefinedTerm(raw);
      expect(parsed.term).toBe('Test');
      expect(parsed.sectionReference).toBe('Section 1.01');
      expect(parsed.crossReferences).toContain('Other Term');
      expect(parsed.notes).toBe('Test notes');
    });

    it('should parse multiple raw terms', () => {
      const rawTerms = [
        { term: 'A', definition: 'A def', source: 's', section_reference: '1', category: 'g', cross_references: [] },
        { term: 'B', definition: 'B def', source: 's', section_reference: '2', category: 'g', cross_references: [] },
      ];

      const parsed = parseDefinedTerms(rawTerms);
      expect(parsed.length).toBe(2);
      expect(parsed[0]!.term).toBe('A');
      expect(parsed[1]!.term).toBe('B');
    });

    it('should load terms from JSON string', () => {
      const json = JSON.stringify([
        { term: 'Test', definition: 'Def', source: 's', section_reference: '1', category: 'g', cross_references: [] }
      ]);

      const terms = loadDefinedTermsFromJson(json);
      expect(terms.length).toBe(1);
      expect(terms[0]!.term).toBe('Test');
    });
  });

  describe('Registry', () => {
    let registry: DefinedTermsRegistry;

    beforeEach(() => {
      registry = createTermsRegistry(sampleTerms, 'test_agreement', '1.0');
    });

    it('should create a registry from terms', () => {
      expect(registry.source).toBe('test_agreement');
      expect(registry.version).toBe('1.0');
      expect(registry.terms.length).toBe(3);
      expect(registry.lastUpdated).toBeDefined();
    });

    it('should find term by name', () => {
      const term = findTerm(registry, 'EBITDA');
      expect(term).toBeDefined();
      expect(term!.definition).toContain('Net Income');
    });

    it('should find term case-insensitively', () => {
      const term = findTerm(registry, 'ebitda');
      expect(term).toBeDefined();
      expect(term!.term).toBe('EBITDA');
    });

    it('should find terms by category', () => {
      const financialTerms = findTermsByCategory(registry, 'financial');
      expect(financialTerms.length).toBe(2);
      expect(financialTerms.every(t => t.category === 'financial')).toBe(true);
    });

    it('should find referencing terms', () => {
      const referencingTerms = findReferencingTerms(registry, 'Net Income');
      expect(referencingTerms.length).toBe(1);
      expect(referencingTerms[0]!.term).toBe('EBITDA');
    });
  });

  describe('Cross-Reference Analysis', () => {
    let registry: DefinedTermsRegistry;

    beforeEach(() => {
      registry = createTermsRegistry(sampleTerms, 'test', '1.0');
    });

    it('should build cross-reference graph', () => {
      const graph = buildCrossReferenceGraph(registry);
      expect(graph.length).toBeGreaterThan(0);

      const ebitdaRefs = graph.filter(r => r.fromTerm === 'EBITDA');
      expect(ebitdaRefs.length).toBe(3);
    });

    it('should detect circular references', () => {
      const circularTerms: DefinedTerm[] = [
        { term: 'A', definition: 'refs B', source: 's', sectionReference: '1', category: 'g', crossReferences: ['B'] },
        { term: 'B', definition: 'refs C', source: 's', sectionReference: '2', category: 'g', crossReferences: ['C'] },
        { term: 'C', definition: 'refs A', source: 's', sectionReference: '3', category: 'g', crossReferences: ['A'] },
      ];
      const circularRegistry = createTermsRegistry(circularTerms, 'test', '1.0');

      const cycles = findCircularReferences(circularRegistry);
      expect(cycles.length).toBeGreaterThan(0);
    });

    it('should not detect cycles where none exist', () => {
      const cycles = findCircularReferences(registry);
      expect(cycles.length).toBe(0);
    });
  });

  describe('Validation', () => {
    it('should validate cross-references', () => {
      const invalidTerms: DefinedTerm[] = [
        { term: 'Test', definition: 'refs undefined', source: 's', sectionReference: '1', category: 'g', crossReferences: ['UndefinedTerm'] },
      ];
      const registry = createTermsRegistry(invalidTerms, 'test', '1.0');

      const errors = validateCrossReferences(registry);
      expect(errors.length).toBe(1);
      expect(errors[0]).toContain('UndefinedTerm');
    });

    it('should detect duplicate terms', () => {
      const duplicateTerms: DefinedTerm[] = [
        { term: 'Test', definition: 'def 1', source: 's', sectionReference: '1', category: 'g', crossReferences: [] },
        { term: 'TEST', definition: 'def 2', source: 's', sectionReference: '2', category: 'g', crossReferences: [] },
      ];
      const registry = createTermsRegistry(duplicateTerms, 'test', '1.0');

      const duplicates = findDuplicateTerms(registry);
      expect(duplicates.length).toBe(1);
    });
  });

  describe('CreditLang Integration', () => {
    it('should identify calculable terms by category', () => {
      const financialTerm: DefinedTerm = {
        term: 'EBITDA',
        definition: 'calculated value',
        source: 's',
        sectionReference: '1',
        category: 'financial',
        crossReferences: [],
      };

      expect(isCalculableTerm(financialTerm)).toBe(true);
    });

    it('should identify calculable terms by definition keywords', () => {
      const calculableTerm: DefinedTerm = {
        term: 'Leverage',
        definition: 'means the ratio of Total Debt divided by EBITDA',
        source: 's',
        sectionReference: '1',
        category: 'general',
        crossReferences: [],
      };

      expect(isCalculableTerm(calculableTerm)).toBe(true);
    });

    it('should not identify non-calculable terms', () => {
      const partyTerm: DefinedTerm = {
        term: 'Borrower',
        definition: 'ABC Corporation, a Delaware corporation',
        source: 's',
        sectionReference: '1',
        category: 'party',
        crossReferences: [],
      };

      expect(isCalculableTerm(partyTerm)).toBe(false);
    });

    it('should extract potential identifiers from definition', () => {
      const term: DefinedTerm = {
        term: 'EBITDA',
        definition: 'means Net Income plus Interest Expense',
        source: 's',
        sectionReference: '1',
        category: 'financial',
        crossReferences: ['Net Income', 'Interest Expense'],
      };

      const identifiers = extractPotentialIdentifiers(term);
      expect(identifiers).toContain('Net Income');
      expect(identifiers).toContain('Interest Expense');
    });
  });
});

// ==================== MULTI-PERIOD TESTS ====================

describe('Multi-Period Financial Data', () => {
  describe('Type Guards', () => {
    it('should identify multi-period data', async () => {
      const { isMultiPeriodData, isPeriodData, isSimpleFinancialData } = await import('../src/types.js');

      const multiPeriod = {
        periods: [
          { period: '2024-Q1', periodType: 'quarterly', periodEnd: '2024-03-31', data: { revenue: 100 } },
        ],
      };

      const simple = { revenue: 100, expenses: 50 };

      expect(isMultiPeriodData(multiPeriod)).toBe(true);
      expect(isMultiPeriodData(simple)).toBe(false);
      expect(isSimpleFinancialData(simple)).toBe(true);
      expect(isSimpleFinancialData(multiPeriod)).toBe(false);
    });

    it('should identify period data', async () => {
      const { isPeriodData } = await import('../src/types.js');

      const periodData = {
        period: '2024-Q1',
        periodType: 'quarterly',
        periodEnd: '2024-03-31',
        data: { revenue: 100 },
      };

      expect(isPeriodData(periodData)).toBe(true);
      expect(isPeriodData({ revenue: 100 })).toBe(false);
    });
  });

  describe('Trailing Expression Parsing', () => {
    it('should parse TRAILING QUARTERS expression', async () => {
      const source = `
        DEFINE LTM_EBITDA AS
          TRAILING 4 QUARTERS OF EBITDA
      `;
      const ast = await parseOrThrow(source);
      const define = ast.statements.find((s) => s.type === 'Define') as any;
      expect(define).toBeDefined();
      expect(define.expression.type).toBe('Trailing');
      expect(define.expression.count).toBe(4);
      expect(define.expression.period).toBe('quarters');
    });

    it('should parse TRAILING MONTHS expression', async () => {
      const source = `
        DEFINE LTM_Revenue AS
          TRAILING 12 MONTHS OF revenue
      `;
      const ast = await parseOrThrow(source);
      const define = ast.statements.find((s) => s.type === 'Define') as any;
      expect(define.expression.type).toBe('Trailing');
      expect(define.expression.count).toBe(12);
      expect(define.expression.period).toBe('months');
    });

    it('should parse TRAILING YEARS expression', async () => {
      const source = `
        DEFINE ThreeYearAvg AS
          TRAILING 3 YEARS OF annualRevenue
      `;
      const ast = await parseOrThrow(source);
      const define = ast.statements.find((s) => s.type === 'Define') as any;
      expect(define.expression.type).toBe('Trailing');
      expect(define.expression.count).toBe(3);
      expect(define.expression.period).toBe('years');
    });

    it('should parse trailing with singular period (QUARTER)', async () => {
      const source = `
        DEFINE SingleQuarter AS
          TRAILING 1 QUARTER OF EBITDA
      `;
      const ast = await parseOrThrow(source);
      const define = ast.statements.find((s) => s.type === 'Define') as any;
      expect(define.expression.count).toBe(1);
      expect(define.expression.period).toBe('quarters');
    });
  });

  describe('Multi-Period Interpreter', () => {
    const multiPeriodData = {
      periods: [
        {
          period: '2024-Q1',
          periodType: 'quarterly' as const,
          periodEnd: '2024-03-31',
          data: { EBITDA: 10000000, interest_expense: 1000000, funded_debt: 40000000 },
        },
        {
          period: '2024-Q2',
          periodType: 'quarterly' as const,
          periodEnd: '2024-06-30',
          data: { EBITDA: 11000000, interest_expense: 1100000, funded_debt: 42000000 },
        },
        {
          period: '2024-Q3',
          periodType: 'quarterly' as const,
          periodEnd: '2024-09-30',
          data: { EBITDA: 10500000, interest_expense: 1050000, funded_debt: 43000000 },
        },
        {
          period: '2024-Q4',
          periodType: 'quarterly' as const,
          periodEnd: '2024-12-31',
          data: { EBITDA: 11500000, interest_expense: 1150000, funded_debt: 45000000 },
        },
      ],
    };

    it('should load multi-period data and detect mode', async () => {
      const source = `DEFINE Test AS EBITDA`;
      const ast = await parseOrThrow(source);
      const interpreter = new CreditLangInterpreter(ast);

      expect(interpreter.hasMultiPeriodData()).toBe(false);

      interpreter.loadFinancials(multiPeriodData);
      expect(interpreter.hasMultiPeriodData()).toBe(true);
    });

    it('should return available periods sorted', async () => {
      const source = `DEFINE Test AS EBITDA`;
      const ast = await parseOrThrow(source);
      const interpreter = new CreditLangInterpreter(ast);
      interpreter.loadFinancials(multiPeriodData);

      const periods = interpreter.getAvailablePeriods();
      expect(periods).toEqual(['2024-Q1', '2024-Q2', '2024-Q3', '2024-Q4']);
    });

    it('should default to latest period', async () => {
      const source = `DEFINE Test AS EBITDA`;
      const ast = await parseOrThrow(source);
      const interpreter = new CreditLangInterpreter(ast);
      interpreter.loadFinancials(multiPeriodData);

      expect(interpreter.getEvaluationPeriod()).toBe('2024-Q4');
    });

    it('should set and get evaluation period', async () => {
      const source = `DEFINE Test AS EBITDA`;
      const ast = await parseOrThrow(source);
      const interpreter = new CreditLangInterpreter(ast);
      interpreter.loadFinancials(multiPeriodData);

      interpreter.setEvaluationPeriod('2024-Q2');
      expect(interpreter.getEvaluationPeriod()).toBe('2024-Q2');
    });

    it('should throw on invalid period', async () => {
      const source = `DEFINE Test AS EBITDA`;
      const ast = await parseOrThrow(source);
      const interpreter = new CreditLangInterpreter(ast);
      interpreter.loadFinancials(multiPeriodData);

      expect(() => interpreter.setEvaluationPeriod('2025-Q1')).toThrow();
    });

    it('should evaluate identifier for current period', async () => {
      const source = `
        DEFINE Test AS EBITDA
        COVENANT MaxTest REQUIRES Test <= 50_000_000
      `;
      const ast = await parseOrThrow(source);
      const interpreter = new CreditLangInterpreter(ast);
      interpreter.loadFinancials(multiPeriodData);

      // Default is Q4, EBITDA = 11500000
      const result = interpreter.checkCovenant('MaxTest');
      expect(result.actual).toBe(11500000);

      // Switch to Q1, EBITDA = 10000000
      interpreter.setEvaluationPeriod('2024-Q1');
      const result2 = interpreter.checkCovenant('MaxTest');
      expect(result2.actual).toBe(10000000);
    });

    it('should evaluate trailing expression', async () => {
      const source = `
        DEFINE LTM_EBITDA AS TRAILING 4 QUARTERS OF EBITDA
        COVENANT MaxLeverage REQUIRES funded_debt / LTM_EBITDA <= 2.00
      `;
      const ast = await parseOrThrow(source);
      const interpreter = new CreditLangInterpreter(ast);
      interpreter.loadFinancials(multiPeriodData);

      // LTM EBITDA = 10 + 11 + 10.5 + 11.5 = 43 million
      // Q4 funded_debt = 45 million
      // Leverage = 45/43 = 1.047
      const result = interpreter.checkCovenant('MaxLeverage');
      expect(result.actual).toBeCloseTo(45000000 / 43000000, 2);
      expect(result.compliant).toBe(true);
    });

    it('should handle trailing with fewer periods available', async () => {
      const source = `
        DEFINE LTM_EBITDA AS TRAILING 4 QUARTERS OF EBITDA
      `;
      const ast = await parseOrThrow(source);
      const interpreter = new CreditLangInterpreter(ast);

      // Load only 2 quarters
      interpreter.loadFinancials({
        periods: [
          { period: '2024-Q3', periodType: 'quarterly', periodEnd: '2024-09-30', data: { EBITDA: 10000000 } },
          { period: '2024-Q4', periodType: 'quarterly', periodEnd: '2024-12-31', data: { EBITDA: 11000000 } },
        ],
      });

      // Should sum available periods (only 2) - this will log a warning
      // but should still work
      const definition = ast.statements.find((s) => s.type === 'Define') as any;
      expect(definition).toBeDefined();
    });

    it('should get compliance history', async () => {
      const source = `
        COVENANT MinEBITDA REQUIRES EBITDA >= 10_500_000
      `;
      const ast = await parseOrThrow(source);
      const interpreter = new CreditLangInterpreter(ast);
      interpreter.loadFinancials(multiPeriodData);

      const history = interpreter.getComplianceHistory();
      expect(history.length).toBe(4);

      // Q1: 10M < 10.5M -> breach
      expect(history[0]?.period).toBe('2024-Q1');
      expect(history[0]?.overallCompliant).toBe(false);

      // Q2: 11M >= 10.5M -> compliant
      expect(history[1]?.period).toBe('2024-Q2');
      expect(history[1]?.overallCompliant).toBe(true);

      // Q3: 10.5M >= 10.5M -> compliant (exactly)
      expect(history[2]?.period).toBe('2024-Q3');
      expect(history[2]?.overallCompliant).toBe(true);

      // Q4: 11.5M >= 10.5M -> compliant
      expect(history[3]?.period).toBe('2024-Q4');
      expect(history[3]?.overallCompliant).toBe(true);
    });
  });

  describe('Backward Compatibility', () => {
    it('should still work with simple financial data', async () => {
      const source = `
        DEFINE EBITDA AS net_income + interest
        COVENANT MaxLeverage REQUIRES debt / EBITDA <= 4.00
      `;
      const ast = await parseOrThrow(source);
      const interpreter = new CreditLangInterpreter(ast);

      // Old-style simple data
      interpreter.loadFinancials({
        net_income: 8000000,
        interest: 2000000,
        debt: 36000000,
      });

      expect(interpreter.hasMultiPeriodData()).toBe(false);

      const result = interpreter.checkCovenant('MaxLeverage');
      expect(result.actual).toBeCloseTo(3.6, 1);
      expect(result.compliant).toBe(true);
    });

    it('should work with loadFinancialsFromFile for simple data', async () => {
      const source = `DEFINE Test AS revenue`;
      const ast = await parseOrThrow(source);
      const interpreter = new CreditLangInterpreter(ast);

      interpreter.loadFinancialsFromFile({
        financials: { revenue: 1000000 },
        adjustments: { bonus: 50000 },
      });

      expect(interpreter.hasMultiPeriodData()).toBe(false);
    });
  });

  describe('Period Sorting', () => {
    it('should sort quarterly periods correctly', async () => {
      const source = `DEFINE Test AS value`;
      const ast = await parseOrThrow(source);
      const interpreter = new CreditLangInterpreter(ast);

      // Load out-of-order periods
      interpreter.loadFinancials({
        periods: [
          { period: '2024-Q3', periodType: 'quarterly', periodEnd: '2024-09-30', data: { value: 3 } },
          { period: '2024-Q1', periodType: 'quarterly', periodEnd: '2024-03-31', data: { value: 1 } },
          { period: '2024-Q4', periodType: 'quarterly', periodEnd: '2024-12-31', data: { value: 4 } },
          { period: '2024-Q2', periodType: 'quarterly', periodEnd: '2024-06-30', data: { value: 2 } },
        ],
      });

      const periods = interpreter.getAvailablePeriods();
      expect(periods).toEqual(['2024-Q1', '2024-Q2', '2024-Q3', '2024-Q4']);
    });

    it('should sort monthly periods correctly', async () => {
      const source = `DEFINE Test AS value`;
      const ast = await parseOrThrow(source);
      const interpreter = new CreditLangInterpreter(ast);

      interpreter.loadFinancials({
        periods: [
          { period: '2024-03', periodType: 'monthly', periodEnd: '2024-03-31', data: { value: 3 } },
          { period: '2024-01', periodType: 'monthly', periodEnd: '2024-01-31', data: { value: 1 } },
          { period: '2024-02', periodType: 'monthly', periodEnd: '2024-02-29', data: { value: 2 } },
        ],
      });

      const periods = interpreter.getAvailablePeriods();
      expect(periods).toEqual(['2024-01', '2024-02', '2024-03']);
    });
  });

  describe('Validation', () => {
    it('should validate trailing expressions', async () => {
      const { validate } = await import('../src/validator.js');

      const source = `
        DEFINE LTM_EBITDA AS TRAILING 4 QUARTERS OF QuarterlyEBITDA
        DEFINE QuarterlyEBITDA AS net_income + depreciation
      `;
      const ast = await parseOrThrow(source);
      const result = validate(ast);

      // Should have warnings for net_income and depreciation (undefined identifiers)
      // but no errors
      expect(result.valid).toBe(true);
    });
  });
});

// ==================== PHASE SYSTEM TESTS (v1.0) ====================

describe('Phase System', () => {
  describe('Parser', () => {
    it('should parse PHASE statement with UNTIL clause', async () => {
      const source = `
        PHASE Construction
          UNTIL COD_Achieved
          COVENANTS SUSPENDED MaxLeverage
          REQUIRED MinEquityContribution
      `;
      const ast = await parseOrThrow(source);
      const phase = ast.statements.find(s => s.type === 'Phase') as any;

      expect(phase).toBeDefined();
      expect(phase.name).toBe('Construction');
      expect(phase.until).toBe('COD_Achieved');
      expect(phase.covenantsSuspended).toContain('MaxLeverage');
      expect(phase.requiredCovenants).toContain('MinEquityContribution');
    });

    it('should parse PHASE statement with FROM clause', async () => {
      const source = `
        PHASE Operations
          FROM COD_Achieved
          COVENANTS ACTIVE MaxLeverage, MinDSCR
      `;
      const ast = await parseOrThrow(source);
      const phase = ast.statements.find(s => s.type === 'Phase') as any;

      expect(phase).toBeDefined();
      expect(phase.name).toBe('Operations');
      expect(phase.from).toBe('COD_Achieved');
      expect(phase.covenantsActive).toEqual(['MaxLeverage', 'MinDSCR']);
    });

    it('should parse PHASE with multiple suspended covenants', async () => {
      const source = `
        PHASE Construction
          UNTIL COD_Achieved
          COVENANTS SUSPENDED MaxLeverage, InterestCoverage, MinDSCR
      `;
      const ast = await parseOrThrow(source);
      const phase = ast.statements.find(s => s.type === 'Phase') as any;

      expect(phase.covenantsSuspended).toEqual(['MaxLeverage', 'InterestCoverage', 'MinDSCR']);
    });

    it('should parse TRANSITION statement with ALL_OF condition', async () => {
      const source = `
        TRANSITION COD_Achieved
          WHEN ALL_OF(
            SubstantialCompletion,
            LenderCertification,
            InsuranceInPlace
          )
      `;
      const ast = await parseOrThrow(source);
      const transition = ast.statements.find(s => s.type === 'Transition') as any;

      expect(transition).toBeDefined();
      expect(transition.name).toBe('COD_Achieved');
      expect(transition.when.type).toBe('AllOf');
      expect(transition.when.conditions).toEqual([
        'SubstantialCompletion',
        'LenderCertification',
        'InsuranceInPlace'
      ]);
    });

    it('should parse TRANSITION statement with ANY_OF condition', async () => {
      const source = `
        TRANSITION EarlyTermination
          WHEN ANY_OF(
            BorrowerDefault,
            MaterialAdverseChange,
            LenderAcceleration
          )
      `;
      const ast = await parseOrThrow(source);
      const transition = ast.statements.find(s => s.type === 'Transition') as any;

      expect(transition.when.type).toBe('AnyOf');
      expect(transition.when.conditions).toHaveLength(3);
    });

    it('should parse TRANSITION with simple boolean expression', async () => {
      const source = `
        TRANSITION MaturityReached
          WHEN maturity_date_reached = 1
      `;
      const ast = await parseOrThrow(source);
      const transition = ast.statements.find(s => s.type === 'Transition') as any;

      expect(transition.when.type).toBe('Comparison');
    });
  });

  describe('Interpreter - Phase Management', () => {
    it('should set initial phase from first PHASE with no FROM clause', async () => {
      const source = `
        PHASE Construction
          UNTIL COD_Achieved

        PHASE Operations
          FROM COD_Achieved
      `;
      const ast = await parseOrThrow(source);
      const interpreter = new CreditLangInterpreter(ast);

      expect(interpreter.getCurrentPhase()).toBe('Construction');
    });

    it('should track phase history', async () => {
      const source = `
        PHASE Construction
          UNTIL COD_Achieved

        PHASE Operations
          FROM COD_Achieved
      `;
      const ast = await parseOrThrow(source);
      const interpreter = new CreditLangInterpreter(ast);

      const history = interpreter.getPhaseHistory();
      expect(history).toHaveLength(1);
      expect(history[0].phase).toBe('Construction');
      expect(history[0].triggeredBy).toBeNull();
    });

    it('should transition to new phase', async () => {
      const source = `
        PHASE Construction
          UNTIL COD_Achieved

        PHASE Operations
          FROM COD_Achieved
      `;
      const ast = await parseOrThrow(source);
      const interpreter = new CreditLangInterpreter(ast);

      expect(interpreter.getCurrentPhase()).toBe('Construction');

      interpreter.transitionTo('COD_Achieved');

      expect(interpreter.getCurrentPhase()).toBe('Operations');
      expect(interpreter.getPhaseHistory()).toHaveLength(2);
    });

    it('should get phase names', async () => {
      const source = `
        PHASE Construction
          UNTIL COD_Achieved

        PHASE Operations
          FROM COD_Achieved
      `;
      const ast = await parseOrThrow(source);
      const interpreter = new CreditLangInterpreter(ast);

      expect(interpreter.getPhaseNames()).toEqual(['Construction', 'Operations']);
    });

    it('should report hasPhases correctly', async () => {
      const sourceWithPhases = `
        PHASE Construction
          UNTIL COD_Achieved
      `;
      const sourceWithoutPhases = `
        COVENANT MaxLeverage
          REQUIRES Leverage <= 4.5
          TESTED QUARTERLY
      `;

      const ast1 = await parseOrThrow(sourceWithPhases);
      const ast2 = await parseOrThrow(sourceWithoutPhases);

      const interpreter1 = new CreditLangInterpreter(ast1);
      const interpreter2 = new CreditLangInterpreter(ast2);

      expect(interpreter1.hasPhases()).toBe(true);
      expect(interpreter2.hasPhases()).toBe(false);
    });
  });

  describe('Interpreter - Covenant Suspension', () => {
    it('should suspend covenants in construction phase', async () => {
      const source = `
        PHASE Construction
          UNTIL COD_Achieved
          COVENANTS SUSPENDED MaxLeverage, InterestCoverage

        COVENANT MaxLeverage
          REQUIRES Leverage <= 4.5
          TESTED QUARTERLY

        COVENANT InterestCoverage
          REQUIRES coverage >= 2.5
          TESTED QUARTERLY

        COVENANT MinEquity
          REQUIRES equity >= 1000000
          TESTED QUARTERLY

        DEFINE Leverage AS total_debt / ebitda
        DEFINE coverage AS ebitda / interest
        DEFINE equity AS total_equity
      `;
      const ast = await parseOrThrow(source);
      const interpreter = new CreditLangInterpreter(ast);

      expect(interpreter.getCurrentPhase()).toBe('Construction');
      expect(interpreter.getSuspendedCovenants()).toEqual(['MaxLeverage', 'InterestCoverage']);
      expect(interpreter.getActiveCovenants()).toEqual(['MinEquity']);
    });

    it('should check only active covenants in checkActiveCovenants', async () => {
      const source = `
        PHASE Construction
          UNTIL COD_Achieved
          COVENANTS SUSPENDED MaxLeverage

        COVENANT MaxLeverage
          REQUIRES Leverage <= 4.5
          TESTED QUARTERLY

        COVENANT MinEquity
          REQUIRES equity >= 1000000
          TESTED QUARTERLY

        DEFINE Leverage AS total_debt / ebitda
        DEFINE equity AS total_equity
      `;
      const ast = await parseOrThrow(source);
      const interpreter = new CreditLangInterpreter(ast);

      interpreter.loadFinancials({
        total_debt: 5000000,
        ebitda: 1000000,  // Leverage = 5.0, would fail MaxLeverage
        total_equity: 2000000  // Passes MinEquity
      });

      // checkAllCovenants includes all covenants
      const allResults = interpreter.checkAllCovenants();
      expect(allResults).toHaveLength(2);
      expect(allResults.find(r => r.name === 'MaxLeverage')?.compliant).toBe(false);

      // checkActiveCovenants excludes suspended covenants
      const activeResults = interpreter.checkActiveCovenants();
      expect(activeResults).toHaveLength(1);
      expect(activeResults[0].name).toBe('MinEquity');
      expect(activeResults[0].compliant).toBe(true);
    });

    it('should activate covenants after transition to operations', async () => {
      const source = `
        PHASE Construction
          UNTIL COD_Achieved
          COVENANTS SUSPENDED MaxLeverage

        PHASE Operations
          FROM COD_Achieved
          COVENANTS ACTIVE MaxLeverage, MinEquity

        COVENANT MaxLeverage
          REQUIRES Leverage <= 4.5
          TESTED QUARTERLY

        COVENANT MinEquity
          REQUIRES equity >= 1000000
          TESTED QUARTERLY

        DEFINE Leverage AS total_debt / ebitda
        DEFINE equity AS total_equity
      `;
      const ast = await parseOrThrow(source);
      const interpreter = new CreditLangInterpreter(ast);

      // Initially in Construction
      expect(interpreter.getSuspendedCovenants()).toContain('MaxLeverage');

      // Transition to Operations
      interpreter.transitionTo('COD_Achieved');

      expect(interpreter.getCurrentPhase()).toBe('Operations');
      expect(interpreter.getSuspendedCovenants()).toEqual([]);
      expect(interpreter.getActiveCovenants()).toEqual(['MaxLeverage', 'MinEquity']);
    });

    it('should include required covenants in phase checking', async () => {
      const source = `
        PHASE Construction
          UNTIL COD_Achieved
          COVENANTS SUSPENDED MaxLeverage
          REQUIRED MinEquityContribution

        COVENANT MaxLeverage
          REQUIRES Leverage <= 4.5
          TESTED QUARTERLY

        COVENANT MinEquityContribution
          REQUIRES equity_pct >= 0.35
          TESTED MONTHLY

        DEFINE Leverage AS total_debt / ebitda
        DEFINE equity_pct AS equity / total_project_cost
      `;
      const ast = await parseOrThrow(source);
      const interpreter = new CreditLangInterpreter(ast);

      expect(interpreter.getRequiredCovenants()).toEqual(['MinEquityContribution']);
    });
  });

  describe('Interpreter - Transition Conditions', () => {
    it('should check ALL_OF transition conditions', async () => {
      const source = `
        TRANSITION COD_Achieved
          WHEN ALL_OF(
            SubstantialCompletion,
            LenderCertification,
            InsuranceInPlace
          )

        PHASE Construction
          UNTIL COD_Achieved

        PHASE Operations
          FROM COD_Achieved
      `;
      const ast = await parseOrThrow(source);
      const interpreter = new CreditLangInterpreter(ast);

      // Check transition before any conditions are satisfied
      let transitions = interpreter.checkPhaseTransitions();
      expect(transitions).toHaveLength(1);
      expect(transitions[0].triggered).toBe(false);
      expect(transitions[0].conditions.every(c => !c.met)).toBe(true);

      // Satisfy some conditions
      interpreter.satisfyCondition('SubstantialCompletion');
      interpreter.satisfyCondition('LenderCertification');

      transitions = interpreter.checkPhaseTransitions();
      expect(transitions[0].triggered).toBe(false);
      expect(transitions[0].conditions.filter(c => c.met)).toHaveLength(2);

      // Satisfy all conditions
      interpreter.satisfyCondition('InsuranceInPlace');

      transitions = interpreter.checkPhaseTransitions();
      expect(transitions[0].triggered).toBe(true);
      expect(transitions[0].targetPhase).toBe('Operations');
    });

    it('should check ANY_OF transition conditions', async () => {
      const source = `
        TRANSITION EarlyTermination
          WHEN ANY_OF(
            BorrowerDefault,
            MaterialAdverseChange
          )
      `;
      const ast = await parseOrThrow(source);
      const interpreter = new CreditLangInterpreter(ast);

      // Not triggered initially
      let transitions = interpreter.checkPhaseTransitions();
      expect(transitions[0].triggered).toBe(false);

      // Satisfy just one condition
      interpreter.satisfyCondition('MaterialAdverseChange');

      transitions = interpreter.checkPhaseTransitions();
      expect(transitions[0].triggered).toBe(true);
    });

    it('should track and clear satisfied conditions', async () => {
      const source = `
        PHASE Construction
          UNTIL COD_Achieved
      `;
      const ast = await parseOrThrow(source);
      const interpreter = new CreditLangInterpreter(ast);

      expect(interpreter.isConditionSatisfied('TestCondition')).toBe(false);

      interpreter.satisfyCondition('TestCondition');
      expect(interpreter.isConditionSatisfied('TestCondition')).toBe(true);

      interpreter.clearCondition('TestCondition');
      expect(interpreter.isConditionSatisfied('TestCondition')).toBe(false);
    });
  });

  describe('Interpreter - Status Report with Phases', () => {
    it('should include phase info in status report', async () => {
      const source = `
        PHASE Construction
          UNTIL COD_Achieved
          COVENANTS SUSPENDED MaxLeverage

        COVENANT MaxLeverage
          REQUIRES Leverage <= 4.5
          TESTED QUARTERLY

        DEFINE Leverage AS total_debt / ebitda
      `;
      const ast = await parseOrThrow(source);
      const interpreter = new CreditLangInterpreter(ast);

      interpreter.loadFinancials({
        total_debt: 3000000,
        ebitda: 1000000
      });

      const status = interpreter.getStatus();

      expect(status.currentPhase).toBe('Construction');
      expect(status.suspendedCovenants).toContain('MaxLeverage');
      // Should only check active covenants (none in this case since only one covenant which is suspended)
      expect(status.covenants).toHaveLength(0);
    });

    it('should check covenants without phase info when no phases defined', async () => {
      const source = `
        COVENANT MaxLeverage
          REQUIRES Leverage <= 4.5
          TESTED QUARTERLY

        DEFINE Leverage AS total_debt / ebitda
      `;
      const ast = await parseOrThrow(source);
      const interpreter = new CreditLangInterpreter(ast);

      interpreter.loadFinancials({
        total_debt: 3000000,
        ebitda: 1000000
      });

      const status = interpreter.getStatus();

      expect(status.currentPhase).toBeUndefined();
      expect(status.suspendedCovenants).toBeUndefined();
      expect(status.covenants).toHaveLength(1);
    });
  });

  describe('Integration - Full Project Finance Flow', () => {
    it('should simulate construction to operations transition', async () => {
      const source = `
        // Phases
        PHASE Construction
          UNTIL COD_Achieved
          COVENANTS SUSPENDED TotalLeverage, InterestCoverage
          REQUIRED MinEquityContribution

        PHASE Operations
          FROM COD_Achieved
          COVENANTS ACTIVE TotalLeverage, InterestCoverage, MinDSCR

        // Transition
        TRANSITION COD_Achieved
          WHEN ALL_OF(
            SubstantialCompletion,
            LenderCertification
          )

        // Covenants
        COVENANT TotalLeverage
          REQUIRES Leverage <= 4.50
          TESTED QUARTERLY

        COVENANT InterestCoverage
          REQUIRES EBITDA / interest_expense >= 2.50
          TESTED QUARTERLY

        COVENANT MinDSCR
          REQUIRES DSCR >= 1.25
          TESTED QUARTERLY

        COVENANT MinEquityContribution
          REQUIRES equity_pct >= 0.35
          TESTED MONTHLY

        // Definitions
        DEFINE Leverage AS TotalDebt / EBITDA
        DEFINE TotalDebt AS senior_debt + subordinated_debt
        DEFINE EBITDA AS net_income + interest_expense + depreciation
        DEFINE DSCR AS EBITDA / debt_service
        DEFINE equity_pct AS equity_contributed / total_project_cost
      `;
      const ast = await parseOrThrow(source);
      const interpreter = new CreditLangInterpreter(ast);

      interpreter.loadFinancials({
        net_income: 5000000,
        interest_expense: 2000000,
        depreciation: 3000000,
        senior_debt: 30000000,
        subordinated_debt: 0,
        debt_service: 6000000,
        equity_contributed: 18000000,
        total_project_cost: 50000000
      });

      // CONSTRUCTION PHASE
      expect(interpreter.getCurrentPhase()).toBe('Construction');

      // Leverage covenants should be suspended
      expect(interpreter.getSuspendedCovenants()).toContain('TotalLeverage');
      expect(interpreter.getSuspendedCovenants()).toContain('InterestCoverage');

      // Only check active covenants (MinEquityContribution in this setup)
      const constructionResults = interpreter.checkActiveCovenants();
      expect(constructionResults.some(r => r.name === 'TotalLeverage')).toBe(false);

      // Check transition status
      let transitions = interpreter.checkPhaseTransitions();
      expect(transitions[0].triggered).toBe(false);

      // Satisfy construction milestones
      interpreter.satisfyCondition('SubstantialCompletion');
      interpreter.satisfyCondition('LenderCertification');

      transitions = interpreter.checkPhaseTransitions();
      expect(transitions[0].triggered).toBe(true);

      // Execute transition
      interpreter.transitionTo('COD_Achieved');

      // OPERATIONS PHASE
      expect(interpreter.getCurrentPhase()).toBe('Operations');
      expect(interpreter.getSuspendedCovenants()).toEqual([]);

      // Now all covenants should be active
      const operationsResults = interpreter.checkActiveCovenants();
      expect(operationsResults.map(r => r.name)).toContain('TotalLeverage');
      expect(operationsResults.map(r => r.name)).toContain('InterestCoverage');
      expect(operationsResults.map(r => r.name)).toContain('MinDSCR');
    });
  });
});

// ==================== MILESTONE TESTS ====================

describe('Milestones', () => {
  it('should parse MILESTONE statements', async () => {
    const source = `
      MILESTONE FoundationComplete
        TARGET 2024-06-30
        LONGSTOP 2024-09-30
        TRIGGERS Draw2Available
    `;
    const ast = await parseOrThrow(source);
    const milestone = ast.statements.find(s => s.type === 'Milestone') as any;
    expect(milestone).toBeDefined();
    expect(milestone.name).toBe('FoundationComplete');
    expect(milestone.targetDate).toBe('2024-06-30');
    expect(milestone.longstopDate).toBe('2024-09-30');
    expect(milestone.triggers).toEqual(['Draw2Available']);
  });

  it('should parse MILESTONE with REQUIRES', async () => {
    const source = `
      MILESTONE SubstantialCompletion
        TARGET 2025-06-15
        LONGSTOP 2025-08-15
        REQUIRES ALL_OF(RoofComplete, MEPComplete)
        TRIGGERS COD_Achieved
    `;
    const ast = await parseOrThrow(source);
    const milestone = ast.statements.find(s => s.type === 'Milestone') as any;
    expect(milestone.requires.type).toBe('AllOf');
    expect(milestone.requires.conditions).toEqual(['RoofComplete', 'MEPComplete']);
  });

  it('should parse MILESTONE with single prerequisite', async () => {
    const source = `
      MILESTONE SteelErection
        TARGET 2024-09-30
        LONGSTOP 2024-12-31
        REQUIRES FoundationComplete
    `;
    const ast = await parseOrThrow(source);
    const milestone = ast.statements.find(s => s.type === 'Milestone') as any;
    expect(milestone.requires).toBe('FoundationComplete');
  });

  it('should track milestone status', async () => {
    const source = `
      MILESTONE FoundationComplete
        TARGET 2024-06-30
        LONGSTOP 2024-09-30
    `;
    const ast = await parseOrThrow(source);
    const interpreter = new CreditLangInterpreter(ast);

    // Check pending status (using a date before target)
    const status = interpreter.getMilestoneStatus('FoundationComplete', new Date('2024-05-01'));
    expect(status.status).toBe('pending');
    expect(status.daysToTarget).toBe(60);
    expect(status.daysToLongstop).toBe(152);
  });

  it('should detect at_risk status', async () => {
    const source = `
      MILESTONE FoundationComplete
        TARGET 2024-06-30
        LONGSTOP 2024-09-30
    `;
    const ast = await parseOrThrow(source);
    const interpreter = new CreditLangInterpreter(ast);

    // Check at_risk status (past target, before longstop)
    const status = interpreter.getMilestoneStatus('FoundationComplete', new Date('2024-08-01'));
    expect(status.status).toBe('at_risk');
  });

  it('should detect breached status', async () => {
    const source = `
      MILESTONE FoundationComplete
        TARGET 2024-06-30
        LONGSTOP 2024-09-30
    `;
    const ast = await parseOrThrow(source);
    const interpreter = new CreditLangInterpreter(ast);

    // Check breached status (past longstop)
    const status = interpreter.getMilestoneStatus('FoundationComplete', new Date('2024-10-15'));
    expect(status.status).toBe('breached');
  });

  it('should mark milestone as achieved', async () => {
    const source = `
      MILESTONE FoundationComplete
        TARGET 2024-06-30
        LONGSTOP 2024-09-30
        TRIGGERS Draw2Available
    `;
    const ast = await parseOrThrow(source);
    const interpreter = new CreditLangInterpreter(ast);

    interpreter.achieveMilestone('FoundationComplete', new Date('2024-06-22'));

    const status = interpreter.getMilestoneStatus('FoundationComplete');
    expect(status.status).toBe('achieved');
    expect(status.achievedDate).toBe('2024-06-22');

    // Trigger should be satisfied
    expect(interpreter.isConditionSatisfied('Draw2Available')).toBe(true);
  });

  it('should check milestone prerequisites', async () => {
    const source = `
      MILESTONE FoundationComplete
        TARGET 2024-06-30
        LONGSTOP 2024-09-30

      MILESTONE SteelErection
        TARGET 2024-09-30
        LONGSTOP 2024-12-31
        REQUIRES FoundationComplete
    `;
    const ast = await parseOrThrow(source);
    const interpreter = new CreditLangInterpreter(ast);

    // Prerequisites not met
    expect(interpreter.areMilestonePrerequisitesMet('SteelErection')).toBe(false);

    // Achieve prerequisite
    interpreter.achieveMilestone('FoundationComplete');
    expect(interpreter.areMilestonePrerequisitesMet('SteelErection')).toBe(true);
  });

  it('should get all milestone statuses', async () => {
    const source = `
      MILESTONE FoundationComplete
        TARGET 2024-06-30
        LONGSTOP 2024-09-30

      MILESTONE SteelErection
        TARGET 2024-09-30
        LONGSTOP 2024-12-31
    `;
    const ast = await parseOrThrow(source);
    const interpreter = new CreditLangInterpreter(ast);

    const statuses = interpreter.getAllMilestoneStatuses(new Date('2024-05-01'));
    expect(statuses.length).toBe(2);
    expect(statuses.map(s => s.name)).toEqual(['FoundationComplete', 'SteelErection']);
  });
});

// ==================== RESERVE TESTS ====================

describe('Reserves', () => {
  it('should parse RESERVE statements', async () => {
    const source = `
      DEFINE monthly_debt_service AS 5_000_000

      RESERVE DebtServiceReserve
        TARGET 6 * monthly_debt_service
        MINIMUM 3 * monthly_debt_service
        FUNDED_BY Waterfall, EquityContribution
        RELEASED_TO Waterfall
    `;
    const ast = await parseOrThrow(source);
    const reserve = ast.statements.find(s => s.type === 'Reserve') as any;
    expect(reserve).toBeDefined();
    expect(reserve.name).toBe('DebtServiceReserve');
    expect(reserve.fundedBy).toEqual(['Waterfall', 'EquityContribution']);
    expect(reserve.releasedTo).toBe('Waterfall');
  });

  it('should parse RESERVE with RELEASED_FOR', async () => {
    const source = `
      DEFINE annual_capex_budget AS 16_000_000

      RESERVE MaintenanceReserve
        TARGET annual_capex_budget
        MINIMUM 0.5 * annual_capex_budget
        FUNDED_BY Waterfall
        RELEASED_FOR PermittedCapEx
    `;
    const ast = await parseOrThrow(source);
    const reserve = ast.statements.find(s => s.type === 'Reserve') as any;
    expect(reserve.releasedFor).toBe('PermittedCapEx');
  });

  it('should calculate reserve status', async () => {
    const source = `
      DEFINE monthly_debt_service AS 5_000_000

      RESERVE DebtServiceReserve
        TARGET 6 * monthly_debt_service
        MINIMUM 3 * monthly_debt_service
    `;
    const ast = await parseOrThrow(source);
    const interpreter = new CreditLangInterpreter(ast);
    interpreter.loadFinancials({ monthly_debt_service: 5000000 });

    const status = interpreter.getReserveStatus('DebtServiceReserve');
    expect(status.target).toBe(30000000); // 6 * 5M
    expect(status.minimum).toBe(15000000); // 3 * 5M
    expect(status.balance).toBe(0);
    expect(status.fundedPercent).toBe(0);
    expect(status.belowMinimum).toBe(true);
    expect(status.availableForRelease).toBe(0);
  });

  it('should fund reserve accounts', async () => {
    const source = `
      RESERVE DebtServiceReserve
        TARGET 30_000_000
        MINIMUM 15_000_000
    `;
    const ast = await parseOrThrow(source);
    const interpreter = new CreditLangInterpreter(ast);

    interpreter.fundReserve('DebtServiceReserve', 20000000);

    const status = interpreter.getReserveStatus('DebtServiceReserve');
    expect(status.balance).toBe(20000000);
    expect(status.fundedPercent).toBeCloseTo(66.67, 1);
    expect(status.belowMinimum).toBe(false);
    expect(status.availableForRelease).toBe(5000000); // 20M - 15M minimum
  });

  it('should draw from reserve accounts', async () => {
    const source = `
      RESERVE DebtServiceReserve
        TARGET 30_000_000
        MINIMUM 15_000_000
    `;
    const ast = await parseOrThrow(source);
    const interpreter = new CreditLangInterpreter(ast);

    interpreter.setReserveBalance('DebtServiceReserve', 25000000);

    // Can only draw down to minimum
    const drawn = interpreter.drawFromReserve('DebtServiceReserve', 20000000);
    expect(drawn).toBe(10000000); // Can only draw 25M - 15M minimum = 10M

    const status = interpreter.getReserveStatus('DebtServiceReserve');
    expect(status.balance).toBe(15000000);
  });

  it('should get all reserve statuses', async () => {
    const source = `
      RESERVE DebtServiceReserve
        TARGET 30_000_000
        MINIMUM 15_000_000

      RESERVE MaintenanceReserve
        TARGET 16_000_000
        MINIMUM 8_000_000
    `;
    const ast = await parseOrThrow(source);
    const interpreter = new CreditLangInterpreter(ast);

    const statuses = interpreter.getAllReserveStatuses();
    expect(statuses.length).toBe(2);
    expect(statuses.map(s => s.name)).toContain('DebtServiceReserve');
    expect(statuses.map(s => s.name)).toContain('MaintenanceReserve');
  });
});

// ==================== WATERFALL TESTS ====================

describe('Waterfalls', () => {
  it('should parse WATERFALL statements', async () => {
    const source = `
      WATERFALL OperatingWaterfall
        FREQUENCY monthly

        TIER 1 "Operating Expenses"
          PAY operating_expenses
          FROM Revenue

        TIER 2 "Senior Debt Service"
          PAY senior_debt_service
          FROM REMAINDER
    `;
    const ast = await parseOrThrow(source);
    const waterfall = ast.statements.find(s => s.type === 'Waterfall') as any;
    expect(waterfall).toBeDefined();
    expect(waterfall.name).toBe('OperatingWaterfall');
    expect(waterfall.frequency).toBe('monthly');
    expect(waterfall.tiers.length).toBe(2);
    expect(waterfall.tiers[0].name).toBe('Operating Expenses');
    expect(waterfall.tiers[0].from).toBe('Revenue');
  });

  it('should parse WATERFALL with PAY TO reserve', async () => {
    const source = `
      WATERFALL OperatingWaterfall
        FREQUENCY monthly

        TIER 3 "DSRA Replenishment"
          PAY TO DebtServiceReserve
          UNTIL DebtServiceReserve >= 30_000_000
          FROM REMAINDER
    `;
    const ast = await parseOrThrow(source);
    const waterfall = ast.statements.find(s => s.type === 'Waterfall') as any;
    expect(waterfall.tiers[0].payTo).toBe('DebtServiceReserve');
    expect(waterfall.tiers[0].until).toBeDefined();
  });

  it('should parse WATERFALL with SHORTFALL and IF', async () => {
    const source = `
      DEFINE MinDSCR AS 1.25

      WATERFALL OperatingWaterfall
        FREQUENCY monthly

        TIER 2 "Debt Service"
          PAY senior_debt_service
          FROM REMAINDER
          SHORTFALL -> DebtServiceReserve

        TIER 5 "Distributions"
          IF DSCR >= 1.50
          PAY distributions
          FROM REMAINDER
    `;
    const ast = await parseOrThrow(source);
    const waterfall = ast.statements.find(s => s.type === 'Waterfall') as any;
    expect(waterfall.tiers[0].shortfall).toBe('DebtServiceReserve');
    expect(waterfall.tiers[1].condition).toBeDefined();
  });

  it('should execute simple waterfall', async () => {
    const source = `
      WATERFALL TestWaterfall
        FREQUENCY monthly

        TIER 1 "OpEx"
          PAY 3_000_000
          FROM Revenue

        TIER 2 "Debt Service"
          PAY 4_000_000
          FROM REMAINDER
    `;
    const ast = await parseOrThrow(source);
    const interpreter = new CreditLangInterpreter(ast);

    const result = interpreter.executeWaterfall('TestWaterfall', 10000000);

    expect(result.totalRevenue).toBe(10000000);
    expect(result.tiers[0].paid).toBe(3000000);
    expect(result.tiers[1].paid).toBe(4000000);
    expect(result.remainder).toBe(3000000);
    expect(result.totalDistributed).toBe(7000000);
  });

  it('should handle waterfall shortfall', async () => {
    const source = `
      RESERVE DebtServiceReserve
        TARGET 30_000_000
        MINIMUM 0

      WATERFALL TestWaterfall
        FREQUENCY monthly

        TIER 1 "Debt Service"
          PAY 10_000_000
          FROM Revenue
          SHORTFALL -> DebtServiceReserve
    `;
    const ast = await parseOrThrow(source);
    const interpreter = new CreditLangInterpreter(ast);
    interpreter.setReserveBalance('DebtServiceReserve', 8000000);

    // Only $5M available, need $10M, should draw $5M from reserve
    const result = interpreter.executeWaterfall('TestWaterfall', 5000000);

    expect(result.tiers[0].requested).toBe(10000000);
    expect(result.tiers[0].paid).toBe(10000000); // Paid in full with reserve draw
    expect(result.tiers[0].shortfall).toBe(0);
    expect(result.tiers[0].reserveDrawn).toBe(5000000);

    // Reserve should be drawn down
    const reserveStatus = interpreter.getReserveStatus('DebtServiceReserve');
    expect(reserveStatus.balance).toBe(3000000);
  });

  it('should block distribution tier on condition', async () => {
    const source = `
      DEFINE DSCR AS 1.20

      WATERFALL TestWaterfall
        FREQUENCY monthly

        TIER 1 "OpEx"
          PAY 1_000_000
          FROM Revenue

        TIER 2 "Distributions"
          IF DSCR >= 1.50
          PAY 5_000_000
          FROM REMAINDER
    `;
    const ast = await parseOrThrow(source);
    const interpreter = new CreditLangInterpreter(ast);
    interpreter.loadFinancials({ DSCR: 1.20 });

    const result = interpreter.executeWaterfall('TestWaterfall', 10000000);

    expect(result.tiers[1].blocked).toBe(true);
    expect(result.tiers[1].blockReason).toBe('Condition not met');
    expect(result.tiers[1].paid).toBe(0);
    expect(result.remainder).toBe(9000000); // Only OpEx paid
  });

  it('should pay into reserve with UNTIL condition', async () => {
    const source = `
      RESERVE DebtServiceReserve
        TARGET 30_000_000
        MINIMUM 0

      WATERFALL TestWaterfall
        FREQUENCY monthly

        TIER 1 "Reserve Replenishment"
          PAY TO DebtServiceReserve
          UNTIL DebtServiceReserve >= 30_000_000
          FROM Revenue
    `;
    const ast = await parseOrThrow(source);
    const interpreter = new CreditLangInterpreter(ast);
    interpreter.setReserveBalance('DebtServiceReserve', 25000000);

    // Should only pay 5M to reach target
    const result = interpreter.executeWaterfall('TestWaterfall', 10000000);

    expect(result.tiers[0].requested).toBe(5000000); // Only need 5M to reach target
    expect(result.tiers[0].paid).toBe(5000000);
    expect(result.remainder).toBe(5000000);

    const reserveStatus = interpreter.getReserveStatus('DebtServiceReserve');
    expect(reserveStatus.balance).toBe(30000000);
  });
});

// ==================== CONDITIONS PRECEDENT TESTS ====================

describe('Conditions Precedent', () => {
  it('should parse CONDITIONS_PRECEDENT statements', async () => {
    const source = `
      CONDITIONS_PRECEDENT InitialFunding
        SECTION "4.01"

        CP ExecutedCreditAgreement
          DESCRIPTION "Executed Credit Agreement"
          RESPONSIBLE Agent

        CP LegalOpinions
          DESCRIPTION "Opinions of Borrower's Counsel"
          RESPONSIBLE BorrowerCounsel
    `;
    const ast = await parseOrThrow(source);
    const cp = ast.statements.find(s => s.type === 'ConditionsPrecedent') as any;
    expect(cp).toBeDefined();
    expect(cp.name).toBe('InitialFunding');
    expect(cp.section).toBe('4.01');
    expect(cp.conditions.length).toBe(2);
    expect(cp.conditions[0].name).toBe('ExecutedCreditAgreement');
    expect(cp.conditions[0].responsible).toBe('Agent');
  });

  it('should parse CP with STATUS and SATISFIES', async () => {
    const source = `
      CONDITIONS_PRECEDENT Draw2
        SECTION "4.02"

        CP InsuranceCertificate
          DESCRIPTION "Evidence of Required Insurance"
          RESPONSIBLE Borrower
          STATUS pending
          SATISFIES InsuranceInPlace
    `;
    const ast = await parseOrThrow(source);
    const cp = ast.statements.find(s => s.type === 'ConditionsPrecedent') as any;
    expect(cp.conditions[0].status).toBe('pending');
    expect(cp.conditions[0].satisfies).toEqual(['InsuranceInPlace']);
  });

  it('should track CP checklist status', async () => {
    const source = `
      CONDITIONS_PRECEDENT InitialFunding
        SECTION "4.01"

        CP Item1
          DESCRIPTION "First item"
          STATUS pending

        CP Item2
          DESCRIPTION "Second item"
          STATUS satisfied

        CP Item3
          DESCRIPTION "Third item"
          STATUS waived
    `;
    const ast = await parseOrThrow(source);
    const interpreter = new CreditLangInterpreter(ast);

    const checklist = interpreter.getCPChecklist('InitialFunding');
    expect(checklist.totalConditions).toBe(3);
    expect(checklist.satisfied).toBe(1);
    expect(checklist.pending).toBe(1);
    expect(checklist.waived).toBe(1);
    expect(checklist.complete).toBe(false); // Still has pending
  });

  it('should update CP status', async () => {
    const source = `
      CONDITIONS_PRECEDENT InitialFunding
        SECTION "4.01"

        CP Item1
          DESCRIPTION "First item"
          STATUS pending
          SATISFIES Condition1
    `;
    const ast = await parseOrThrow(source);
    const interpreter = new CreditLangInterpreter(ast);

    // Update status
    interpreter.updateCPStatus('InitialFunding', 'Item1', 'satisfied');

    const checklist = interpreter.getCPChecklist('InitialFunding');
    expect(checklist.satisfied).toBe(1);
    expect(checklist.pending).toBe(0);
    expect(checklist.complete).toBe(true);

    // Should trigger satisfied condition
    expect(interpreter.isConditionSatisfied('Condition1')).toBe(true);
  });

  it('should check if draw is allowed', async () => {
    const source = `
      CONDITIONS_PRECEDENT Draw1
        CP Item1
          STATUS pending

      CONDITIONS_PRECEDENT Draw2
        CP Item2
          STATUS satisfied
    `;
    const ast = await parseOrThrow(source);
    const interpreter = new CreditLangInterpreter(ast);

    expect(interpreter.isDrawAllowed('Draw1')).toBe(false);
    expect(interpreter.isDrawAllowed('Draw2')).toBe(true);
  });

  it('should list all CP checklists', async () => {
    const source = `
      CONDITIONS_PRECEDENT InitialFunding
        CP Item1
          STATUS pending

      CONDITIONS_PRECEDENT Draw3
        CP Item2
          STATUS pending
    `;
    const ast = await parseOrThrow(source);
    const interpreter = new CreditLangInterpreter(ast);

    const names = interpreter.getCPChecklistNames();
    expect(names).toContain('InitialFunding');
    expect(names).toContain('Draw3');
  });
});

// ==================== INTEGRATION TESTS ====================

describe('Project Finance Integration', () => {
  it('should handle complete project finance scenario', async () => {
    const source = `
      // Phases
      PHASE Construction
        UNTIL COD_Achieved
        COVENANTS SUSPENDED TotalLeverage

      PHASE Operations
        FROM COD_Achieved
        COVENANTS ACTIVE TotalLeverage, MinDSCR

      TRANSITION COD_Achieved
        WHEN ALL_OF(SubstantialCompletion, LenderCert)

      // Milestones
      MILESTONE FoundationComplete
        TARGET 2024-06-30
        LONGSTOP 2024-09-30
        TRIGGERS Draw2Available

      MILESTONE SubstantialCompletion
        TARGET 2025-06-15
        LONGSTOP 2025-08-15
        REQUIRES FoundationComplete
        TRIGGERS COD_Achieved

      // Definitions
      DEFINE TotalDebt AS total_debt
      DEFINE EBITDA AS ebitda
      DEFINE Leverage AS TotalDebt / EBITDA
      DEFINE DSCR AS 1.50

      // Covenants
      COVENANT TotalLeverage
        REQUIRES Leverage <= 4.50
        TESTED QUARTERLY

      COVENANT MinDSCR
        REQUIRES DSCR >= 1.25
        TESTED QUARTERLY

      // Reserves
      RESERVE DebtServiceReserve
        TARGET 30_000_000
        MINIMUM 15_000_000

      // Waterfall
      WATERFALL OperatingWaterfall
        FREQUENCY monthly

        TIER 1 "OpEx"
          PAY operating_expenses
          FROM Revenue

        TIER 2 "Debt Service"
          PAY debt_service
          FROM REMAINDER
          SHORTFALL -> DebtServiceReserve

        TIER 3 "DSRA"
          PAY TO DebtServiceReserve
          UNTIL DebtServiceReserve >= 30_000_000
          FROM REMAINDER

      // Conditions Precedent
      CONDITIONS_PRECEDENT Draw2
        CP LienSearch
          RESPONSIBLE Agent
          STATUS pending

        CP InsuranceCert
          RESPONSIBLE Borrower
          STATUS pending
    `;
    const ast = await parseOrThrow(source);
    const interpreter = new CreditLangInterpreter(ast);

    // Load financial data
    interpreter.loadFinancials({
      total_debt: 100000000,
      ebitda: 30000000,
      operating_expenses: 5000000,
      debt_service: 8000000,
    });

    // CONSTRUCTION PHASE
    expect(interpreter.getCurrentPhase()).toBe('Construction');
    expect(interpreter.getSuspendedCovenants()).toContain('TotalLeverage');

    // Check milestones
    expect(interpreter.hasMilestones()).toBe(true);
    const milestoneStatus = interpreter.getMilestoneStatus('FoundationComplete', new Date('2024-05-01'));
    expect(milestoneStatus.status).toBe('pending');

    // Achieve milestone
    interpreter.achieveMilestone('FoundationComplete');
    expect(interpreter.isConditionSatisfied('Draw2Available')).toBe(true);

    // Check reserves
    expect(interpreter.hasReserves()).toBe(true);
    interpreter.setReserveBalance('DebtServiceReserve', 20000000);
    const reserveStatus = interpreter.getReserveStatus('DebtServiceReserve');
    expect(reserveStatus.belowMinimum).toBe(false);

    // Execute waterfall
    const waterfallResult = interpreter.executeWaterfall('OperatingWaterfall', 20000000);
    expect(waterfallResult.tiers.length).toBe(3);
    expect(waterfallResult.tiers[0].paid).toBe(5000000); // OpEx
    expect(waterfallResult.tiers[1].paid).toBe(8000000); // Debt Service

    // Check CP status
    const cpStatus = interpreter.getCPChecklist('Draw2');
    expect(cpStatus.pending).toBe(2);
    expect(interpreter.isDrawAllowed('Draw2')).toBe(false);

    // Satisfy CPs
    interpreter.updateCPStatus('Draw2', 'LienSearch', 'satisfied');
    interpreter.updateCPStatus('Draw2', 'InsuranceCert', 'satisfied');
    expect(interpreter.isDrawAllowed('Draw2')).toBe(true);

    // Complete transition to operations
    interpreter.satisfyCondition('SubstantialCompletion');
    interpreter.satisfyCondition('LenderCert');

    const transitions = interpreter.checkPhaseTransitions();
    expect(transitions.find(t => t.name === 'COD_Achieved')?.triggered).toBe(true);

    interpreter.transitionTo('COD_Achieved');
    expect(interpreter.getCurrentPhase()).toBe('Operations');
    expect(interpreter.getSuspendedCovenants()).toEqual([]);
  });
});
