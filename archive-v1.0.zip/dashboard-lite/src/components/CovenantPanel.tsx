import { CheckCircle2, XCircle, Pause } from 'lucide-react';
import { Card, CardHeader, CardBody } from './Card';
import { StatusBadge } from './StatusBadge';
import type { CovenantData } from '../types';

interface CovenantPanelProps {
  covenants: CovenantData[];
}

export function CovenantPanel({ covenants }: CovenantPanelProps) {
  const activeCovenants = covenants.filter(c => !c.suspended);
  const suspendedCovenants = covenants.filter(c => c.suspended);

  return (
    <Card>
      <CardHeader
        title="Covenant Compliance"
        subtitle={`${activeCovenants.filter(c => c.compliant).length}/${activeCovenants.length} passing`}
      />
      <CardBody className="p-0">
        {/* Active Covenants */}
        <div className="divide-y divide-slate-800">
          {activeCovenants.map((covenant) => (
            <CovenantRow key={covenant.name} covenant={covenant} />
          ))}
        </div>

        {/* Suspended Covenants Section */}
        {suspendedCovenants.length > 0 && (
          <div className="border-t border-slate-700 bg-slate-900/30">
            <div className="px-5 py-3 flex items-center gap-2">
              <Pause className="w-4 h-4 text-gray-500" />
              <span className="text-sm font-medium text-gray-500">
                Suspended During Construction ({suspendedCovenants.length})
              </span>
            </div>
            <div className="divide-y divide-slate-800/50">
              {suspendedCovenants.map((covenant) => (
                <CovenantRow key={covenant.name} covenant={covenant} />
              ))}
            </div>
          </div>
        )}
      </CardBody>
    </Card>
  );
}

interface CovenantRowProps {
  covenant: CovenantData;
}

function CovenantRow({ covenant }: CovenantRowProps) {
  const { name, actual, required, operator, compliant, headroom, suspended } = covenant;

  // Calculate usage percentage for the bar
  let usagePercent = 0;

  if (operator === '<=') {
    // For max covenants (like leverage), usage is actual/required
    usagePercent = Math.min((actual / required) * 100, 100);
  } else if (operator === '>=') {
    // For min covenants (like coverage), usage is required/actual
    usagePercent = Math.min((required / actual) * 100, 100);
  }

  // Format covenant name for display
  const displayName = name.replace(/([A-Z])/g, ' $1').trim();

  // Format the ratio display
  const formatValue = (val: number) => {
    if (val >= 100) return val.toFixed(0);
    if (val >= 10) return val.toFixed(1);
    return val.toFixed(2);
  };

  return (
    <div className={`px-5 py-4 ${suspended ? 'opacity-60' : ''}`}>
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-3">
          {suspended ? (
            <Pause className="w-5 h-5 text-gray-500" />
          ) : compliant ? (
            <CheckCircle2 className="w-5 h-5 text-emerald-500" />
          ) : (
            <XCircle className="w-5 h-5 text-red-500" />
          )}
          <div>
            <span className="text-sm font-medium text-white">{displayName}</span>
            {suspended && (
              <StatusBadge status="suspended" label="Suspended" />
            )}
          </div>
        </div>
        <div className="text-right">
          <div className="flex items-baseline gap-2">
            <span className={`text-lg font-semibold tabular-nums ${
              suspended ? 'text-gray-500' : compliant ? 'text-white' : 'text-red-400'
            }`}>
              {formatValue(actual)}x
            </span>
            <span className="text-sm text-gray-500">
              {operator} {formatValue(required)}x
            </span>
          </div>
          {headroom !== undefined && !suspended && (
            <span className={`text-xs ${compliant ? 'text-emerald-400' : 'text-red-400'}`}>
              {compliant ? '+' : ''}{formatValue(headroom)}x headroom
            </span>
          )}
        </div>
      </div>

      {/* Progress Bar */}
      <div className="progress-bar">
        <div
          className={`progress-bar-fill ${
            suspended
              ? 'bg-gray-600'
              : compliant
              ? 'bg-gradient-to-r from-emerald-600 to-emerald-500'
              : 'bg-gradient-to-r from-red-600 to-red-500'
          }`}
          style={{ width: `${usagePercent}%` }}
        />
      </div>

      {/* Visual Threshold Marker */}
      <div className="relative h-0">
        <div
          className="absolute -top-2 w-0.5 h-4 bg-gray-400"
          style={{ left: operator === '<=' ? '100%' : '0%' }}
        />
      </div>
    </div>
  );
}
