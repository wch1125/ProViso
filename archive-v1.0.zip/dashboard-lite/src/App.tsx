import {
  DashboardShell,
  ExecutiveSummary,
  PhaseTimeline,
  CovenantPanel,
  WaterfallChart,
  ReserveStatus,
  MilestoneTracker,
  CPChecklist,
} from './components';
import { demoData } from './data/demo';

function App() {
  const data = demoData;

  return (
    <DashboardShell
      projectName={data.project.name}
      facility={data.project.facility}
      currentPhase={data.phase.current}
    >
      {/* Executive Summary - Full Width */}
      <ExecutiveSummary data={data} />

      {/* Phase Timeline - Full Width */}
      <div className="mt-6">
        <PhaseTimeline phase={data.phase} />
      </div>

      {/* Main Grid - 3 Column Layout */}
      <div className="mt-6 grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column - Covenants */}
        <div className="lg:col-span-1">
          <CovenantPanel covenants={data.covenants} />
        </div>

        {/* Middle Column - Waterfall + Reserves */}
        <div className="lg:col-span-1 space-y-6">
          <WaterfallChart waterfall={data.waterfall} />
          <ReserveStatus reserves={data.reserves} />
        </div>

        {/* Right Column - Milestones + CPs */}
        <div className="lg:col-span-1 space-y-6">
          <MilestoneTracker milestones={data.milestones} />
          <CPChecklist checklists={data.conditionsPrecedent} />
        </div>
      </div>
    </DashboardShell>
  );
}

export default App;
