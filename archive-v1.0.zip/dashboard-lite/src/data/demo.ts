import type { DashboardData } from '../types';

// Demo data based on the Sunrise Solar Project example
export const demoData: DashboardData = {
  project: {
    name: "Sunrise Solar Project",
    facility: "$150M Construction + Term",
    sponsor: "Renewable Energy Partners",
    borrower: "Sunrise Solar Holdings LLC"
  },
  phase: {
    current: "construction",
    constructionStart: "2024-03-01",
    codTarget: "2025-06-15",
    maturity: "2040-06-15"
  },
  financials: {
    net_income: 8_000_000,
    interest_expense: 6_000_000,
    tax_expense: 2_000_000,
    depreciation: 4_000_000,
    amortization: 1_000_000,
    senior_debt: 100_000_000,
    subordinated_debt: 20_000_000,
    senior_interest: 4_000_000,
    senior_principal: 3_000_000,
    total_project_cost: 150_000_000,
    equity_contributed: 55_000_000,
    monthly_debt_service: 5_000_000,
    annual_capex_budget: 16_000_000,
    operating_expenses: 3_200_000,
    distributions: 5_000_000,
    Revenue: 12_500_000,
    total_assets: 180_000_000,
    EBITDA: 21_000_000 // Calculated: net_income + interest + tax + depreciation + amortization
  },
  covenants: [
    {
      name: "TotalLeverage",
      actual: 5.71,
      required: 4.50,
      operator: "<=",
      compliant: false,
      suspended: true // Suspended during construction
    },
    {
      name: "SeniorLeverage",
      actual: 4.76,
      required: 3.00,
      operator: "<=",
      compliant: false,
      suspended: true
    },
    {
      name: "InterestCoverage",
      actual: 3.50,
      required: 2.50,
      operator: ">=",
      compliant: true,
      headroom: 1.00,
      suspended: true
    },
    {
      name: "MinDSCR",
      actual: 3.00,
      required: 1.25,
      operator: ">=",
      compliant: true,
      headroom: 1.75,
      suspended: true
    },
    {
      name: "MinEquityContribution",
      actual: 36.67,
      required: 35.00,
      operator: ">=",
      compliant: true,
      headroom: 1.67
    }
  ],
  milestones: [
    {
      name: "Foundation Complete",
      target: "2024-06-30",
      longstop: "2024-09-30",
      status: "achieved",
      achievedDate: "2024-06-22"
    },
    {
      name: "Steel Erection",
      target: "2024-09-30",
      longstop: "2024-12-31",
      status: "achieved",
      achievedDate: "2024-10-15"
    },
    {
      name: "Roof Complete",
      target: "2025-01-15",
      longstop: "2025-03-15",
      status: "in_progress",
      percentComplete: 65
    },
    {
      name: "MEP Complete",
      target: "2025-04-01",
      longstop: "2025-06-01",
      status: "pending"
    },
    {
      name: "Substantial Completion",
      target: "2025-06-15",
      longstop: "2025-08-15",
      status: "pending"
    }
  ],
  reserves: [
    {
      name: "Debt Service Reserve",
      balance: 24_600_000,
      target: 30_000_000,
      minimum: 15_000_000
    },
    {
      name: "Maintenance Reserve",
      balance: 8_200_000,
      target: 16_000_000,
      minimum: 8_000_000
    }
  ],
  waterfall: {
    revenue: 12_500_000,
    tiers: [
      { name: "Operating Expenses", amount: 3_200_000 },
      { name: "Senior Debt Service", amount: 4_100_000 },
      { name: "DSRA Top-Up", amount: 800_000 },
      { name: "Maintenance Reserve", amount: 500_000 },
      { name: "Available for Distribution", amount: 3_900_000, blocked: true, reason: "DSCR < 1.50x" }
    ]
  },
  conditionsPrecedent: [
    {
      name: "Initial Funding",
      section: "4.01",
      conditions: [
        { name: "Executed Credit Agreement", description: "Executed Credit Agreement and all Loan Documents", responsible: "Agent", status: "satisfied" },
        { name: "Legal Opinions", description: "Opinions of Borrower's Counsel and Local Counsel", responsible: "Borrower Counsel", status: "satisfied" },
        { name: "Equity Contribution", description: "Evidence of Initial Equity Contribution", responsible: "Sponsor", status: "satisfied" },
        { name: "Insurance Certificates", description: "Evidence of Required Insurance Coverage", responsible: "Borrower", status: "satisfied" },
        { name: "Environmental Report", description: "Phase I Environmental Site Assessment", responsible: "Borrower", status: "satisfied" }
      ]
    },
    {
      name: "Draw 3",
      section: "4.02(c)",
      conditions: [
        { name: "Lien Search", description: "Updated Lien Search Results", responsible: "Agent", status: "satisfied" },
        { name: "Title Endorsement", description: "Date-Down Title Endorsement", responsible: "Borrower", status: "pending" },
        { name: "Construction Inspection", description: "Construction Inspection Report", responsible: "Engineering Consultant", status: "pending" },
        { name: "Contractor Waiver", description: "Contractor Partial Lien Waiver", responsible: "General Contractor", status: "satisfied" },
        { name: "Budget Reconciliation", description: "Updated Budget and Schedule", responsible: "Borrower", status: "pending" }
      ]
    }
  ]
};
