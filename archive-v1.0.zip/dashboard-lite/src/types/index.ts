// Dashboard types mirroring CreditLang interpreter types

export interface ProjectInfo {
  name: string;
  facility: string;
  sponsor: string;
  borrower: string;
}

export interface PhaseInfo {
  current: string;
  constructionStart: string;
  codTarget: string;
  maturity: string;
}

export interface CovenantData {
  name: string;
  actual: number;
  required: number;
  operator: '<=' | '>=' | '<' | '>' | '=' | '!=';
  compliant: boolean;
  headroom?: number;
  suspended?: boolean;
}

export interface MilestoneData {
  name: string;
  target: string;
  longstop: string;
  status: 'pending' | 'achieved' | 'at_risk' | 'breached' | 'in_progress';
  achievedDate?: string;
  percentComplete?: number;
}

export interface ReserveData {
  name: string;
  balance: number;
  target: number;
  minimum: number;
}

export interface WaterfallTierData {
  name: string;
  amount: number;
  blocked?: boolean;
  reason?: string;
}

export interface WaterfallData {
  revenue: number;
  tiers: WaterfallTierData[];
}

export interface CPItemData {
  name: string;
  description: string;
  responsible: string;
  status: 'pending' | 'satisfied' | 'waived' | 'not_applicable';
}

export interface CPChecklistData {
  name: string;
  section: string;
  conditions: CPItemData[];
}

export interface DashboardData {
  project: ProjectInfo;
  phase: PhaseInfo;
  financials: Record<string, number>;
  covenants: CovenantData[];
  milestones: MilestoneData[];
  reserves: ReserveData[];
  waterfall: WaterfallData;
  conditionsPrecedent: CPChecklistData[];
}
