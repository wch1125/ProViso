// CreditLang Type Definitions

// ==================== AST NODES ====================

export interface Program {
  type: 'Program';
  statements: Statement[];
}

export type Statement =
  | DefineStatement
  | CovenantStatement
  | BasketStatement
  | ConditionStatement
  | ProhibitStatement
  | EventStatement
  | LoadStatement
  | CommentStatement
  | AmendmentStatement;

export interface DefineStatement {
  type: 'Define';
  name: string;
  expression: Expression;
  modifiers: DefineModifiers;
}

export interface DefineModifiers {
  excluding?: string[];
  cap?: Expression;
}

export interface CovenantStatement {
  type: 'Covenant';
  name: string;
  requires: Expression | null;
  tested: Frequency | null;
  cure: CureMechanism | null;
  breach: string | null;
}

export type Frequency = 'quarterly' | 'annually' | 'monthly';

export interface CureMechanism {
  type: 'EquityCure' | 'PaymentCure';
  details: CureDetails;
}

export interface CureDetails {
  maxUses?: number;
  overPeriod?: string;
  maxAmount?: Expression;
  curePeriod?: Duration;
}

export interface BasketStatement {
  type: 'Basket';
  name: string;
  capacity: Expression | null;
  plus: Expression[];
  subjectTo: string[] | null;
  // Grower basket: minimum floor for the capacity
  floor: Expression | null;
  // Builder basket: expression that adds to capacity over time
  buildsFrom: Expression | null;
  // Builder basket: starting capacity amount
  starting: Expression | null;
  // Builder basket: maximum capacity cap
  maximum: Expression | null;
}

export interface ConditionStatement {
  type: 'Condition';
  name: string;
  expression: Expression;
}

export interface ProhibitStatement {
  type: 'Prohibit';
  target: string;
  exceptions: ExceptClause[];
}

export type ExceptClause = ExceptWhenClause | NotwithstandingClause;

export interface ExceptWhenClause {
  type: 'ExceptWhen';
  conditions: Expression[];
  notwithstanding?: string;
}

export interface NotwithstandingClause {
  type: 'Notwithstanding';
  reference: string;
}

export interface EventStatement {
  type: 'Event';
  name: string;
  triggers: Expression | null;
  gracePeriod: Duration | null;
  consequence: string | null;
}

export interface LoadStatement {
  type: 'Load';
  source: LoadSource;
}

export type LoadSource = FileSource | InlineSource;

export interface FileSource {
  type: 'file';
  path: string;
}

export interface InlineSource {
  type: 'inline';
  data: Record<string, unknown>;
}

export interface CommentStatement {
  type: 'Comment';
  text: string;
}

// ==================== EXPRESSIONS ====================

export type Expression =
  | string // Identifier
  | number
  | NumberLiteral
  | CurrencyLiteral
  | PercentageLiteral
  | RatioLiteral
  | BinaryExpression
  | UnaryExpression
  | ComparisonExpression
  | FunctionCallExpression
  | TrailingExpression;

export interface NumberLiteral {
  type: 'Number';
  value: number;
}

export interface CurrencyLiteral {
  type: 'Currency';
  value: number;
}

export interface PercentageLiteral {
  type: 'Percentage';
  value: number;
  unit?: 'bps';
}

export interface RatioLiteral {
  type: 'Ratio';
  value: number;
}

export interface BinaryExpression {
  type: 'BinaryExpression';
  operator: '+' | '-' | '*' | '/' | 'AND' | 'OR';
  left: Expression;
  right: Expression;
}

export interface UnaryExpression {
  type: 'UnaryExpression';
  operator: '-' | 'NOT';
  argument: Expression;
}

export interface ComparisonExpression {
  type: 'Comparison';
  operator: '<=' | '>=' | '<' | '>' | '=' | '!=';
  left: Expression;
  right: Expression;
}

export interface FunctionCallExpression {
  type: 'FunctionCall';
  name: string;
  arguments: Expression[];
}

/**
 * Trailing expression for period-based calculations.
 * Example: TRAILING 4 QUARTERS OF EBITDA
 */
export interface TrailingExpression {
  type: 'Trailing';
  /** Number of periods to include */
  count: number;
  /** Type of periods (quarters, months, years) */
  period: 'quarters' | 'months' | 'years';
  /** Expression to evaluate for each period */
  expression: Expression;
}

/**
 * Type guard for TrailingExpression
 */
export function isTrailingExpression(expr: Expression): expr is TrailingExpression {
  return isObjectExpression(expr) && expr.type === 'Trailing';
}

export interface Duration {
  type: 'Duration';
  amount: number;
  unit: 'days' | 'months' | 'years';
}

// ==================== TYPE GUARDS ====================

/**
 * Union type of all object-based expressions (excludes string and number primitives)
 */
export type ObjectExpression =
  | NumberLiteral
  | CurrencyLiteral
  | PercentageLiteral
  | RatioLiteral
  | BinaryExpression
  | UnaryExpression
  | ComparisonExpression
  | FunctionCallExpression
  | TrailingExpression;

/**
 * Check if an expression is an object-based expression (not a string identifier or number)
 */
export function isObjectExpression(expr: Expression): expr is ObjectExpression {
  return expr !== null && typeof expr === 'object';
}

/**
 * Check if an expression is a ComparisonExpression
 */
export function isComparisonExpression(expr: Expression): expr is ComparisonExpression {
  return isObjectExpression(expr) && expr.type === 'Comparison';
}

/**
 * Check if an expression is a BinaryExpression
 */
export function isBinaryExpression(expr: Expression): expr is BinaryExpression {
  return isObjectExpression(expr) && expr.type === 'BinaryExpression';
}

/**
 * Check if an expression is a UnaryExpression
 */
export function isUnaryExpression(expr: Expression): expr is UnaryExpression {
  return isObjectExpression(expr) && expr.type === 'UnaryExpression';
}

/**
 * Check if an expression is a FunctionCallExpression
 */
export function isFunctionCallExpression(expr: Expression): expr is FunctionCallExpression {
  return isObjectExpression(expr) && expr.type === 'FunctionCall';
}

// ==================== RUNTIME TYPES ====================

/**
 * Simple financial data - a flat record of metric names to values.
 * This is the original format and is still fully supported.
 */
export type SimpleFinancialData = Record<string, number>;

/**
 * Period-specific financial data with period identification.
 */
export interface PeriodData {
  /** Period identifier (e.g., "2024-Q1", "2024-Q2", "2024-12") */
  period: string;
  /** Type of period for interpretation */
  periodType: 'quarterly' | 'monthly' | 'annual';
  /** ISO date string for the period end date (e.g., "2024-03-31") */
  periodEnd: string;
  /** Financial data for this period */
  data: Record<string, number>;
}

/**
 * Multi-period financial data with multiple periods.
 */
export interface MultiPeriodFinancialData {
  /** Array of period data, typically in chronological order */
  periods: PeriodData[];
  /** Optional pre-calculated trailing values (e.g., trailing["LTM"]["EBITDA"]) */
  trailing?: Record<string, Record<string, number>>;
}

/**
 * Financial data can be either simple (flat) or multi-period.
 * The interpreter detects which format is used and handles it appropriately.
 */
export type FinancialData = SimpleFinancialData | MultiPeriodFinancialData;

/**
 * Type guard to check if financial data is multi-period format.
 */
export function isMultiPeriodData(data: unknown): data is MultiPeriodFinancialData {
  return (
    typeof data === 'object' &&
    data !== null &&
    'periods' in data &&
    Array.isArray((data as MultiPeriodFinancialData).periods)
  );
}

/**
 * Type guard to check if data is a PeriodData object.
 */
export function isPeriodData(data: unknown): data is PeriodData {
  return (
    typeof data === 'object' &&
    data !== null &&
    'period' in data &&
    'periodType' in data &&
    'periodEnd' in data &&
    'data' in data
  );
}

/**
 * Type guard to check if financial data is simple (flat) format.
 */
export function isSimpleFinancialData(data: unknown): data is SimpleFinancialData {
  if (typeof data !== 'object' || data === null) return false;
  // Simple data has no 'periods' key and all values are numbers
  if ('periods' in data) return false;
  return Object.values(data).every((v) => typeof v === 'number');
}

export interface CovenantResult {
  name: string;
  compliant: boolean;
  actual: number;
  threshold: number;
  operator: string;
  headroom?: number;
}

export interface BasketStatus {
  name: string;
  capacity: number;
  used: number;
  available: number;
  // For grower baskets: the calculated base capacity before floor
  baseCapacity?: number;
  // For grower baskets: the floor that was applied
  floor?: number;
  // For builder baskets: accumulated amount
  accumulated?: number;
  // For builder baskets: starting capacity
  starting?: number;
  // For builder baskets: maximum cap
  maximum?: number;
  // Basket classification
  basketType?: 'fixed' | 'grower' | 'builder';
}

export interface BasketLedgerEntry {
  timestamp: Date;
  basket: string;
  amount: number;
  description: string;
  // For builder baskets: whether this is an accumulation (+) or usage (-)
  entryType?: 'usage' | 'accumulation';
}

export interface QueryResult {
  permitted: boolean;
  reasoning: ReasoningStep[];
  warnings: string[];
}

export interface ReasoningStep {
  rule: string;
  evaluation: string;
  passed: boolean;
}

export interface SimulationResult {
  covenants: CovenantResult[];
  baskets: BasketStatus[];
}

export interface StatusReport {
  timestamp: Date;
  covenants: CovenantResult[];
  baskets: BasketStatus[];
  overallCompliant: boolean;
}

// ==================== PARSER TYPES ====================

export interface ParseErrorLocation {
  start: { line: number; column: number; offset?: number };
  end: { line: number; column: number; offset?: number };
}

export interface ParseError {
  message: string;
  location?: ParseErrorLocation;
  /** What the parser expected at the error position */
  expected?: string[];
  /** What was actually found at the error position */
  found?: string | null;
}

export interface ParseResult {
  success: boolean;
  ast?: Program;
  error?: ParseError;
  /** The source that was parsed (for error context display) */
  source?: string;
}

// ==================== VALIDATION TYPES ====================

export type ValidationSeverity = 'error' | 'warning';

export interface ValidationIssue {
  severity: ValidationSeverity;
  message: string;
  /** The name of the undefined or problematic reference */
  reference?: string;
  /** Where the issue occurred */
  context?: string;
  /** What type of reference was expected */
  expectedType?: 'define' | 'covenant' | 'basket' | 'condition' | 'event' | 'identifier';
}

export interface ValidationResult {
  valid: boolean;
  errors: ValidationIssue[];
  warnings: ValidationIssue[];
}

// ==================== CURE RIGHTS TYPES ====================

export type CureStatus = 'breach' | 'unmatured_default' | 'cured' | 'event_of_default';

export interface CureState {
  covenantName: string;
  breachDate: Date;
  cureDeadline: Date;
  status: CureStatus;
  cureAttempts: CureAttempt[];
}

export interface CureAttempt {
  date: Date;
  mechanism: string;
  amount: number;
  successful: boolean;
}

export interface CureUsage {
  mechanism: string;
  usesRemaining: number;
  totalUses: number;
  maxUses: number;
  period: string;
}

export interface CureResult {
  success: boolean;
  reason?: string;
  curedAmount?: number;
}

export interface CovenantResultWithCure extends CovenantResult {
  cureAvailable?: boolean;
  cureState?: CureState;
  shortfall?: number;
  cureMechanism?: CureMechanism;
}

// ==================== AMENDMENT TYPES ====================

export interface AmendmentStatement {
  type: 'Amendment';
  number: number;
  effective: DateLiteral | null;
  description: string | null;
  directives: AmendmentDirective[];
}

export interface DateLiteral {
  type: 'Date';
  value: string; // ISO format: YYYY-MM-DD
}

export type AmendmentDirective =
  | ReplaceDirective
  | AddDirective
  | DeleteDirective
  | ModifyDirective;

export interface ReplaceDirective {
  directive: 'replace';
  targetType: StatementTypeName;
  targetName: string;
  replacement: Statement;
}

export interface AddDirective {
  directive: 'add';
  statement: Statement;
}

export interface DeleteDirective {
  directive: 'delete';
  targetType: StatementTypeName;
  targetName: string;
}

export interface ModifyDirective {
  directive: 'modify';
  targetType: StatementTypeName;
  targetName: string;
  modifications: ModificationClause[];
}

export type StatementTypeName = 'Covenant' | 'Basket' | 'Condition' | 'Define' | 'Prohibit' | 'Event';

export interface ModificationClause {
  type: 'capacity' | 'floor' | 'maximum' | 'requires' | 'tested';
  value: Expression;
}
