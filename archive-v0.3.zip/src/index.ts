// CreditLang - Domain-Specific Language for Credit Agreements
// Main entry point

export * from './types.js';
export { parse, parseOrThrow, validate as validateSyntax } from './parser.js';
export { CreditLangInterpreter } from './interpreter.js';
export { validate as validateSemantics } from './validator.js';

// Closing room enums and helpers
export * from './closing-enums.js';

// Ontology system for declarative configuration
export * from './ontology.js';

// Defined terms system
export * from './defined-terms.js';
