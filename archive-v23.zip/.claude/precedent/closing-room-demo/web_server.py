#!/usr/bin/env python3
"""
Run the Legal Transaction Engine web interface.

Usage:
    python web_server.py
    
Then open http://localhost:8000 in your browser.
"""

import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / "src"))

if __name__ == "__main__":
    import uvicorn
    from web import app
    
    print("\n" + "="*60)
    print("  Legal Transaction Engine - Web Interface")
    print("="*60)
    print("\n  Starting server at http://localhost:8000")
    print("  Press Ctrl+C to stop\n")
    
    uvicorn.run(app, host="0.0.0.0", port=8000, log_level="info")
