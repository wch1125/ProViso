Transaction: ABC Corporation $150M Revolving Credit Facility
Created: 2025-12-09T11:53:50.684384

Folder Structure:
  1_Credit_Agreement
  2_Corporate_Documents
  3_Security_Documents
  4_Legal_Opinions
  5_Certificates
  6_Financial_Documents
  7_UCC_Filings
  8_Miscellaneous
  9_Executed_Originals

Place documents in the appropriate folders.
The system will auto-detect and match files to the closing checklist.
