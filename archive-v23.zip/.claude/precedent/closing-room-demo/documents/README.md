# Documentation

This folder contains user-facing and developer documentation.

## Suggested Structure

```
docs/
├── README.md           # This file
├── user-guide.md       # End-user documentation
├── developer-guide.md  # Developer setup and contribution guide
├── api-reference.md    # API documentation (if applicable)
├── architecture.md     # System architecture overview
└── deployment.md       # Deployment instructions
```

## Guidelines

- Keep documentation up to date with code changes
- Include examples for all features
- Write for your audience (users vs developers)
- Test all code examples before committing
