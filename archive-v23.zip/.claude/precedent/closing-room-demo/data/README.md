# Data

Project data files. This folder may contain sensitive information.

## Guidelines

- **Do not commit sensitive data** to version control
- Add patterns to `.gitignore` as needed
- Use environment variables for credentials
- Consider encryption for sensitive files

## Common Contents

- Database files (*.db, *.sqlite)
- Configuration files
- Seed data
- Uploaded files

## Security

This folder is partially gitignored. Check `.gitignore` for excluded patterns.
