#!/usr/bin/env python3
"""
Legal Transaction Engine - Command Line Interface

A simple CLI for managing credit agreement closings.

Usage (from project root):
    python -m src.cli create "Deal Name" --amount 100000000 --closing-date 2025-03-15
    python -m src.cli list
    python -m src.cli status <transaction_id>
    
Usage (from src folder):
    python cli.py create "Deal Name" --amount 100000000 --closing-date 2025-03-15
    python cli.py list
    python cli.py status <transaction_id>
"""

import argparse
import sys
import json
from datetime import date, datetime
from pathlib import Path

# Determine project root and add src to path
SCRIPT_DIR = Path(__file__).parent.resolve()
if SCRIPT_DIR.name == "src":
    PROJECT_ROOT = SCRIPT_DIR.parent
else:
    PROJECT_ROOT = SCRIPT_DIR

sys.path.insert(0, str(SCRIPT_DIR))

from engine import TransactionEngine
from models import (
    TransactionType, DocumentType, DocumentStatus, 
    PartyRole, ConditionStatus
)


def get_default_data_dir() -> str:
    """Determine the default data directory based on where the script is run from."""
    # Check if we're in src/ or project root
    cwd = Path.cwd().resolve()
    
    # If data/ exists in current directory, use it
    if (cwd / "data").exists():
        return str(cwd / "data")
    
    # If we're in src/, look for ../data
    if cwd.name == "src" and (cwd.parent / "data").exists():
        return str(cwd.parent / "data")
    
    # Default: create data/ relative to project root
    return str(PROJECT_ROOT / "data")


def format_currency(amount: float) -> str:
    """Format a number as currency."""
    if amount >= 1_000_000_000:
        return f"${amount/1_000_000_000:.1f}B"
    elif amount >= 1_000_000:
        return f"${amount/1_000_000:.1f}M"
    elif amount >= 1_000:
        return f"${amount/1_000:.1f}K"
    else:
        return f"${amount:,.2f}"


def print_table(headers: list[str], rows: list[list], widths: list[int] = None):
    """Print a simple ASCII table."""
    if not widths:
        widths = [max(len(str(row[i])) for row in [headers] + rows) + 2 
                  for i in range(len(headers))]
    
    # Header
    header_line = "│".join(f" {h:<{w-1}}" for h, w in zip(headers, widths))
    separator = "┼".join("─" * w for w in widths)
    
    print("┌" + "┬".join("─" * w for w in widths) + "┐")
    print("│" + header_line + "│")
    print("├" + separator + "┤")
    
    # Rows
    for row in rows:
        row_line = "│".join(f" {str(cell):<{w-1}}" for cell, w in zip(row, widths))
        print("│" + row_line + "│")
    
    print("└" + "┴".join("─" * w for w in widths) + "┘")


def cmd_create(args, engine: TransactionEngine):
    """Create a new transaction."""
    closing_date = None
    if args.closing_date:
        closing_date = date.fromisoformat(args.closing_date)
    
    txn_type = TransactionType.REVOLVING_CREDIT
    if args.type:
        try:
            txn_type = TransactionType(args.type)
        except ValueError:
            print(f"Invalid transaction type: {args.type}")
            print(f"Valid types: {[t.value for t in TransactionType]}")
            return
    
    txn = engine.create_transaction(
        name=args.name,
        transaction_type=txn_type,
        facility_amount=args.amount or 0,
        closing_date=closing_date,
        create_standard_documents=not args.no_docs,
        create_standard_conditions=not args.no_conditions,
    )
    
    print(f"\n✓ Created transaction: {txn.name}")
    print(f"  ID: {txn.id}")
    print(f"  Type: {txn.transaction_type.value}")
    print(f"  Amount: {format_currency(txn.facility_amount)}")
    print(f"  Closing Date: {txn.closing_date or 'TBD'}")
    print(f"  Documents: {len(txn.document_ids)}")
    print(f"  Conditions: {len(txn.condition_ids)}")
    print(f"\nUse 'python cli.py status {txn.id[:8]}' to view status")


def cmd_list(args, engine: TransactionEngine):
    """List all transactions."""
    transactions = engine.store.list_transactions()
    
    if not transactions:
        print("\nNo transactions found.")
        print("Create one with: python cli.py create \"Deal Name\" --amount 100000000")
        return
    
    print(f"\n{'='*60}")
    print("TRANSACTIONS")
    print(f"{'='*60}\n")
    
    headers = ["ID", "Name", "Amount", "Closing Date", "Status"]
    rows = []
    
    for txn in transactions:
        status = "CLOSED" if txn.is_closed else "OPEN"
        rows.append([
            txn.id[:8],
            txn.name[:30],
            format_currency(txn.facility_amount),
            str(txn.closing_date) if txn.closing_date else "TBD",
            status,
        ])
    
    print_table(headers, rows)


def cmd_status(args, engine: TransactionEngine):
    """Show transaction status."""
    # Find transaction by ID prefix
    txn = find_transaction(args.transaction_id, engine)
    if not txn:
        return
    
    summary = engine.get_status_summary(txn.id)
    
    print(f"\n{'='*60}")
    print(f"TRANSACTION STATUS: {summary['transaction']['name']}")
    print(f"{'='*60}\n")
    
    print(f"Facility Amount: {format_currency(summary['transaction']['facility_amount'])}")
    print(f"Closing Date: {summary['transaction']['closing_date'] or 'TBD'}")
    print(f"Status: {'CLOSED' if summary['transaction']['is_closed'] else 'OPEN'}")
    
    print(f"\n--- READINESS ---")
    print(f"Overall: {summary['readiness']['percentage']}% ({summary['readiness']['ready_items']}/{summary['readiness']['total_items']} items)")
    
    print(f"\n--- DOCUMENTS ({summary['documents']['total']}) ---")
    for status, count in summary['documents'].items():
        if status != 'total':
            print(f"  {status}: {count}")
    
    print(f"\n--- CONDITIONS ({summary['conditions']['total']}) ---")
    for status, count in summary['conditions'].items():
        if status != 'total':
            print(f"  {status}: {count}")
    
    if summary['outstanding']['documents'] or summary['outstanding']['conditions']:
        print(f"\n--- OUTSTANDING ITEMS ---")
        
        if summary['outstanding']['documents']:
            print(f"\nDocuments:")
            for doc in summary['outstanding']['documents'][:5]:
                print(f"  • {doc['title']} [{doc['status']}]")
            if len(summary['outstanding']['documents']) > 5:
                print(f"  ... and {len(summary['outstanding']['documents']) - 5} more")
        
        if summary['outstanding']['conditions']:
            print(f"\nConditions:")
            for cond in summary['outstanding']['conditions'][:5]:
                print(f"  • {cond['title']} [{cond['status']}]")
            if len(summary['outstanding']['conditions']) > 5:
                print(f"  ... and {len(summary['outstanding']['conditions']) - 5} more")


def cmd_checklist(args, engine: TransactionEngine):
    """Generate and display closing checklist."""
    txn = find_transaction(args.transaction_id, engine)
    if not txn:
        return
    
    checklist = engine.generate_checklist(txn.id)
    
    print(f"\n{'='*70}")
    print(f"CLOSING CHECKLIST: {txn.name}")
    print(f"{'='*70}")
    
    for section in checklist:
        if not section['items']:
            continue
            
        print(f"\n{section['section']}. {section['title']}")
        print("-" * 60)
        
        for item in section['items']:
            status_icon = get_status_icon(item['status'])
            print(f"  {item['number']:3}. {status_icon} {item['title']}")
            if item['responsible_party']:
                print(f"       Responsible: {item['responsible_party']}")
            if item['due_date']:
                print(f"       Due: {item['due_date']}")


def cmd_documents(args, engine: TransactionEngine):
    """List documents in a transaction."""
    txn = find_transaction(args.transaction_id, engine)
    if not txn:
        return
    
    documents = engine.store.list_documents(txn.id)
    
    print(f"\n{'='*60}")
    print(f"DOCUMENTS: {txn.name}")
    print(f"{'='*60}\n")
    
    # Group by type
    by_type = {}
    for doc in documents:
        doc_type = doc.document_type.value
        if doc_type not in by_type:
            by_type[doc_type] = []
        by_type[doc_type].append(doc)
    
    for doc_type, docs in sorted(by_type.items()):
        print(f"\n{doc_type.upper().replace('_', ' ')}")
        for doc in docs:
            status_icon = get_status_icon(doc.status.value)
            print(f"  {status_icon} {doc.title}")
            print(f"      ID: {doc.id[:8]}  Status: {doc.status.value}")


def cmd_conditions(args, engine: TransactionEngine):
    """List conditions precedent in a transaction."""
    txn = find_transaction(args.transaction_id, engine)
    if not txn:
        return
    
    conditions = engine.store.list_conditions(txn.id)
    
    print(f"\n{'='*60}")
    print(f"CONDITIONS PRECEDENT: {txn.name}")
    print(f"{'='*60}\n")
    
    for cond in sorted(conditions, key=lambda c: c.section_reference):
        status_icon = get_status_icon(cond.status.value)
        print(f"{status_icon} Section {cond.section_reference}: {cond.title}")
        print(f"    Status: {cond.status.value}")
        if cond.description:
            # Wrap description
            desc = cond.description[:100] + "..." if len(cond.description) > 100 else cond.description
            print(f"    {desc}")
        print()


def cmd_add_party(args, engine: TransactionEngine):
    """Add a party to a transaction."""
    txn = find_transaction(args.transaction_id, engine)
    if not txn:
        return
    
    # Parse roles
    roles = []
    for role_str in args.role:
        try:
            roles.append(PartyRole(role_str))
        except ValueError:
            print(f"Invalid role: {role_str}")
            print(f"Valid roles: {[r.value for r in PartyRole]}")
            return
    
    party = engine.add_party(
        txn_id=txn.id,
        name=args.name,
        roles=roles,
        short_name=args.short_name or "",
        jurisdiction=args.jurisdiction or "",
        entity_type=args.entity_type or "",
    )
    
    print(f"\n✓ Added party: {party.name}")
    print(f"  ID: {party.id[:8]}")
    print(f"  Roles: {[r.value for r in party.roles]}")


def cmd_update_doc(args, engine: TransactionEngine):
    """Update a document's status."""
    # Find document by ID prefix
    doc = find_document(args.document_id, engine)
    if not doc:
        return
    
    try:
        status = DocumentStatus(args.status)
    except ValueError:
        print(f"Invalid status: {args.status}")
        print(f"Valid statuses: {[s.value for s in DocumentStatus]}")
        return
    
    doc = engine.update_document_status(doc.id, status, args.notes or "")
    
    print(f"\n✓ Updated document: {doc.title}")
    print(f"  New status: {doc.status.value}")


def cmd_update_condition(args, engine: TransactionEngine):
    """Update a condition's status."""
    cond = find_condition(args.condition_id, engine)
    if not cond:
        return
    
    try:
        status = ConditionStatus(args.status)
    except ValueError:
        print(f"Invalid status: {args.status}")
        print(f"Valid statuses: {[s.value for s in ConditionStatus]}")
        return
    
    cond = engine.update_condition_status(cond.id, status, args.notes or "")
    
    print(f"\n✓ Updated condition: {cond.title}")
    print(f"  New status: {cond.status.value}")


def cmd_generate(args, engine: TransactionEngine):
    """Generate a document from template."""
    from docgen import DocumentGenerator
    
    txn = find_transaction(args.transaction_id, engine)
    if not txn:
        return
    
    # Set up output directory
    output_dir = PROJECT_ROOT / "output"
    output_dir.mkdir(exist_ok=True)
    
    generator = DocumentGenerator(
        data_dir=str(Path(engine.store.data_dir)),
        output_dir=str(output_dir)
    )
    
    try:
        if args.doc_type == "officers":
            path = generator.generate_officers_certificate(
                txn.id,
                officer_name=args.officer_name,
                officer_title=args.officer_title,
            )
        elif args.doc_type == "secretary":
            path = generator.generate_secretary_certificate(
                txn.id,
                secretary_name=args.secretary_name,
            )
        elif args.doc_type == "solvency":
            path = generator.generate_solvency_certificate(
                txn.id,
                officer_name=args.officer_name,
                officer_title=args.officer_title,
            )
        elif args.doc_type == "checklist":
            path = generator.generate_closing_checklist(txn.id)
        else:
            print(f"Unknown document type: {args.doc_type}")
            return
        
        print(f"\n✓ Generated document: {path}")
        print(f"  Open with: open \"{path}\"")
        
    except Exception as e:
        print(f"\n✗ Error generating document: {e}")
        import traceback
        traceback.print_exc()


def find_transaction(id_prefix: str, engine: TransactionEngine):
    """Find a transaction by ID prefix."""
    transactions = engine.store.list_transactions()
    matches = [t for t in transactions if t.id.startswith(id_prefix)]
    
    if len(matches) == 0:
        print(f"No transaction found matching '{id_prefix}'")
        return None
    elif len(matches) > 1:
        print(f"Multiple transactions match '{id_prefix}':")
        for t in matches:
            print(f"  {t.id[:8]}: {t.name}")
        return None
    
    return matches[0]


def find_document(id_prefix: str, engine: TransactionEngine):
    """Find a document by ID prefix."""
    all_docs = []
    for txn in engine.store.list_transactions():
        all_docs.extend(engine.store.list_documents(txn.id))
    
    matches = [d for d in all_docs if d.id.startswith(id_prefix)]
    
    if len(matches) == 0:
        print(f"No document found matching '{id_prefix}'")
        return None
    elif len(matches) > 1:
        print(f"Multiple documents match '{id_prefix}':")
        for d in matches:
            print(f"  {d.id[:8]}: {d.title}")
        return None
    
    return matches[0]


def find_condition(id_prefix: str, engine: TransactionEngine):
    """Find a condition by ID prefix."""
    all_conds = []
    for txn in engine.store.list_transactions():
        all_conds.extend(engine.store.list_conditions(txn.id))
    
    matches = [c for c in all_conds if c.id.startswith(id_prefix)]
    
    if len(matches) == 0:
        print(f"No condition found matching '{id_prefix}'")
        return None
    elif len(matches) > 1:
        print(f"Multiple conditions match '{id_prefix}':")
        for c in matches:
            print(f"  {c.id[:8]}: {c.title}")
        return None
    
    return matches[0]


def get_status_icon(status: str) -> str:
    """Get an icon for a status."""
    icons = {
        # Document statuses
        "not_started": "○",
        "drafting": "◐",
        "internal_review": "◑",
        "out_for_review": "◑",
        "comments_received": "◑",
        "final": "◉",
        "executed": "●",
        "filed": "●",
        "superseded": "×",
        # Condition statuses
        "pending": "○",
        "in_progress": "◐",
        "satisfied": "●",
        "waived": "◇",
        "not_applicable": "─",
    }
    return icons.get(status, "?")


def main():
    parser = argparse.ArgumentParser(
        description="Legal Transaction Engine CLI",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  Create a new transaction:
    python cli.py create "ABC Corp Credit Facility" --amount 100000000 --closing-date 2025-03-15
  
  List all transactions:
    python cli.py list
  
  View transaction status:
    python cli.py status abc123
  
  View closing checklist:
    python cli.py checklist abc123
  
  Add a party:
    python cli.py add-party abc123 "ABC Corporation" --role borrower --jurisdiction Delaware
  
  Update document status:
    python cli.py update-doc doc123 --status executed
        """
    )
    
    parser.add_argument("--data-dir", default=None, help="Data directory (default: auto-detect)")
    
    subparsers = parser.add_subparsers(dest="command", help="Commands")
    
    # CREATE command
    create_parser = subparsers.add_parser("create", help="Create a new transaction")
    create_parser.add_argument("name", help="Transaction name")
    create_parser.add_argument("--amount", type=float, help="Facility amount")
    create_parser.add_argument("--closing-date", help="Closing date (YYYY-MM-DD)")
    create_parser.add_argument("--type", help="Transaction type")
    create_parser.add_argument("--no-docs", action="store_true", help="Don't create standard documents")
    create_parser.add_argument("--no-conditions", action="store_true", help="Don't create standard conditions")
    
    # LIST command
    list_parser = subparsers.add_parser("list", help="List all transactions")
    
    # STATUS command
    status_parser = subparsers.add_parser("status", help="Show transaction status")
    status_parser.add_argument("transaction_id", help="Transaction ID (or prefix)")
    
    # CHECKLIST command
    checklist_parser = subparsers.add_parser("checklist", help="Generate closing checklist")
    checklist_parser.add_argument("transaction_id", help="Transaction ID (or prefix)")
    
    # DOCUMENTS command
    docs_parser = subparsers.add_parser("documents", help="List documents")
    docs_parser.add_argument("transaction_id", help="Transaction ID (or prefix)")
    
    # CONDITIONS command
    conds_parser = subparsers.add_parser("conditions", help="List conditions precedent")
    conds_parser.add_argument("transaction_id", help="Transaction ID (or prefix)")
    
    # ADD-PARTY command
    party_parser = subparsers.add_parser("add-party", help="Add a party to a transaction")
    party_parser.add_argument("transaction_id", help="Transaction ID (or prefix)")
    party_parser.add_argument("name", help="Party name")
    party_parser.add_argument("--role", action="append", required=True, help="Party role(s)")
    party_parser.add_argument("--short-name", help="Short name")
    party_parser.add_argument("--jurisdiction", help="Jurisdiction")
    party_parser.add_argument("--entity-type", help="Entity type")
    
    # UPDATE-DOC command
    update_doc_parser = subparsers.add_parser("update-doc", help="Update document status")
    update_doc_parser.add_argument("document_id", help="Document ID (or prefix)")
    update_doc_parser.add_argument("--status", required=True, help="New status")
    update_doc_parser.add_argument("--notes", help="Notes")
    
    # UPDATE-CONDITION command
    update_cond_parser = subparsers.add_parser("update-condition", help="Update condition status")
    update_cond_parser.add_argument("condition_id", help="Condition ID (or prefix)")
    update_cond_parser.add_argument("--status", required=True, help="New status")
    update_cond_parser.add_argument("--notes", help="Notes")
    
    # GENERATE command - document generation
    gen_parser = subparsers.add_parser("generate", help="Generate a document from template")
    gen_parser.add_argument("transaction_id", help="Transaction ID (or prefix)")
    gen_parser.add_argument("doc_type", choices=["officers", "secretary", "solvency", "checklist"],
                           help="Document type to generate")
    gen_parser.add_argument("--officer-name", default="[OFFICER NAME]", help="Officer name for certificates")
    gen_parser.add_argument("--officer-title", default="Chief Financial Officer", help="Officer title")
    gen_parser.add_argument("--secretary-name", default="[SECRETARY NAME]", help="Secretary name")
    
    # TERMS command - defined terms management
    terms_parser = subparsers.add_parser("terms", help="Manage defined terms")
    terms_subparsers = terms_parser.add_subparsers(dest="terms_command")
    
    # terms list
    terms_list = terms_subparsers.add_parser("list", help="List all defined terms")
    terms_list.add_argument("--category", help="Filter by category (party, financial, date, document, covenant, collateral, facility, general)")
    
    # terms load-sample
    terms_load = terms_subparsers.add_parser("load-sample", help="Load sample credit agreement definitions")
    
    # terms show
    terms_show = terms_subparsers.add_parser("show", help="Show details for a specific term")
    terms_show.add_argument("term", help="Term name (e.g., 'Administrative Agent')")
    
    # terms report
    terms_report = terms_subparsers.add_parser("report", help="Generate terms analysis report")
    
    # terms scan
    terms_scan = terms_subparsers.add_parser("scan", help="Scan a document for term usages")
    terms_scan.add_argument("filepath", help="Path to document text file")
    terms_scan.add_argument("--doc-id", default="manual-scan", help="Document ID for tracking")
    terms_scan.add_argument("--doc-type", default="unknown", help="Document type")
    
    # terms orphaned
    terms_orphaned = terms_subparsers.add_parser("orphaned", help="Find terms defined but never used")
    
    # terms graph
    terms_graph = terms_subparsers.add_parser("graph", help="Show term relationships")
    
    # FOLDER command - file watcher and smart checklist
    folder_parser = subparsers.add_parser("folder", help="Manage transaction folders and scan for files")
    folder_subparsers = folder_parser.add_subparsers(dest="folder_command")
    
    # folder create
    folder_create = folder_subparsers.add_parser("create", help="Create folder structure for a transaction")
    folder_create.add_argument("transaction_id", help="Transaction ID (or prefix)")
    
    # folder scan
    folder_scan = folder_subparsers.add_parser("scan", help="Scan folder and generate smart checklist")
    folder_scan.add_argument("transaction_id", help="Transaction ID (or prefix)")
    folder_scan.add_argument("--subfolder", help="Specific subfolder to scan")
    
    # folder sync
    folder_sync = folder_subparsers.add_parser("sync", help="Update document status based on files found")
    folder_sync.add_argument("transaction_id", help="Transaction ID (or prefix)")
    folder_sync.add_argument("--subfolder", help="Specific subfolder to scan")
    
    # folder suggest
    folder_suggest = folder_subparsers.add_parser("suggest", help="Show suggested folders for documents")
    folder_suggest.add_argument("transaction_id", help="Transaction ID (or prefix)")
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return
    
    # Use provided data-dir or auto-detect
    data_dir = args.data_dir if args.data_dir else get_default_data_dir()
    engine = TransactionEngine(data_dir)
    
    commands = {
        "create": cmd_create,
        "list": cmd_list,
        "status": cmd_status,
        "checklist": cmd_checklist,
        "documents": cmd_documents,
        "conditions": cmd_conditions,
        "add-party": cmd_add_party,
        "update-doc": cmd_update_doc,
        "update-condition": cmd_update_condition,
        "generate": cmd_generate,
        "terms": cmd_terms,
        "folder": cmd_folder,
    }
    
    if args.command in commands:
        commands[args.command](args, engine)
    else:
        parser.print_help()


def cmd_terms(args, engine: TransactionEngine):
    """Handle terms subcommands."""
    if not engine.terms_enabled:
        print("❌ Terms system not available")
        return
    
    if not args.terms_command:
        print("Usage: python run.py terms <subcommand>")
        print("\nSubcommands:")
        print("  list         List all defined terms")
        print("  load-sample  Load sample credit agreement definitions")
        print("  show <term>  Show details for a specific term")
        print("  report       Generate terms analysis report")
        print("  scan <file>  Scan a document for term usages")
        print("  orphaned     Find terms defined but never used")
        print("  graph        Show term relationships")
        return
    
    if args.terms_command == "list":
        terms = engine.list_defined_terms(category=getattr(args, 'category', None))
        
        if not terms:
            print("No defined terms found. Run 'terms load-sample' to load sample definitions.")
            return
        
        print(f"\n{'═' * 80}")
        print(f" DEFINED TERMS ({len(terms)} total)")
        print(f"{'═' * 80}\n")
        
        # Group by category
        by_category = {}
        for t in terms:
            cat = t['category']
            if cat not in by_category:
                by_category[cat] = []
            by_category[cat].append(t)
        
        for category, cat_terms in sorted(by_category.items()):
            print(f"[{category.upper()}]")
            for t in cat_terms:
                print(f"  • {t['term']}")
                print(f"    {t['definition'][:100]}...")
            print()
    
    elif args.terms_command == "load-sample":
        print("Loading sample credit agreement definitions...")
        terms = engine.load_sample_definitions()
        print(f"✓ Loaded {len(terms)} defined terms")
        
        # Show categories
        categories = {}
        for t in terms:
            cat = t.category.value
            categories[cat] = categories.get(cat, 0) + 1
        
        print("\nBy category:")
        for cat, count in sorted(categories.items()):
            print(f"  • {cat}: {count}")
    
    elif args.terms_command == "show":
        term_name = args.term
        detail = engine.get_term_detail(term_name)
        
        if not detail:
            print(f"Term '{term_name}' not found")
            return
        
        print(f"\n{'═' * 80}")
        print(f" {detail['term']}")
        print(f"{'═' * 80}\n")
        
        print(f"Category: {detail['category']}")
        print(f"Source: {detail['source']}")
        print(f"Section: {detail['section_reference']}")
        print(f"Usage count: {detail['usage_count']}")
        
        print(f"\nDefinition:")
        print(f"  {detail['definition']}")
        
        if detail['cross_references']:
            print(f"\nCross-references:")
            for ref in detail['cross_references']:
                print(f"  → {ref}")
        
        if detail['usages']:
            print(f"\nUsages (first 10):")
            for u in detail['usages']:
                print(f"  • {u['document_type']} {u['section']}")
                print(f"    {u['context']}")
    
    elif args.terms_command == "report":
        report = engine.get_terms_report()
        
        if "error" in report:
            print(f"❌ {report['error']}")
            return
        
        print(f"\n{'═' * 80}")
        print(f" DEFINED TERMS REPORT")
        print(f"{'═' * 80}\n")
        
        print(f"Total terms: {report['total_terms']}")
        print(f"Orphaned terms (defined but unused): {report['orphaned_count']}")
        
        print(f"\nBy category:")
        for cat, terms in report['by_category'].items():
            print(f"  • {cat}: {len(terms)}")
        
        if report['most_used']:
            print(f"\nMost used terms:")
            for term, count in report['most_used'][:5]:
                print(f"  • {term}: {count} usages")
        
        if report['issues']:
            print(f"\n⚠️  Issues found:")
            for issue in report['issues']:
                print(f"  • [{issue['severity']}] {issue['type']}: {issue['message']}")
    
    elif args.terms_command == "scan":
        filepath = Path(args.filepath)
        if not filepath.exists():
            print(f"File not found: {filepath}")
            return
        
        text = filepath.read_text()
        result = engine.scan_document_for_terms(text, args.doc_id, args.doc_type)
        
        print(f"\n{'═' * 80}")
        print(f" SCAN RESULTS: {filepath.name}")
        print(f"{'═' * 80}\n")
        
        print(f"Terms found: {result['terms_found']}")
        print(f"Total usages: {result['total_usages']}")
        
        if result['term_counts']:
            print(f"\nTop terms:")
            for term, count in list(result['term_counts'].items())[:10]:
                print(f"  • {term}: {count}")
        
        if result['potentially_undefined']:
            print(f"\n⚠️  Potentially undefined terms:")
            for term in result['potentially_undefined'][:10]:
                print(f"  ? {term}")
    
    elif args.terms_command == "orphaned":
        orphaned = engine.find_orphaned_terms()
        
        if not orphaned:
            print("✓ No orphaned terms found (all defined terms are used)")
        else:
            print(f"⚠️  Orphaned terms ({len(orphaned)} defined but never used):")
            for t in orphaned:
                print(f"  • {t['term']} [{t['category']}]")
    
    elif args.terms_command == "graph":
        graph = engine.get_term_graph()
        
        print(f"\n{'═' * 80}")
        print(f" TERM RELATIONSHIP GRAPH")
        print(f"{'═' * 80}\n")
        
        print(f"Nodes (terms): {graph['stats']['total_nodes']}")
        print(f"Edges (references): {graph['stats']['total_edges']}")
        
        if graph['edges']:
            print(f"\nCross-references:")
            for edge in graph['edges'][:20]:
                print(f"  {edge['source']} → {edge['target']}")
            
            if len(graph['edges']) > 20:
                print(f"  ... and {len(graph['edges']) - 20} more")


def cmd_folder(args, engine: TransactionEngine):
    """Handle folder subcommands."""
    if not engine.filewatcher_enabled:
        print("❌ File watcher system not available")
        return
    
    if not args.folder_command:
        print("Usage: python run.py folder <subcommand>")
        print("\nSubcommands:")
        print("  create <txn_id>   Create folder structure for a transaction")
        print("  scan <txn_id>     Scan folder and generate smart checklist")
        print("  sync <txn_id>     Update document status based on files found")
        print("  suggest <txn_id>  Show suggested folders for each document")
        return
    
    # Resolve transaction ID
    txn_id_prefix = getattr(args, 'transaction_id', None)
    if txn_id_prefix:
        txn = find_transaction(txn_id_prefix, engine)
        if not txn:
            return
        txn_id = txn.id
    else:
        print("Transaction ID required")
        return
    
    if args.folder_command == "create":
        result = engine.create_transaction_folder(txn_id)
        
        if "error" in result:
            print(f"❌ {result['error']}")
            return
        
        print(f"\n{'═' * 70}")
        print(f" FOLDER CREATED")
        print(f"{'═' * 70}\n")
        
        print(f"Path: {result['path']}")
        print(f"\nSubfolders:")
        for folder in result['subfolders']:
            print(f"  📁 {folder}")
        
        print(f"\n✓ Folder structure ready. Place documents in the appropriate subfolders.")
    
    elif args.folder_command == "scan":
        subfolder = getattr(args, 'subfolder', None) or ""
        result = engine.scan_transaction_folder(txn_id, subfolder)
        
        if "error" in result:
            print(f"❌ {result['error']}")
            print(f"   Folder: {result.get('scan_folder', 'unknown')}")
            print(f"\n   Run 'folder create {txn_id[:8]}' to create the folder structure.")
            return
        
        print(f"\n{'═' * 70}")
        print(f" SMART CHECKLIST: {result['transaction_name']}")
        print(f"{'═' * 70}")
        print(f"Scanned: {result['scan_folder']}")
        print(f"Time: {result['scan_time'][:19]}")
        print(f"\nReady: {result['ready_percentage']}% ({result['total_found']}/{result['total_expected']} documents)")
        print()
        
        # Group by status
        found = [i for i in result['items'] if i['file_found'] and i['file_status'] != 'draft']
        drafts = [i for i in result['items'] if i['file_status'] == 'draft']
        missing = [i for i in result['items'] if not i['file_found']]
        
        if found:
            print("✓ PRESENT")
            print("-" * 50)
            for item in found:
                filename = Path(item['file_path']).name if item['file_path'] else ""
                print(f"  ● {item['document_title']}")
                print(f"    → {filename} ({item['match_confidence']*100:.0f}% match)")
            print()
        
        if drafts:
            print("◐ DRAFTS")
            print("-" * 50)
            for item in drafts:
                filename = Path(item['file_path']).name if item['file_path'] else ""
                print(f"  ○ {item['document_title']}")
                print(f"    → {filename}")
            print()
        
        if missing:
            print("✗ MISSING")
            print("-" * 50)
            for item in missing:
                print(f"  □ {item['document_title']}")
            print()
        
        if result['unexpected_files']:
            print("? UNEXPECTED FILES")
            print("-" * 50)
            for f in result['unexpected_files'][:10]:
                print(f"  ? {f['filename']}")
            if len(result['unexpected_files']) > 10:
                print(f"  ... and {len(result['unexpected_files']) - 10} more")
            print()
    
    elif args.folder_command == "sync":
        subfolder = getattr(args, 'subfolder', None) or ""
        updated = engine.sync_from_folder(txn_id, subfolder)
        
        if not updated:
            print("✓ No documents needed status updates")
        else:
            print(f"\n{'═' * 70}")
            print(f" SYNCED {len(updated)} DOCUMENTS")
            print(f"{'═' * 70}\n")
            
            for doc in updated:
                print(f"  • {doc['title']}")
                print(f"    {doc['old_status']} → {doc['new_status']}")
    
    elif args.folder_command == "suggest":
        suggestions = engine.get_folder_suggestions(txn_id)
        
        if not suggestions:
            print("No documents found")
            return
        
        print(f"\n{'═' * 70}")
        print(f" SUGGESTED FOLDERS")
        print(f"{'═' * 70}\n")
        
        # Group by folder
        by_folder = {}
        for s in suggestions:
            folder = s['suggested_folder']
            if folder not in by_folder:
                by_folder[folder] = []
            by_folder[folder].append(s)
        
        for folder, docs in sorted(by_folder.items()):
            print(f"📁 {folder}/")
            for doc in docs:
                print(f"   • {doc['title']}")
            print()


if __name__ == "__main__":
    main()
