"""
Legal Transaction Engine - Data Store

Simple JSON-based persistence layer. 
This keeps things lightweight for experimentation while maintaining
the same interface we'd use with PostgreSQL later.

Design: Each entity type gets its own JSON file. All operations
go through this module, making it easy to swap in a real database later.
"""

import json
import os
from datetime import datetime, date
from pathlib import Path
from typing import Optional, TypeVar, Generic
from dataclasses import asdict, fields
import shutil

from models import (
    Transaction, Document, Party, ConditionPrecedent,
    DefinedTerm, CrossReference, SignaturePage, ChecklistItem,
    TransactionType, DocumentType, DocumentStatus, PartyRole, ConditionStatus
)

T = TypeVar('T')


class DateTimeEncoder(json.JSONEncoder):
    """Custom JSON encoder for datetime objects."""
    def default(self, obj):
        if isinstance(obj, datetime):
            return {"__datetime__": obj.isoformat()}
        if isinstance(obj, date):
            return {"__date__": obj.isoformat()}
        if hasattr(obj, 'value'):  # Enum
            return {"__enum__": f"{obj.__class__.__name__}.{obj.value}"}
        return super().default(obj)


def datetime_decoder(obj):
    """Custom JSON decoder for datetime objects."""
    if "__datetime__" in obj:
        return datetime.fromisoformat(obj["__datetime__"])
    if "__date__" in obj:
        return date.fromisoformat(obj["__date__"])
    if "__enum__" in obj:
        enum_str = obj["__enum__"]
        class_name, value = enum_str.split(".", 1)
        enum_classes = {
            "TransactionType": TransactionType,
            "DocumentType": DocumentType,
            "DocumentStatus": DocumentStatus,
            "PartyRole": PartyRole,
            "ConditionStatus": ConditionStatus,
        }
        if class_name in enum_classes:
            return enum_classes[class_name](value)
    return obj


class DataStore:
    """
    JSON-file-based data store.
    
    Stores each entity type in a separate JSON file.
    Provides CRUD operations with the same interface
    we'd use for a database.
    """
    
    def __init__(self, data_dir: str = "./data"):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        # Entity type to filename mapping
        self.entity_files = {
            "transactions": "transactions.json",
            "documents": "documents.json", 
            "parties": "parties.json",
            "conditions": "conditions.json",
            "defined_terms": "defined_terms.json",
            "cross_references": "cross_references.json",
            "signature_pages": "signature_pages.json",
            "checklist_items": "checklist_items.json",
        }
        
        # Initialize empty files if they don't exist
        for filename in self.entity_files.values():
            filepath = self.data_dir / filename
            if not filepath.exists():
                filepath.write_text("{}")
    
    def _load_file(self, entity_type: str) -> dict:
        """Load a JSON file for an entity type."""
        filepath = self.data_dir / self.entity_files[entity_type]
        with open(filepath, 'r') as f:
            return json.load(f, object_hook=datetime_decoder)
    
    def _save_file(self, entity_type: str, data: dict):
        """Save data to a JSON file."""
        filepath = self.data_dir / self.entity_files[entity_type]
        # Write to temp file first, then rename (atomic operation)
        temp_path = filepath.with_suffix('.tmp')
        with open(temp_path, 'w') as f:
            json.dump(data, f, cls=DateTimeEncoder, indent=2)
        shutil.move(str(temp_path), str(filepath))
    
    def _dataclass_to_dict(self, obj) -> dict:
        """Convert a dataclass to a dictionary."""
        return asdict(obj)
    
    def _dict_to_dataclass(self, data: dict, cls):
        """Convert a dictionary back to a dataclass."""
        # Handle nested enums that might have been decoded
        field_types = {f.name: f.type for f in fields(cls)}
        
        processed = {}
        for key, value in data.items():
            if key in field_types:
                processed[key] = value
        
        return cls(**processed)
    
    # =========================================================================
    # TRANSACTION OPERATIONS
    # =========================================================================
    
    def save_transaction(self, txn: Transaction) -> Transaction:
        """Save or update a transaction."""
        txn.updated_at = datetime.now()
        data = self._load_file("transactions")
        data[txn.id] = self._dataclass_to_dict(txn)
        self._save_file("transactions", data)
        return txn
    
    def get_transaction(self, txn_id: str) -> Optional[Transaction]:
        """Get a transaction by ID."""
        data = self._load_file("transactions")
        if txn_id in data:
            return self._dict_to_dataclass(data[txn_id], Transaction)
        return None
    
    def list_transactions(self) -> list[Transaction]:
        """List all transactions."""
        data = self._load_file("transactions")
        return [self._dict_to_dataclass(d, Transaction) for d in data.values()]
    
    def delete_transaction(self, txn_id: str) -> bool:
        """Delete a transaction."""
        data = self._load_file("transactions")
        if txn_id in data:
            del data[txn_id]
            self._save_file("transactions", data)
            return True
        return False
    
    # =========================================================================
    # DOCUMENT OPERATIONS
    # =========================================================================
    
    def save_document(self, doc: Document) -> Document:
        """Save or update a document."""
        doc.updated_at = datetime.now()
        data = self._load_file("documents")
        data[doc.id] = self._dataclass_to_dict(doc)
        self._save_file("documents", data)
        return doc
    
    def get_document(self, doc_id: str) -> Optional[Document]:
        """Get a document by ID."""
        data = self._load_file("documents")
        if doc_id in data:
            return self._dict_to_dataclass(data[doc_id], Document)
        return None
    
    def list_documents(self, transaction_id: Optional[str] = None) -> list[Document]:
        """List documents, optionally filtered by transaction."""
        data = self._load_file("documents")
        docs = [self._dict_to_dataclass(d, Document) for d in data.values()]
        
        if transaction_id:
            txn = self.get_transaction(transaction_id)
            if txn:
                docs = [d for d in docs if d.id in txn.document_ids]
        
        return docs
    
    def delete_document(self, doc_id: str) -> bool:
        """Delete a document."""
        data = self._load_file("documents")
        if doc_id in data:
            del data[doc_id]
            self._save_file("documents", data)
            return True
        return False
    
    # =========================================================================
    # PARTY OPERATIONS
    # =========================================================================
    
    def save_party(self, party: Party) -> Party:
        """Save or update a party."""
        party.updated_at = datetime.now()
        data = self._load_file("parties")
        data[party.id] = self._dataclass_to_dict(party)
        self._save_file("parties", data)
        return party
    
    def get_party(self, party_id: str) -> Optional[Party]:
        """Get a party by ID."""
        data = self._load_file("parties")
        if party_id in data:
            return self._dict_to_dataclass(data[party_id], Party)
        return None
    
    def list_parties(self, transaction_id: Optional[str] = None) -> list[Party]:
        """List parties, optionally filtered by transaction."""
        data = self._load_file("parties")
        parties = [self._dict_to_dataclass(d, Party) for d in data.values()]
        
        if transaction_id:
            txn = self.get_transaction(transaction_id)
            if txn:
                parties = [p for p in parties if p.id in txn.party_ids]
        
        return parties
    
    def delete_party(self, party_id: str) -> bool:
        """Delete a party."""
        data = self._load_file("parties")
        if party_id in data:
            del data[party_id]
            self._save_file("parties", data)
            return True
        return False
    
    # =========================================================================
    # CONDITION PRECEDENT OPERATIONS
    # =========================================================================
    
    def save_condition(self, cond: ConditionPrecedent) -> ConditionPrecedent:
        """Save or update a condition precedent."""
        cond.updated_at = datetime.now()
        data = self._load_file("conditions")
        data[cond.id] = self._dataclass_to_dict(cond)
        self._save_file("conditions", data)
        return cond
    
    def get_condition(self, cond_id: str) -> Optional[ConditionPrecedent]:
        """Get a condition by ID."""
        data = self._load_file("conditions")
        if cond_id in data:
            return self._dict_to_dataclass(data[cond_id], ConditionPrecedent)
        return None
    
    def list_conditions(self, transaction_id: Optional[str] = None) -> list[ConditionPrecedent]:
        """List conditions, optionally filtered by transaction."""
        data = self._load_file("conditions")
        conditions = [self._dict_to_dataclass(d, ConditionPrecedent) for d in data.values()]
        
        if transaction_id:
            txn = self.get_transaction(transaction_id)
            if txn:
                conditions = [c for c in conditions if c.id in txn.condition_ids]
        
        return conditions
    
    def delete_condition(self, cond_id: str) -> bool:
        """Delete a condition."""
        data = self._load_file("conditions")
        if cond_id in data:
            del data[cond_id]
            self._save_file("conditions", data)
            return True
        return False
    
    # =========================================================================
    # CHECKLIST ITEM OPERATIONS
    # =========================================================================
    
    def save_checklist_item(self, item: ChecklistItem) -> ChecklistItem:
        """Save or update a checklist item."""
        item.updated_at = datetime.now()
        data = self._load_file("checklist_items")
        data[item.id] = self._dataclass_to_dict(item)
        self._save_file("checklist_items", data)
        return item
    
    def get_checklist_item(self, item_id: str) -> Optional[ChecklistItem]:
        """Get a checklist item by ID."""
        data = self._load_file("checklist_items")
        if item_id in data:
            return self._dict_to_dataclass(data[item_id], ChecklistItem)
        return None
    
    def list_checklist_items(self) -> list[ChecklistItem]:
        """List all checklist items."""
        data = self._load_file("checklist_items")
        return [self._dict_to_dataclass(d, ChecklistItem) for d in data.values()]
    
    # =========================================================================
    # UTILITY OPERATIONS
    # =========================================================================
    
    def backup(self, backup_dir: str):
        """Create a backup of all data files."""
        backup_path = Path(backup_dir)
        backup_path.mkdir(parents=True, exist_ok=True)
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        for filename in self.entity_files.values():
            src = self.data_dir / filename
            if src.exists():
                dst = backup_path / f"{timestamp}_{filename}"
                shutil.copy(str(src), str(dst))
    
    def get_transaction_summary(self, txn_id: str) -> dict:
        """Get a summary of transaction status."""
        txn = self.get_transaction(txn_id)
        if not txn:
            return {}
        
        documents = self.list_documents(txn_id)
        conditions = self.list_conditions(txn_id)
        
        doc_stats = {}
        for doc in documents:
            status = doc.status.value if hasattr(doc.status, 'value') else str(doc.status)
            doc_stats[status] = doc_stats.get(status, 0) + 1
        
        cond_stats = {}
        for cond in conditions:
            status = cond.status.value if hasattr(cond.status, 'value') else str(cond.status)
            cond_stats[status] = cond_stats.get(status, 0) + 1
        
        return {
            "transaction_name": txn.name,
            "closing_date": txn.closing_date,
            "total_documents": len(documents),
            "document_status": doc_stats,
            "total_conditions": len(conditions),
            "condition_status": cond_stats,
            "is_closed": txn.is_closed,
        }
