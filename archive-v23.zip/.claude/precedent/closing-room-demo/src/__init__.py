"""
Legal Transaction Engine

A Gwern-inspired document management system for credit agreement closings.
"""

__version__ = "0.1.0"
