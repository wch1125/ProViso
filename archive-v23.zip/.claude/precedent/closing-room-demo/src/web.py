"""
Legal Transaction Engine - Web Interface

FastAPI-based web interface for managing credit agreement closings.
Uses HTMX for dynamic interactions without heavy JavaScript.
"""

import os
import sys
import random
from pathlib import Path
from datetime import date
from typing import Optional, List

from fastapi import FastAPI, Request, Form, HTTPException, UploadFile, File, APIRouter
from fastapi.responses import HTMLResponse, RedirectResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware
from starlette.middleware.base import BaseHTTPMiddleware

import zipfile
import time

# Add src to path
SCRIPT_DIR = Path(__file__).parent.resolve()
sys.path.insert(0, str(SCRIPT_DIR))

from engine import TransactionEngine
from models import (
    TransactionType, DocumentStatus,
    PartyRole, ConditionStatus
)
from docgen import DocumentGenerator

# =============================================================================
# DEMO MODE CONFIGURATION
# =============================================================================
# When DEMO_MODE=true, the following are disabled:
# - File uploads (prevents confidential/malicious file exposure)
# - New transaction creation
# - Transaction/document deletion
# Status updates are still allowed so users can interact with the demo.

DEMO_MODE = os.environ.get("DEMO_MODE", "true").lower() in ("true", "1", "yes")

def require_edit_access():
    """Guard function - raises HTTPException if in demo mode."""
    if DEMO_MODE:
        raise HTTPException(
            status_code=403,
            detail="This action is disabled in demo mode. Contact the administrator to enable editing."
        )

# Initialize FastAPI
app = FastAPI(
    title="Haslun.ai",
    description="AI-Powered Legal Infrastructure",
    version="0.3.0"
)

# Create router for demo with prefix
demo = APIRouter(prefix="/demo/credit-agreement")

# Determine paths
if SCRIPT_DIR.name == "src":
    PROJECT_ROOT = SCRIPT_DIR.parent
else:
    PROJECT_ROOT = SCRIPT_DIR

DATA_DIR = PROJECT_ROOT / "data"
OUTPUT_DIR = PROJECT_ROOT / "output"
TEMPLATES_DIR = SCRIPT_DIR / "templates"
STATIC_DIR = SCRIPT_DIR / "static"

# Create directories if needed
OUTPUT_DIR.mkdir(exist_ok=True)
TEMPLATES_DIR.mkdir(exist_ok=True)
STATIC_DIR.mkdir(exist_ok=True)

# Mount static files
app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")

# Setup templates
templates = Jinja2Templates(directory=str(TEMPLATES_DIR))

# Simple auth gate: require login for demo routes only
# Landing page and static files are public
EXEMPT_PATHS = {"/", "/login", "/demo/credit-agreement/login"}
EXEMPT_PREFIXES = ("/static", "/docs", "/openapi", "/redoc")


class AuthMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        path = request.url.path

        # Allow landing page, static files, docs, and login pages without auth
        if path in EXEMPT_PATHS or any(path.startswith(p) for p in EXEMPT_PREFIXES):
            response = await call_next(request)
            return response

        # Demo routes require auth
        if path.startswith("/demo/credit-agreement"):
            if not request.session.get("user"):
                return RedirectResponse(url="/demo/credit-agreement/login")

        # Allow everything if we've already logged in
        if request.session.get("user"):
            response = await call_next(request)
            return response

        # For non-demo protected routes, redirect to main login
        return RedirectResponse(url="/login")


# Add middlewares in order (AuthMiddleware wraps SessionMiddleware)
# Note: add_middleware adds in reverse order - last added is outermost
app.add_middleware(AuthMiddleware)
app.add_middleware(
    SessionMiddleware,
    secret_key=os.environ.get("APP_SECRET_KEY", "dev-secret-change-me"),
    session_cookie="haslun_session",
)

# Initialize engine
engine = TransactionEngine(str(DATA_DIR))
docgen = DocumentGenerator(str(DATA_DIR), str(OUTPUT_DIR))


# =============================================================================
# TEMPLATE FILTERS
# =============================================================================

def format_currency(amount: float) -> str:
    """Format a number as currency."""
    if amount >= 1_000_000_000:
        return f"${amount/1_000_000_000:.1f}B"
    elif amount >= 1_000_000:
        return f"${amount/1_000_000:.0f}M"
    elif amount >= 1_000:
        return f"${amount/1_000:.0f}K"
    else:
        return f"${amount:,.0f}"

def format_date(d) -> str:
    """Format a date for display."""
    if not d:
        return "TBD"
    if isinstance(d, str):
        return d
    return d.strftime("%b %d, %Y")

def status_icon(status: str) -> str:
    """Get status icon."""
    icons = {
        "not_started": "○",
        "drafting": "◐",
        "internal_review": "◑",
        "out_for_review": "◑",
        "comments_received": "◑",
        "final": "◉",
        "executed": "●",
        "filed": "●",
        "superseded": "×",
        "pending": "○",
        "in_progress": "◐",
        "satisfied": "●",
        "waived": "◇",
        "not_applicable": "─",
    }
    return icons.get(status, "?")

def status_color(status: str) -> str:
    """Get status color class."""
    colors = {
        "not_started": "gray",
        "drafting": "blue",
        "internal_review": "yellow",
        "out_for_review": "yellow",
        "comments_received": "orange",
        "final": "green",
        "executed": "green",
        "filed": "green",
        "superseded": "red",
        "pending": "gray",
        "in_progress": "blue",
        "satisfied": "green",
        "waived": "purple",
        "not_applicable": "gray",
    }
    return colors.get(status, "gray")

# Register filters
templates.env.filters["currency"] = format_currency
templates.env.filters["date"] = format_date
templates.env.filters["status_icon"] = status_icon
templates.env.filters["status_color"] = status_color

# Make DEMO_MODE available in all templates
templates.env.globals["DEMO_MODE"] = DEMO_MODE


# =============================================================================
# ROUTES - LANDING PAGE (PUBLIC)
# =============================================================================

@app.get("/", response_class=HTMLResponse)
async def landing_page(request: Request):
    """Public landing page for haslun.ai."""
    return templates.TemplateResponse("landing.html", {"request": request})


# =============================================================================
# ROUTES - AUTH (for demo)
# =============================================================================

@app.get("/demo/credit-agreement/login", response_class=HTMLResponse)
async def demo_login_page(request: Request):
    """Login page for credit agreement demo."""
    # If already logged in, go straight to demo dashboard
    if request.session.get("user"):
        return RedirectResponse(url="/demo/credit-agreement/", status_code=303)
    return templates.TemplateResponse(
        "login.html",
        {"request": request, "error": None},
    )


@app.post("/demo/credit-agreement/login", response_class=HTMLResponse)
async def demo_login_submit(
    request: Request,
    username: str = Form(...),
    password: str = Form(...),
):
    """Handle login form submission for demo."""
    expected_user = os.environ.get("DEMO_USERNAME", "admin")
    expected_pass = os.environ.get("DEMO_PASSWORD", "demo123")

    if username == expected_user and password == expected_pass:
        request.session["user"] = username
        # Redirect to the demo dashboard
        return RedirectResponse(url="/demo/credit-agreement/", status_code=303)

    # Failed login — re-render with an error
    return templates.TemplateResponse(
        "login.html",
        {"request": request, "error": "Invalid username or password."},
    )


@app.get("/demo/credit-agreement/logout")
async def demo_logout(request: Request):
    """Log out and clear session."""
    request.session.clear()
    return RedirectResponse(url="/", status_code=303)


# Legacy auth routes (redirect to new structure)
@app.get("/login", response_class=HTMLResponse)
async def login_redirect(request: Request):
    """Redirect old login URL to demo login."""
    return RedirectResponse(url="/demo/credit-agreement/login", status_code=303)


@app.get("/logout")
async def logout_redirect(request: Request):
    """Redirect old logout URL to demo logout."""
    return RedirectResponse(url="/demo/credit-agreement/logout", status_code=303)


# =============================================================================
# ROUTES - DEMO PAGES
# =============================================================================

@app.get("/demo/credit-agreement/", response_class=HTMLResponse)
@app.get("/demo/credit-agreement", response_class=HTMLResponse)
async def demo_home(request: Request):
    """Dashboard home page (Deal Room)."""
    transactions = engine.store.list_transactions()
    
    # Get first transaction for context
    txn = transactions[0] if transactions else None
    
    # Calculate summary stats
    total_docs = 0
    completed_docs = 0
    total_conditions = 0
    satisfied_conditions = 0
    
    for t in transactions:
        docs = engine.store.list_documents(t.id)
        conds = engine.store.list_conditions(t.id)
        
        total_docs += len(docs)
        completed_docs += sum(1 for d in docs if d.status in [DocumentStatus.FINAL, DocumentStatus.EXECUTED])
        
        total_conditions += len(conds)
        satisfied_conditions += sum(1 for c in conds if c.status in [ConditionStatus.SATISFIED, ConditionStatus.WAIVED])
    
    # Get terms count
    terms = engine.list_defined_terms()
    term_count = len(terms)
    
    # Get audit count
    audit_entries = engine.get_audit_trail(limit=1000)
    audit_count = len(audit_entries)
    
    return templates.TemplateResponse("index.html", {
        "request": request,
        "transaction": txn,
        "active_nav": "dashboard",
        "transactions": transactions,
        "term_count": term_count,
        "audit_count": audit_count,
        "stats": {
            "total_transactions": len(transactions),
            "total_docs": total_docs,
            "completed_docs": completed_docs,
            "total_conditions": total_conditions,
            "satisfied_conditions": satisfied_conditions,
        }
    })


@app.get("/demo/credit-agreement/transaction/{txn_id}", response_class=HTMLResponse)
async def transaction_detail(request: Request, txn_id: str):
    """Transaction detail page."""
    txn = engine.store.get_transaction(txn_id)
    if not txn:
        raise HTTPException(status_code=404, detail="Transaction not found")
    
    documents = engine.store.list_documents(txn_id)
    conditions = engine.store.list_conditions(txn_id)
    parties = engine.store.list_parties(txn_id)
    
    # Get borrower and agent
    borrower = None
    agent = None
    for p in parties:
        if PartyRole.BORROWER in p.roles:
            borrower = p
        if PartyRole.ADMINISTRATIVE_AGENT in p.roles:
            agent = p
    
    # Calculate readiness
    docs_ready = sum(1 for d in documents if d.status in [DocumentStatus.FINAL, DocumentStatus.EXECUTED])
    conds_ready = sum(1 for c in conditions if c.status in [ConditionStatus.SATISFIED, ConditionStatus.WAIVED, ConditionStatus.NOT_APPLICABLE])
    total = len(documents) + len(conditions)
    readiness = ((docs_ready + conds_ready) / total * 100) if total > 0 else 0
    
    return templates.TemplateResponse("transaction.html", {
        "request": request,
        "transaction": txn,
        "active_nav": "dashboard",
        "txn": txn,
        "documents": documents,
        "conditions": conditions,
        "parties": parties,
        "borrower": borrower,
        "agent": agent,
        "readiness": round(readiness, 1),
        "docs_ready": docs_ready,
        "conds_ready": conds_ready,
        "DocumentStatus": DocumentStatus,
        "ConditionStatus": ConditionStatus,
    })


@app.get("/demo/credit-agreement/transaction/{txn_id}/checklist", response_class=HTMLResponse)
async def transaction_checklist(request: Request, txn_id: str):
    """Closing checklist page."""
    txn = engine.store.get_transaction(txn_id)
    if not txn:
        raise HTTPException(status_code=404, detail="Transaction not found")
    
    checklist = engine.generate_checklist(txn_id)
    
    return templates.TemplateResponse("checklist.html", {
        "request": request,
        "txn": txn,
        "checklist": checklist,
    })


@app.get("/demo/credit-agreement/audit", response_class=HTMLResponse)
async def audit_trail(request: Request):
    """Global audit trail page."""
    audit_entries = engine.get_audit_trail(limit=100)
    git_history = engine.get_git_history(limit=20)
    integrity = engine.verify_audit_integrity()
    snapshots = engine.list_snapshots()
    
    # Get first transaction for nav context
    transactions = engine.store.list_transactions()
    txn = transactions[0] if transactions else None
    
    return templates.TemplateResponse("audit.html", {
        "request": request,
        "transaction": txn,
        "active_nav": "audit",
        "audit_entries": audit_entries,
        "git_history": git_history,
        "integrity": integrity,
        "snapshots": snapshots,
    })


@app.get("/demo/credit-agreement/transaction/{txn_id}/history", response_class=HTMLResponse)
async def transaction_history(request: Request, txn_id: str):
    """Transaction history page."""
    txn = engine.store.get_transaction(txn_id)
    if not txn:
        raise HTTPException(status_code=404, detail="Transaction not found")
    
    # Get all audit entries for this transaction
    txn_entries = engine.get_audit_trail(entity_type="transaction", entity_id=txn_id, limit=50)
    
    # Get document entries
    doc_entries = engine.get_audit_trail(entity_type="document", limit=200)
    
    # Get condition entries  
    cond_entries = engine.get_audit_trail(entity_type="condition", limit=200)
    
    return templates.TemplateResponse("history.html", {
        "request": request,
        "txn": txn,
        "txn_entries": txn_entries,
        "doc_entries": doc_entries,
        "cond_entries": cond_entries,
    })


@app.post("/demo/credit-agreement/api/transaction/{txn_id}/snapshot")
async def create_snapshot(txn_id: str):
    """Create a closing snapshot."""
    try:
        manifest = engine.create_closing_snapshot(txn_id)
        return RedirectResponse(url=f"/demo/credit-agreement/audit", status_code=303)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# =============================================================================
# ROUTES - DEFINED TERMS
# =============================================================================

@app.get("/demo/credit-agreement/terms", response_class=HTMLResponse)
async def defined_terms(request: Request, category: str = None):
    """Defined terms browser."""
    terms = engine.list_defined_terms(category=category)
    report = engine.get_terms_report() if engine.terms_enabled else {}
    graph = engine.get_term_graph() if engine.terms_enabled else {"nodes": [], "edges": []}
    
    # Get categories for filter
    categories = list(report.get("by_category", {}).keys())
    
    return templates.TemplateResponse("terms.html", {
        "request": request,
        "terms": terms,
        "report": report,
        "graph": graph,
        "categories": categories,
        "selected_category": category,
    })


@app.get("/demo/credit-agreement/terms/{term_name}", response_class=HTMLResponse)
async def term_detail(request: Request, term_name: str):
    """Term detail page."""
    detail = engine.get_term_detail(term_name)
    
    if not detail:
        raise HTTPException(status_code=404, detail="Term not found")
    
    return templates.TemplateResponse("term_detail.html", {
        "request": request,
        "term": detail,
    })


@app.post("/demo/credit-agreement/api/terms/load-sample")
async def load_sample_terms():
    """Load sample credit agreement definitions."""
    try:
        terms = engine.load_sample_definitions()
        return RedirectResponse(url="/demo/credit-agreement/terms", status_code=303)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# =============================================================================
# ROUTES - DOCUMENT LAB (Unified Document Exploration)
# =============================================================================

@app.get("/demo/credit-agreement/documents", response_class=HTMLResponse)
async def document_lab(request: Request):
    """Document Lab - Interactive document exploration with terms and graphs."""
    import json
    
    # Get the first transaction for context (in a real app, this would be selectable)
    transactions = engine.store.list_transactions()
    txn = transactions[0] if transactions else None
    
    # Get terms data
    terms = engine.list_defined_terms()
    terms_data = [
        {
            "id": t.get("id", ""),
            "term": t.get("term", ""),
            "category": t.get("category", "general"),
            "definition": t.get("definition", ""),
            "section_reference": t.get("section_reference", ""),
            "cross_references": t.get("cross_references", []),
        }
        for t in terms
    ]
    
    return templates.TemplateResponse("document-lab.html", {
        "request": request,
        "transaction": txn,
        "active_nav": "documents",
        "terms_json": json.dumps(terms_data),
    })


# Redirect old Terms page to Document Lab
@app.get("/demo/credit-agreement/terms", response_class=HTMLResponse)
async def defined_terms_redirect(request: Request):
    """Redirect old terms page to Document Lab."""
    return RedirectResponse(url="/demo/credit-agreement/documents", status_code=303)


# =============================================================================
# ROUTES - VISUALIZATIONS (Gwern-inspired)
# =============================================================================

@app.get("/demo/credit-agreement/visualizations", response_class=HTMLResponse)
async def visualizations_global(request: Request):
    """Redirect visualizations to Document Lab."""
    return RedirectResponse(url="/demo/credit-agreement/documents", status_code=303)


@app.get("/demo/credit-agreement/transaction/{txn_id}/visualizations", response_class=HTMLResponse)
async def visualizations_transaction(request: Request, txn_id: str):
    """Redirect transaction visualizations to Document Lab."""
    return RedirectResponse(url="/demo/credit-agreement/documents", status_code=303)


async def render_visualizations(request: Request, txn_id: Optional[str]):
    """Render the visualizations template with data."""
    # Get transaction if specified
    txn = engine.store.get_transaction(txn_id) if txn_id else None
    
    # Get terms data - list_defined_terms() returns dicts already
    terms = engine.list_defined_terms()
    terms_data = [
        {
            "term": t.get("term", ""),
            "category": t.get("category", "general"),
            "definition": t.get("definition", ""),
            "cross_references": t.get("cross_references", []),
        }
        for t in terms
    ]
    
    # Get documents data
    if txn_id:
        documents = engine.store.list_documents(txn_id)
    else:
        documents = engine.store.list_documents()
    
    docs_data = [
        {
            "id": str(d.id),
            "title": d.title,
            "name": d.title,
            "status": d.status.value if hasattr(d.status, 'value') else str(d.status),
        }
        for d in documents
    ]
    
    # Generate usage matrix (simulated - in production, scan documents for term usage)
    usage_matrix = []
    for term in terms_data:
        row = []
        for doc in docs_data:
            # Simulate usage based on category matching
            if term["category"] == "document":
                usage = random.randint(3, 15)
            elif term["category"] == "party":
                usage = random.randint(2, 12)
            else:
                usage = random.randint(0, 6)
            row.append(usage)
        usage_matrix.append(row)
    
    # Get properly typed edges from the engine
    # This uses the atomized term edges system
    graph_data = engine.get_term_graph()
    edges = graph_data.get("edges", [])
    
    # If no typed edges exist yet, rebuild them
    if not edges and terms_data:
        rebuild_result = engine.rebuild_term_edges()
        if rebuild_result.get("edges_created", 0) > 0:
            graph_data = engine.get_term_graph()
            edges = graph_data.get("edges", [])
    
    # Format edges for D3 visualization
    formatted_edges = [
        {
            "source": e.get("source", ""),
            "target": e.get("target", ""),
            "type": e.get("type", "references"),
            "weight": int(e.get("confidence", 0.8) * 5),  # Convert confidence to weight 1-5
        }
        for e in edges
    ]
    
    # Get checklist data
    if txn_id:
        checklist = engine.generate_checklist(txn_id)
    else:
        checklist = []
    
    # Build categories and items from checklist
    categories = []
    checklist_items = []
    seen_cats = set()
    
    for section in checklist:
        cat_id = f"cat_{section.get('section', 'misc')}"
        if cat_id not in seen_cats:
            categories.append({
                "id": cat_id,
                "section": section.get("section", ""),
                "title": section.get("title", "Miscellaneous"),
            })
            seen_cats.add(cat_id)
        
        for item in section.get("items", []):
            checklist_items.append({
                "id": item.get("id", str(len(checklist_items))),
                "category_id": cat_id,
                "title": item.get("title", ""),
                "status": item.get("status", "pending"),
                "description": item.get("description", ""),
            })
    
    # Expected items (documents that should exist but don't)
    expected_items = [
        {"category_id": "cat_2", "title": "Certificate of Incorporation"},
        {"category_id": "cat_2", "title": "Bylaws"},
        {"category_id": "cat_3", "title": "Perfection Certificate"},
        {"category_id": "cat_4", "title": "Agent's Counsel Opinion"},
        {"category_id": "cat_5", "title": "Insurance Certificates"},
    ]
    
    # Category colors for legend
    term_categories = [
        {"name": "party", "color": "#3b82f6"},
        {"name": "financial", "color": "#10b981"},
        {"name": "date", "color": "#f59e0b"},
        {"name": "document", "color": "#8b5cf6"},
        {"name": "collateral", "color": "#ec4899"},
        {"name": "covenant", "color": "#ef4444"},
        {"name": "facility", "color": "#06b6d4"},
        {"name": "general", "color": "#6b7280"},
    ]
    
    # Get graph stats if available
    graph_stats = engine.get_term_graph_stats() if hasattr(engine, 'get_term_graph_stats') else {}
    
    # Get conditions data for the Condition Flow visualization
    if txn_id:
        raw_conditions = engine.store.list_conditions(txn_id)
    else:
        raw_conditions = engine.store.list_conditions()
    
    conditions_data = [
        {
            "id": str(c.id),
            "title": c.title,
            "section_reference": c.section_reference,
            "status": c.status.value if hasattr(c.status, 'value') else str(c.status).split('.')[-1],
            "category": c.category,
            "description": c.description,
        }
        for c in raw_conditions
    ]
    
    # Generate logical condition dependencies based on common legal patterns
    condition_dependencies = []
    sorted_conditions = sorted(conditions_data, key=lambda x: x.get("section_reference", ""))
    
    # Build dependency graph based on category relationships
    category_order = [
        "Corporate Documents",
        "Core Agreement", 
        "Credit Agreement",
        "Security Documents",
        "UCC Filings",
        "Legal Opinions",
        "Certificates",
        "Financial",
        "Fees",
        "Insurance",
        "KYC/AML",
        "General Conditions",
    ]
    
    # Create dependencies based on logical prerequisites
    for i, cond in enumerate(sorted_conditions):
        cat = cond.get("category", "")
        
        # Find prerequisite conditions
        for j, other in enumerate(sorted_conditions):
            if i == j:
                continue
            other_cat = other.get("category", "")
            
            # Security docs require Credit Agreement
            if cat == "Security Documents" and other_cat in ["Credit Agreement", "Core Agreement"]:
                condition_dependencies.append({
                    "source": other["id"],
                    "target": cond["id"],
                    "type": "requires"
                })
            # UCC requires Security Docs
            elif cat == "UCC Filings" and other_cat == "Security Documents":
                condition_dependencies.append({
                    "source": other["id"],
                    "target": cond["id"],
                    "type": "requires"
                })
            # Legal opinions can be concurrent with certificates
            elif cat == "Legal Opinions" and other_cat == "Certificates":
                condition_dependencies.append({
                    "source": other["id"],
                    "target": cond["id"],
                    "type": "concurrent"
                })
            # Certificates require Corporate Documents
            elif cat == "Certificates" and other_cat == "Corporate Documents":
                condition_dependencies.append({
                    "source": other["id"],
                    "target": cond["id"],
                    "type": "requires"
                })
    
    return templates.TemplateResponse("visualizations.html", {
        "request": request,
        "txn": txn,
        "terms": terms_data,
        "documents": docs_data,
        "usage_matrix": usage_matrix,
        "edges": formatted_edges,
        "categories": categories,
        "checklist_items": checklist_items,
        "expected_items": expected_items,
        "term_categories": term_categories,
        "graph_stats": graph_stats,
        "conditions": conditions_data,
        "condition_dependencies": condition_dependencies,
    })


# =============================================================================
# ROUTES - FILE WATCHER & SMART CHECKLIST
# =============================================================================

@app.get("/demo/credit-agreement/transaction/{txn_id}/files", response_class=HTMLResponse)
async def transaction_files(request: Request, txn_id: str):
    """Smart checklist showing files vs expected documents."""
    txn = engine.store.get_transaction(txn_id)
    if not txn:
        raise HTTPException(status_code=404, detail="Transaction not found")
    
    # Scan folder
    scan_result = engine.scan_transaction_folder(txn_id)
    suggestions = engine.get_folder_suggestions(txn_id)
    
    return templates.TemplateResponse("files.html", {
        "request": request,
        "txn": txn,
        "scan": scan_result,
        "suggestions": suggestions,
        "folder_enabled": engine.filewatcher_enabled,
    })


@app.post("/demo/credit-agreement/api/transaction/{txn_id}/create-folder")
async def create_transaction_folder(txn_id: str):
    """Create folder structure for a transaction."""
    try:
        result = engine.create_transaction_folder(txn_id)
        return RedirectResponse(url=f"/demo/credit-agreement/transaction/{txn_id}/files", status_code=303)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/demo/credit-agreement/api/transaction/{txn_id}/sync-folder")
async def sync_from_folder(txn_id: str):
    """Sync document statuses from folder files."""
    try:
        updated = engine.sync_from_folder(txn_id)
        return RedirectResponse(url=f"/demo/credit-agreement/transaction/{txn_id}/files", status_code=303)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/demo/credit-agreement/api/transaction/{txn_id}/upload-zip")
async def upload_zip(txn_id: str, upload: UploadFile = File(...)):
    """
    Upload a ZIP file of deal documents and extract it into
    the transaction's documents folder, then rescan.
    """
    require_edit_access()  # Block in demo mode
    
    if not engine.filewatcher_enabled:
        raise HTTPException(status_code=400, detail="File watcher system is not available")

    if not upload.filename.lower().endswith(".zip"):
        raise HTTPException(status_code=400, detail="Please upload a .zip file")

    # Ensure the transaction folder exists and get its path
    folder_info = engine.create_transaction_folder(txn_id)
    if isinstance(folder_info, dict) and folder_info.get("error"):
        raise HTTPException(status_code=500, detail=folder_info["error"])

    txn_folder = Path(folder_info["path"])
    txn_folder.mkdir(parents=True, exist_ok=True)

    # Save ZIP temporarily
    temp_zip_path = txn_folder / f"upload_{int(time.time())}.zip"
    content = await upload.read()
    with temp_zip_path.open("wb") as f:
        f.write(content)

    # Extract ZIP contents into the transaction folder
    try:
        with zipfile.ZipFile(temp_zip_path, "r") as z:
            z.extractall(txn_folder)
    finally:
        # Clean up temp file
        try:
            temp_zip_path.unlink()
        except FileNotFoundError:
            pass

    # After upload/extract, just redirect back to Smart Checklist
    return RedirectResponse(url=f"/demo/credit-agreement/transaction/{txn_id}/files", status_code=303)


@app.post("/demo/credit-agreement/api/transaction/{txn_id}/upload-files")
async def upload_files(
    txn_id: str,
    subfolder: Optional[str] = Form(default=""),
    files: List[UploadFile] = File(...),
):
    """
    Upload one or more individual files into the transaction's
    documents folder (optionally into a subfolder).
    """
    require_edit_access()  # Block in demo mode
    
    if not engine.filewatcher_enabled:
        raise HTTPException(status_code=400, detail="File watcher system is not available")

    # Ensure the transaction folder exists and get its path
    folder_info = engine.create_transaction_folder(txn_id)
    if isinstance(folder_info, dict) and folder_info.get("error"):
        raise HTTPException(status_code=500, detail=folder_info["error"])

    txn_folder = Path(folder_info["path"])

    # Optional subfolder under the transaction folder
    target_folder = txn_folder
    if subfolder:
        # Basic sanitization: no path traversal, just a simple name
        safe_subfolder = subfolder.replace("..", "").strip().strip("/\\")
        if safe_subfolder:
            target_folder = txn_folder / safe_subfolder

    target_folder.mkdir(parents=True, exist_ok=True)

    # Save each file
    for file_upload in files:
        if not file_upload.filename:
            continue

        filename = Path(file_upload.filename).name  # strip any path components
        dest_path = target_folder / filename

        content = await file_upload.read()
        with dest_path.open("wb") as f:
            f.write(content)

    return RedirectResponse(url=f"/demo/credit-agreement/transaction/{txn_id}/files", status_code=303)


# =============================================================================
# ROUTES - HTMX PARTIALS
# =============================================================================

@app.post("/demo/credit-agreement/htmx/document/{doc_id}/status", response_class=HTMLResponse)
async def update_document_status(request: Request, doc_id: str, status: str = Form(...)):
    """Update document status (HTMX partial)."""
    try:
        new_status = DocumentStatus(status)
        doc = engine.update_document_status(doc_id, new_status)
        
        return templates.TemplateResponse("partials/document_row.html", {
            "request": request,
            "doc": doc,
            "DocumentStatus": DocumentStatus,
        })
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/demo/credit-agreement/htmx/condition/{cond_id}/status", response_class=HTMLResponse)
async def update_condition_status(request: Request, cond_id: str, status: str = Form(...)):
    """Update condition status (HTMX partial)."""
    try:
        new_status = ConditionStatus(status)
        cond = engine.update_condition_status(cond_id, new_status)
        
        return templates.TemplateResponse("partials/condition_row.html", {
            "request": request,
            "cond": cond,
            "ConditionStatus": ConditionStatus,
        })
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.get("/demo/credit-agreement/htmx/transaction/{txn_id}/stats", response_class=HTMLResponse)
async def transaction_stats(request: Request, txn_id: str):
    """Get transaction stats (HTMX partial)."""
    summary = engine.get_status_summary(txn_id)
    
    return templates.TemplateResponse("partials/stats.html", {
        "request": request,
        "summary": summary,
    })


# =============================================================================
# ROUTES - DOCUMENT GENERATION
# =============================================================================

@app.post("/demo/credit-agreement/generate/{txn_id}/{doc_type}")
async def generate_document(
    txn_id: str,
    doc_type: str,
    officer_name: str = Form("[OFFICER NAME]"),
    officer_title: str = Form("Chief Financial Officer"),
    secretary_name: str = Form("[SECRETARY NAME]"),
):
    """Generate a document and return download link."""
    try:
        if doc_type == "officers":
            path = docgen.generate_officers_certificate(txn_id, officer_name, officer_title)
        elif doc_type == "secretary":
            path = docgen.generate_secretary_certificate(txn_id, secretary_name)
        elif doc_type == "solvency":
            path = docgen.generate_solvency_certificate(txn_id, officer_name, officer_title)
        elif doc_type == "checklist":
            path = docgen.generate_closing_checklist(txn_id)
        else:
            raise HTTPException(status_code=400, detail=f"Unknown document type: {doc_type}")
        
        # Return the file
        return FileResponse(
            path=str(path),
            filename=path.name,
            media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/demo/credit-agreement/download/{filename}")
async def download_file(filename: str):
    """Download a generated file."""
    file_path = OUTPUT_DIR / filename
    if not file_path.exists():
        raise HTTPException(status_code=404, detail="File not found")
    
    return FileResponse(
        path=str(file_path),
        filename=filename,
        media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    )


# =============================================================================
# ROUTES - API
# =============================================================================

@app.post("/demo/credit-agreement/api/transaction")
async def create_transaction(
    name: str = Form(...),
    amount: float = Form(0),
    closing_date: str = Form(None),
    transaction_type: str = Form("revolving_credit"),
):
    """Create a new transaction."""
    require_edit_access()  # Block in demo mode
    
    try:
        txn_type = TransactionType(transaction_type)
        close_date = date.fromisoformat(closing_date) if closing_date else None
        
        txn = engine.create_transaction(
            name=name,
            transaction_type=txn_type,
            facility_amount=amount,
            closing_date=close_date,
        )
        
        return RedirectResponse(url=f"/demo/credit-agreement/transaction/{txn.id}", status_code=303)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/demo/credit-agreement/api/transaction/{txn_id}/party")
async def add_party(
    txn_id: str,
    name: str = Form(...),
    short_name: str = Form(""),
    roles: str = Form(...),
    jurisdiction: str = Form(""),
    entity_type: str = Form(""),
):
    """Add a party to a transaction."""
    require_edit_access()  # Block in demo mode
    
    try:
        role_list = [PartyRole(r.strip()) for r in roles.split(",")]
        
        party = engine.add_party(
            txn_id=txn_id,
            name=name,
            roles=role_list,
            short_name=short_name,
            jurisdiction=jurisdiction,
            entity_type=entity_type,
        )
        
        return RedirectResponse(url=f"/demo/credit-agreement/transaction/{txn_id}", status_code=303)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


# =============================================================================
# MAIN
# =============================================================================

def main():
    """Run the web server."""
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)


if __name__ == "__main__":
    main()
