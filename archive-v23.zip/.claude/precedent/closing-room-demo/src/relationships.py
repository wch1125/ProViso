"""
Relationship index for the Legal Transaction Engine.

This is a thin, append-only layer that records explicit edges between
entities (documents, conditions, etc.) in a simple JSONL file.

Design goals:
- Plain-text, git-friendly, append-only log (like the audit log)
- Light-weight querying utilities for later analysis
- No coupling to the persistence of core entities (DataStore)
"""

from __future__ import annotations

from dataclasses import dataclass, asdict, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Iterable, Iterator, List, Optional, Dict, Any
import json
import uuid


class RelationshipType(str, Enum):
    EXPECTED_DOC_FOR_CONDITION = "expected_doc_for_condition"
    # Later we can add:
    # SATISFIES_CONDITION = "satisfies_condition"
    # BELONGS_TO_TRANSACTION = "belongs_to_transaction"
    # etc.


@dataclass
class Relationship:
    id: str
    from_type: str
    from_id: str
    relation: RelationshipType
    to_type: str
    to_id: str
    transaction_id: Optional[str] = None
    created_at: datetime = field(default_factory=datetime.utcnow)

    @classmethod
    def create(
        cls,
        from_type: str,
        from_id: str,
        relation: RelationshipType,
        to_type: str,
        to_id: str,
        transaction_id: Optional[str] = None,
    ) -> "Relationship":
        return cls(
            id=str(uuid.uuid4()),
            from_type=from_type,
            from_id=from_id,
            relation=relation,
            to_type=to_type,
            to_id=to_id,
            transaction_id=transaction_id,
        )


class RelationshipStore:
    """
    Simple JSONL-backed store for relationships.

    File format: one JSON object per line. Example:

        {
          "id": "...",
          "from_type": "document",
          "from_id": "...",
          "relation": "expected_doc_for_condition",
          "to_type": "condition",
          "to_id": "...",
          "transaction_id": "...",
          "created_at": "2025-12-10T07:30:00.123456"
        }
    """

    def __init__(self, data_dir: str = "./data"):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.log_file = self.data_dir / "relationships.jsonl"
        if not self.log_file.exists():
            self.log_file.write_text("")

    # --- low-level IO helpers -------------------------------------------------

    def _serialize(self, rel: Relationship) -> dict:
        data = asdict(rel)
        # Convert datetime to ISO string
        data["created_at"] = rel.created_at.isoformat()
        # Enum to value
        data["relation"] = rel.relation.value
        return data

    def _deserialize(self, data: dict) -> Relationship:
        return Relationship(
            id=data["id"],
            from_type=data["from_type"],
            from_id=data["from_id"],
            relation=RelationshipType(data["relation"]),
            to_type=data["to_type"],
            to_id=data["to_id"],
            transaction_id=data.get("transaction_id"),
            created_at=datetime.fromisoformat(data["created_at"]),
        )

    # --- public API -----------------------------------------------------------

    def add(self, rel: Relationship) -> None:
        """Append a single relationship."""
        with self.log_file.open("a", encoding="utf-8") as f:
            json.dump(self._serialize(rel), f, sort_keys=True)
            f.write("\n")

    def add_many(self, rels: Iterable[Relationship]) -> None:
        """Append multiple relationships in one go."""
        with self.log_file.open("a", encoding="utf-8") as f:
            for rel in rels:
                json.dump(self._serialize(rel), f, sort_keys=True)
                f.write("\n")

    def iter_all(self) -> Iterator[Relationship]:
        """Iterate over all relationships."""
        if not self.log_file.exists():
            return iter(())
        with self.log_file.open("r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    data = json.loads(line)
                    yield self._deserialize(data)
                except Exception:
                    # Skip malformed lines rather than exploding
                    continue

    def query(
        self,
        *,
        transaction_id: Optional[str] = None,
        from_type: Optional[str] = None,
        to_type: Optional[str] = None,
        relation: Optional[RelationshipType] = None,
    ) -> List[Relationship]:
        """Filter relationships by simple attributes."""
        results: List[Relationship] = []
        for rel in self.iter_all():
            if transaction_id is not None and rel.transaction_id != transaction_id:
                continue
            if from_type is not None and rel.from_type != from_type:
                continue
            if to_type is not None and rel.to_type != to_type:
                continue
            if relation is not None and rel.relation != relation:
                continue
            results.append(rel)
        return results
