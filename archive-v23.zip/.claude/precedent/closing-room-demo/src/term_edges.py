"""
Legal Transaction Engine - Term Relationship Edges

This module provides atomized, typed edges between defined terms.
Instead of storing cross-references as unvalidated string lists,
we create explicit, validated relationships that can be queried
and visualized in the network graph.

Design goals:
- Each edge is a first-class entity with semantic type
- Edges only connect valid, known terms (no orphan references)
- Support multiple relationship types common in legal documents
- Git-friendly JSONL storage (like the audit log)
- Enable graph queries: "What terms does X depend on?" "What uses X?"

Edge Types:
- REFERENCES: Term A mentions Term B in its definition
- DEFINES_AS: Term A is defined as a subset/type of Term B  
- INCLUDES: Term A's definition includes/encompasses Term B
- INCORPORATES: Term A incorporates Term B by reference
- SUPERSEDES: Term A replaces/supersedes Term B (amendments)
- PART_OF: Term A is part of a group defined by Term B
"""

from __future__ import annotations

from dataclasses import dataclass, field, asdict
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional, Set, Iterator, Tuple
import json
import uuid
import re


class TermEdgeType(str, Enum):
    """Types of relationships between defined terms."""
    
    # Term A's definition mentions/uses Term B
    REFERENCES = "references"
    
    # Term A is explicitly defined as a type/subset of Term B
    # e.g., "Revolving Loan means a Loan made pursuant to..."
    DEFINES_AS = "defines_as"
    
    # Term A includes Term B in its enumeration
    # e.g., "Loan Documents means the Credit Agreement, the Security Agreement..."
    INCLUDES = "includes"
    
    # Term A incorporates Term B by reference
    # e.g., "as defined in Section X of the Credit Agreement"
    INCORPORATES = "incorporates"
    
    # Term A supersedes/replaces Term B (for amendments)
    SUPERSEDES = "supersedes"
    
    # Term A is part of a group/collection Term B
    # e.g., "Administrative Agent" is a type of "Person"
    PART_OF = "part_of"
    
    # Bidirectional reference (both terms reference each other)
    MUTUAL = "mutual"


@dataclass
class TermEdge:
    """
    A single directed edge between two defined terms.
    
    Attributes:
        id: Unique identifier
        source_term: The term containing the reference
        target_term: The term being referenced
        edge_type: The semantic type of relationship
        context: The text context where the reference occurs
        confidence: 0.0-1.0 confidence score for auto-detected edges
        validated: Whether a human has validated this edge
        created_at: When the edge was created
    """
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    source_term: str = ""
    target_term: str = ""
    edge_type: TermEdgeType = TermEdgeType.REFERENCES
    context: str = ""  # Snippet showing the reference in context
    confidence: float = 1.0
    validated: bool = False
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    
    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "id": self.id,
            "source_term": self.source_term,
            "target_term": self.target_term,
            "edge_type": self.edge_type.value,
            "context": self.context,
            "confidence": self.confidence,
            "validated": self.validated,
            "created_at": self.created_at,
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> "TermEdge":
        """Create from dictionary."""
        return cls(
            id=data.get("id", str(uuid.uuid4())),
            source_term=data.get("source_term", ""),
            target_term=data.get("target_term", ""),
            edge_type=TermEdgeType(data.get("edge_type", "references")),
            context=data.get("context", ""),
            confidence=data.get("confidence", 1.0),
            validated=data.get("validated", False),
            created_at=data.get("created_at", datetime.now().isoformat()),
        )


class TermEdgeStore:
    """
    Persistent storage for term relationship edges.
    
    Uses JSONL format for git-friendly, append-optimized storage.
    Each line is a complete JSON object representing one edge.
    """
    
    def __init__(self, data_dir: str):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.edges_file = self.data_dir / "term_edges.jsonl"
        
        if not self.edges_file.exists():
            self.edges_file.write_text("")
    
    def add(self, edge: TermEdge) -> None:
        """Append a single edge."""
        with self.edges_file.open("a", encoding="utf-8") as f:
            json.dump(edge.to_dict(), f, sort_keys=True)
            f.write("\n")
    
    def add_many(self, edges: List[TermEdge]) -> None:
        """Append multiple edges."""
        with self.edges_file.open("a", encoding="utf-8") as f:
            for edge in edges:
                json.dump(edge.to_dict(), f, sort_keys=True)
                f.write("\n")
    
    def iter_all(self) -> Iterator[TermEdge]:
        """Iterate over all edges."""
        if not self.edges_file.exists():
            return
        
        with self.edges_file.open("r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    data = json.loads(line)
                    yield TermEdge.from_dict(data)
                except Exception:
                    continue
    
    def get_all(self) -> List[TermEdge]:
        """Get all edges as a list."""
        return list(self.iter_all())
    
    def get_outgoing(self, term: str) -> List[TermEdge]:
        """Get all edges where the given term is the source."""
        return [e for e in self.iter_all() if e.source_term == term]
    
    def get_incoming(self, term: str) -> List[TermEdge]:
        """Get all edges where the given term is the target."""
        return [e for e in self.iter_all() if e.target_term == term]
    
    def get_between(self, source: str, target: str) -> List[TermEdge]:
        """Get edges between two specific terms."""
        return [
            e for e in self.iter_all()
            if e.source_term == source and e.target_term == target
        ]
    
    def get_by_type(self, edge_type: TermEdgeType) -> List[TermEdge]:
        """Get all edges of a specific type."""
        return [e for e in self.iter_all() if e.edge_type == edge_type]
    
    def clear(self) -> None:
        """Clear all edges (for reprocessing)."""
        self.edges_file.write_text("")
    
    def count(self) -> int:
        """Count total edges."""
        return sum(1 for _ in self.iter_all())


class TermEdgeExtractor:
    """
    Extracts typed edges from defined term definitions.
    
    Uses pattern matching to identify different relationship types
    and only creates edges to known, valid terms.
    """
    
    # Patterns for different edge types - more comprehensive
    PATTERNS = {
        # "X means..." patterns that define as a type/subset
        TermEdgeType.DEFINES_AS: [
            r'means\s+a\s+([A-Z][a-zA-Z]+(?:\s+[A-Z][a-zA-Z]+)*)\s+(?:made|issued|given|provided|executed)',
            r'means\s+(?:any|each)\s+([A-Z][a-zA-Z]+(?:\s+[A-Z][a-zA-Z]+)*)',
        ],
        # Enumeration patterns: "means X, Y, and Z" - these INCLUDE the listed items
        TermEdgeType.INCLUDES: [
            r'means\s+(?:this\s+)?([A-Z][a-zA-Z]+(?:\s+[A-Z][a-zA-Z]+)*),\s+(?:the\s+)?([A-Z][a-zA-Z]+(?:\s+[A-Z][a-zA-Z]+)*)',
            r'includes?\s+(?:the\s+)?([A-Z][a-zA-Z]+(?:\s+[A-Z][a-zA-Z]+)*)',
            r'consisting\s+of\s+(?:the\s+)?([A-Z][a-zA-Z]+(?:\s+[A-Z][a-zA-Z]+)*)',
        ],
        # Incorporation patterns - reference to definition elsewhere
        TermEdgeType.INCORPORATES: [
            r'as\s+(?:defined|set\s+forth)\s+in\s+(?:the\s+)?([A-Z][a-zA-Z]+(?:\s+[A-Z][a-zA-Z]+)*)',
            r'has\s+the\s+meaning\s+(?:given|assigned|set\s+forth)\s+(?:to\s+such\s+term\s+)?in\s+(?:the\s+)?([A-Z][a-zA-Z]+(?:\s+[A-Z][a-zA-Z]+)*)',
            r'(?:given|assigned)\s+(?:to\s+)?(?:such|that)\s+term\s+in\s+(?:Section\s+[\d.]+\s+of\s+)?(?:the\s+)?([A-Z][a-zA-Z]+(?:\s+[A-Z][a-zA-Z]+)*)',
        ],
        # Part-of relationship - term is governed by something larger  
        TermEdgeType.PART_OF: [
            r'under\s+(?:any\s+of\s+)?(?:the\s+)?([A-Z][a-zA-Z]+(?:\s+[A-Z][a-zA-Z]+)*)',
            r'pursuant\s+to\s+(?:the\s+)?([A-Z][a-zA-Z]+(?:\s+[A-Z][a-zA-Z]+)*)',
            r'arising\s+under\s+(?:the\s+)?([A-Z][a-zA-Z]+(?:\s+[A-Z][a-zA-Z]+)*)',
        ],
    }
    
    # Common words that look like terms but aren't
    EXCLUDE_WORDS = {
        "The", "This", "That", "These", "Those", "Such", "Any", "All", "Each",
        "If", "When", "Where", "While", "Unless", "Until", "After", "Before",
        "Article", "Section", "Exhibit", "Schedule", "Annex", "Appendix",
        "January", "February", "March", "April", "May", "June", "July",
        "August", "September", "October", "November", "December",
        "United States", "New York", "Delaware", "California", "Texas",
        "State", "States", "County", "City", "Corporation", "Company",
        "Agreement", "Document", "Certificate", "Notice", "Payment",
    }
    
    # Pattern for finding capitalized phrases (potential term references)
    TERM_PATTERN = r'\b([A-Z][a-zA-Z]*(?:\s+[A-Z][a-zA-Z]*){0,4})\b'
    
    def __init__(self, known_terms: Set[str]):
        """
        Initialize with a set of known valid terms.
        
        Args:
            known_terms: Set of defined term names that are valid targets
        """
        self.known_terms = known_terms
        self._term_lookup = {t.lower(): t for t in known_terms}
    
    def _normalize_term(self, text: str) -> Optional[str]:
        """
        Try to match text to a known term.
        
        Returns the canonical term name if found, None otherwise.
        """
        text = text.strip()
        
        # Direct match
        if text in self.known_terms:
            return text
        
        # Case-insensitive match
        lower = text.lower()
        if lower in self._term_lookup:
            return self._term_lookup[lower]
        
        # Try without trailing 's' (plurals)
        if lower.endswith('s') and lower[:-1] in self._term_lookup:
            return self._term_lookup[lower[:-1]]
        
        return None
    
    def extract_edges(
        self,
        source_term: str,
        definition: str,
    ) -> List[TermEdge]:
        """
        Extract all edges from a term's definition.
        
        Args:
            source_term: The term being defined
            definition: The definition text
        
        Returns:
            List of TermEdge objects
        """
        edges = []
        seen_targets = set()
        
        # First, try typed pattern extraction
        for edge_type, patterns in self.PATTERNS.items():
            for pattern in patterns:
                matches = re.finditer(pattern, definition, re.IGNORECASE)
                for match in matches:
                    for group in match.groups():
                        if group:
                            target = self._normalize_term(group)
                            if target and target != source_term and target not in seen_targets:
                                context = self._extract_context(definition, match.start(), match.end())
                                edges.append(TermEdge(
                                    source_term=source_term,
                                    target_term=target,
                                    edge_type=edge_type,
                                    context=context,
                                    confidence=0.9,
                                ))
                                seen_targets.add(target)
        
        # Then, find all capitalized phrases that match known terms
        # These become generic REFERENCES edges
        for match in re.finditer(self.TERM_PATTERN, definition):
            candidate = match.group(1)
            
            # Skip excluded words
            if candidate in self.EXCLUDE_WORDS:
                continue
            
            target = self._normalize_term(candidate)
            if target and target != source_term and target not in seen_targets:
                context = self._extract_context(definition, match.start(), match.end())
                edges.append(TermEdge(
                    source_term=source_term,
                    target_term=target,
                    edge_type=TermEdgeType.REFERENCES,
                    context=context,
                    confidence=0.8,
                ))
                seen_targets.add(target)
        
        return edges
    
    def _extract_context(self, text: str, start: int, end: int, window: int = 40) -> str:
        """Extract surrounding context for an edge."""
        ctx_start = max(0, start - window)
        ctx_end = min(len(text), end + window)
        
        context = text[ctx_start:ctx_end]
        
        # Add ellipsis if truncated
        if ctx_start > 0:
            context = "..." + context
        if ctx_end < len(text):
            context = context + "..."
        
        return context.strip()


class TermGraphAnalyzer:
    """
    Analyzes the term relationship graph for insights.
    
    Provides methods for:
    - Finding central/important terms
    - Detecting circular references
    - Finding isolated terms
    - Computing dependency chains
    """
    
    def __init__(self, edge_store: TermEdgeStore):
        self.edge_store = edge_store
    
    def get_graph_stats(self) -> dict:
        """Get statistics about the term graph."""
        edges = self.edge_store.get_all()
        
        # Count unique terms
        all_terms = set()
        for e in edges:
            all_terms.add(e.source_term)
            all_terms.add(e.target_term)
        
        # Count edges by type
        by_type = {}
        for e in edges:
            by_type[e.edge_type.value] = by_type.get(e.edge_type.value, 0) + 1
        
        # Find most connected terms (highest degree)
        degree = {}
        for e in edges:
            degree[e.source_term] = degree.get(e.source_term, 0) + 1
            degree[e.target_term] = degree.get(e.target_term, 0) + 1
        
        most_connected = sorted(degree.items(), key=lambda x: x[1], reverse=True)[:10]
        
        # Find terms with most outgoing (most dependencies)
        outgoing = {}
        for e in edges:
            outgoing[e.source_term] = outgoing.get(e.source_term, 0) + 1
        
        most_dependencies = sorted(outgoing.items(), key=lambda x: x[1], reverse=True)[:10]
        
        # Find terms with most incoming (most referenced)
        incoming = {}
        for e in edges:
            incoming[e.target_term] = incoming.get(e.target_term, 0) + 1
        
        most_referenced = sorted(incoming.items(), key=lambda x: x[1], reverse=True)[:10]
        
        return {
            "total_terms": len(all_terms),
            "total_edges": len(edges),
            "edges_by_type": by_type,
            "most_connected": most_connected,
            "most_dependencies": most_dependencies,
            "most_referenced": most_referenced,
        }
    
    def find_circular_references(self) -> List[List[str]]:
        """Find circular reference chains."""
        edges = self.edge_store.get_all()
        
        # Build adjacency list
        graph: Dict[str, Set[str]] = {}
        for e in edges:
            if e.source_term not in graph:
                graph[e.source_term] = set()
            graph[e.source_term].add(e.target_term)
        
        # Find cycles using DFS
        cycles = []
        visited = set()
        rec_stack = set()
        path = []
        
        def dfs(node: str) -> bool:
            visited.add(node)
            rec_stack.add(node)
            path.append(node)
            
            for neighbor in graph.get(node, []):
                if neighbor not in visited:
                    if dfs(neighbor):
                        return True
                elif neighbor in rec_stack:
                    # Found cycle
                    cycle_start = path.index(neighbor)
                    cycles.append(path[cycle_start:] + [neighbor])
            
            path.pop()
            rec_stack.remove(node)
            return False
        
        for node in graph:
            if node not in visited:
                dfs(node)
        
        return cycles
    
    def get_dependency_chain(self, term: str, max_depth: int = 5) -> dict:
        """
        Get the dependency chain for a term.
        
        Returns a tree structure of what the term depends on.
        """
        edges = self.edge_store.get_all()
        
        # Build adjacency list
        outgoing: Dict[str, List[TermEdge]] = {}
        for e in edges:
            if e.source_term not in outgoing:
                outgoing[e.source_term] = []
            outgoing[e.source_term].append(e)
        
        def build_tree(node: str, depth: int, visited: Set[str]) -> dict:
            if depth >= max_depth or node in visited:
                return {"term": node, "truncated": True}
            
            visited.add(node)
            
            children = []
            for edge in outgoing.get(node, []):
                child_tree = build_tree(edge.target_term, depth + 1, visited.copy())
                child_tree["edge_type"] = edge.edge_type.value
                children.append(child_tree)
            
            return {
                "term": node,
                "dependencies": children,
            }
        
        return build_tree(term, 0, set())
    
    def get_visualization_data(self) -> dict:
        """
        Get data formatted for D3.js visualization.
        
        Returns nodes and links in D3 force-directed graph format.
        """
        edges = self.edge_store.get_all()
        
        # Collect unique terms
        terms = set()
        for e in edges:
            terms.add(e.source_term)
            terms.add(e.target_term)
        
        # Create nodes
        nodes = [{"id": t, "name": t} for t in terms]
        
        # Create links with edge type info
        links = [
            {
                "source": e.source_term,
                "target": e.target_term,
                "type": e.edge_type.value,
                "confidence": e.confidence,
            }
            for e in edges
        ]
        
        return {
            "nodes": nodes,
            "links": links,
        }


def rebuild_edges_from_terms(terms_data: List[dict], data_dir: str) -> int:
    """
    Rebuild the edge store from a list of term dictionaries.
    
    This is the main entry point for converting the old cross_references
    lists into proper typed edges.
    
    Args:
        terms_data: List of term dicts with 'term' and 'definition' keys
        data_dir: Directory for the edge store
    
    Returns:
        Number of edges created
    """
    # Get set of known term names
    known_terms = {t["term"] for t in terms_data}
    
    # Initialize extractor and store
    extractor = TermEdgeExtractor(known_terms)
    store = TermEdgeStore(data_dir)
    
    # Clear existing edges
    store.clear()
    
    # Extract edges from each term
    all_edges = []
    for term_data in terms_data:
        source = term_data.get("term", "")
        definition = term_data.get("definition", "")
        
        if source and definition:
            edges = extractor.extract_edges(source, definition)
            all_edges.extend(edges)
    
    # Store all edges
    store.add_many(all_edges)
    
    return len(all_edges)
