"""
Legal Transaction Engine - Defined Terms System

This module handles the extraction, tracking, and validation of defined terms
across a credit agreement closing set.

Key concepts:
- Defined terms are capitalized phrases with specific meanings (e.g., "Administrative Agent")
- They're typically defined in Article I of the Credit Agreement
- They must be used consistently across ALL closing documents
- Cross-references between documents must remain valid

Gwern-inspired features:
- Parse and index all defined terms from source documents
- Track usage across the entire document set
- Validate consistency and flag discrepancies
- Detect orphaned terms (defined but never used)
- Detect undefined terms (used but never defined)
"""

import re
import json
from pathlib import Path
from datetime import datetime
from dataclasses import dataclass, field, asdict
from typing import Optional
from enum import Enum


class TermSource(Enum):
    """Where a term is defined."""
    CREDIT_AGREEMENT = "credit_agreement"
    SECURITY_AGREEMENT = "security_agreement"
    GUARANTY = "guaranty"
    INTERCREDITOR = "intercreditor"
    AMENDMENT = "amendment"
    OTHER = "other"


class TermCategory(Enum):
    """Category of defined term."""
    PARTY = "party"  # Borrower, Administrative Agent, Lenders
    FINANCIAL = "financial"  # EBITDA, Consolidated Net Income
    DATE = "date"  # Closing Date, Maturity Date
    DOCUMENT = "document"  # Credit Agreement, Security Documents
    COVENANT = "covenant"  # Permitted Liens, Permitted Indebtedness
    COLLATERAL = "collateral"  # Collateral, Pledged Stock
    FACILITY = "facility"  # Commitment, Revolving Loans
    GENERAL = "general"  # Everything else


@dataclass
class DefinedTerm:
    """
    A defined term from the credit agreement.
    
    Attributes:
        term: The capitalized term (e.g., "Administrative Agent")
        definition: The full definition text
        source: Which document defines it
        section_reference: Where it's defined (e.g., "Section 1.01")
        category: Type of term for organization
        cross_references: Other terms referenced in this definition
        usage_locations: Where this term is used across documents
    """
    id: str = field(default_factory=lambda: str(__import__('uuid').uuid4()))
    term: str = ""
    definition: str = ""
    source: TermSource = TermSource.CREDIT_AGREEMENT
    section_reference: str = "Section 1.01"
    category: TermCategory = TermCategory.GENERAL
    cross_references: list[str] = field(default_factory=list)  # Other terms this references
    usage_locations: list[dict] = field(default_factory=list)  # [{document, section, context}]
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now().isoformat())
    notes: str = ""
    
    # For amendments/modifications
    supersedes_id: Optional[str] = None  # If this term replaces another
    superseded_by_id: Optional[str] = None  # If this term was replaced


@dataclass
class TermUsage:
    """A single usage of a defined term in a document."""
    term_id: str
    term: str
    document_id: str
    document_type: str
    section: str = ""
    context: str = ""  # Surrounding text for context
    line_number: int = 0
    is_definition: bool = False  # Is this where the term is defined?


@dataclass
class CrossReference:
    """
    A cross-reference between documents or sections.
    
    Examples:
    - "as defined in Section 1.01 of the Credit Agreement"
    - "pursuant to Section 7.01(a)"
    - "as set forth in the Security Agreement"
    """
    id: str = field(default_factory=lambda: str(__import__('uuid').uuid4()))
    source_document_id: str = ""
    source_section: str = ""
    target_document_type: str = ""  # What document it references
    target_section: str = ""  # What section it references
    reference_text: str = ""  # The actual text of the reference
    is_valid: bool = True  # Whether the reference is still valid
    validation_date: str = ""
    notes: str = ""


class DefinedTermsParser:
    """
    Parses defined terms from credit agreement text.
    
    Handles common patterns:
    - "Term" means ...
    - "Term" shall mean ...
    - "Term" has the meaning set forth in ...
    - "Term": ...
    """
    
    # Patterns for finding defined terms
    DEFINITION_PATTERNS = [
        # "Term" means ...
        r'"([A-Z][^"]+)"\s+(?:shall\s+)?means?\s+(.+?)(?=\n\s*"[A-Z]|\n\s*ARTICLE|\n\s*Section|\Z)',
        # "Term": definition
        r'"([A-Z][^"]+)":\s+(.+?)(?=\n\s*"[A-Z]|\n\s*ARTICLE|\n\s*Section|\Z)',
        # "Term" has the meaning...
        r'"([A-Z][^"]+)"\s+has\s+the\s+meaning\s+(?:set\s+forth|assigned|given)\s+(.+?)(?=\n\s*"[A-Z]|\Z)',
    ]
    
    # Pattern for finding capitalized terms in text
    TERM_USAGE_PATTERN = r'\b([A-Z][a-zA-Z]*(?:\s+[A-Z][a-zA-Z]*)*)\b'
    
    # Common words that look like defined terms but aren't
    EXCLUDE_TERMS = {
        "The", "This", "That", "These", "Those", "Such", "Any", "All", "Each",
        "If", "When", "Where", "While", "Unless", "Until", "After", "Before",
        "Article", "Section", "Exhibit", "Schedule", "Annex", "Appendix",
        "January", "February", "March", "April", "May", "June", "July",
        "August", "September", "October", "November", "December",
        "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday",
        "United States", "New York", "Delaware", "California", "Texas",
        "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X",
        "A", "B", "C", "D", "E", "F", "G", "H",
        "WHEREAS", "NOW", "THEREFORE", "PROVIDED", "INCLUDING", "WITHOUT",
        "IN", "WITNESS", "WHEREOF", "HEREBY",
    }
    
    # Terms that indicate references to other documents
    DOCUMENT_REFERENCE_PATTERNS = [
        r'(?:as\s+)?(?:defined|set\s+forth|provided)\s+in\s+(?:the\s+)?([A-Z][a-zA-Z\s]+)',
        r'pursuant\s+to\s+(?:the\s+)?([A-Z][a-zA-Z\s]+)',
        r'under\s+(?:the\s+)?([A-Z][a-zA-Z\s]+)',
    ]
    
    def __init__(self):
        self.terms: dict[str, DefinedTerm] = {}
        self.usages: list[TermUsage] = []
    
    def parse_definitions(self, text: str, source: TermSource = TermSource.CREDIT_AGREEMENT) -> list[DefinedTerm]:
        """
        Extract defined terms from document text.
        
        Args:
            text: The document text (typically Article I)
            source: Which document this is from
        
        Returns:
            List of DefinedTerm objects
        """
        terms = []
        
        for pattern in self.DEFINITION_PATTERNS:
            matches = re.findall(pattern, text, re.DOTALL | re.MULTILINE)
            
            for match in matches:
                term_name = match[0].strip()
                definition = match[1].strip()
                
                # Clean up definition
                definition = re.sub(r'\s+', ' ', definition)
                definition = definition[:2000]  # Limit length
                
                # Skip if too short or looks invalid
                if len(term_name) < 2 or len(definition) < 10:
                    continue
                
                # Categorize the term
                category = self._categorize_term(term_name, definition)
                
                # Find cross-references within the definition
                cross_refs = self._find_cross_references(definition)
                
                term = DefinedTerm(
                    term=term_name,
                    definition=definition,
                    source=source,
                    category=category,
                    cross_references=cross_refs,
                )
                
                terms.append(term)
                self.terms[term_name] = term
        
        return terms
    
    def _categorize_term(self, term: str, definition: str) -> TermCategory:
        """Attempt to categorize a defined term."""
        term_lower = term.lower()
        def_lower = definition.lower()
        
        # Party terms
        party_keywords = ['agent', 'lender', 'borrower', 'guarantor', 'issuer', 'arranger']
        if any(kw in term_lower for kw in party_keywords):
            return TermCategory.PARTY
        
        # Financial terms
        financial_keywords = ['ebitda', 'income', 'revenue', 'debt', 'ratio', 'leverage', 'coverage']
        if any(kw in term_lower for kw in financial_keywords):
            return TermCategory.FINANCIAL
        
        # Date terms
        if 'date' in term_lower:
            return TermCategory.DATE
        
        # Document terms
        document_keywords = ['agreement', 'document', 'certificate', 'opinion', 'notice']
        if any(kw in term_lower for kw in document_keywords):
            return TermCategory.DOCUMENT
        
        # Covenant terms
        covenant_keywords = ['permitted', 'restricted', 'prohibited', 'required']
        if any(kw in term_lower for kw in covenant_keywords):
            return TermCategory.COVENANT
        
        # Collateral terms
        collateral_keywords = ['collateral', 'pledged', 'security', 'lien', 'mortgage']
        if any(kw in term_lower for kw in collateral_keywords):
            return TermCategory.COLLATERAL
        
        # Facility terms
        facility_keywords = ['commitment', 'loan', 'facility', 'advance', 'credit']
        if any(kw in term_lower for kw in facility_keywords):
            return TermCategory.FACILITY
        
        return TermCategory.GENERAL
    
    def _find_cross_references(self, definition: str) -> list[str]:
        """Find references to other defined terms within a definition."""
        cross_refs = []
        
        # Look for capitalized phrases that might be defined terms
        matches = re.findall(self.TERM_USAGE_PATTERN, definition)
        
        for match in matches:
            if match not in self.EXCLUDE_TERMS and len(match) > 2:
                cross_refs.append(match)
        
        return list(set(cross_refs))
    
    def find_term_usages(
        self,
        text: str,
        document_id: str,
        document_type: str,
        known_terms: list[str] = None
    ) -> list[TermUsage]:
        """
        Find all usages of defined terms in a document.
        
        Args:
            text: Document text to search
            document_id: ID of the document
            document_type: Type of document
            known_terms: List of known defined terms to look for
        
        Returns:
            List of TermUsage objects
        """
        usages = []
        terms_to_find = known_terms or list(self.terms.keys())
        
        # Split into lines for line number tracking
        lines = text.split('\n')
        
        for line_num, line in enumerate(lines, 1):
            for term in terms_to_find:
                # Look for the term (case-sensitive for defined terms)
                pattern = r'\b' + re.escape(term) + r'\b'
                matches = list(re.finditer(pattern, line))
                
                for match in matches:
                    # Get surrounding context
                    start = max(0, match.start() - 50)
                    end = min(len(line), match.end() + 50)
                    context = line[start:end]
                    
                    # Determine current section (simplified)
                    section = self._find_current_section(lines, line_num)
                    
                    usage = TermUsage(
                        term_id=self.terms.get(term, DefinedTerm()).id,
                        term=term,
                        document_id=document_id,
                        document_type=document_type,
                        section=section,
                        context=f"...{context}...",
                        line_number=line_num,
                        is_definition='"' + term + '"' in line and ('means' in line.lower() or 'shall mean' in line.lower()),
                    )
                    usages.append(usage)
        
        self.usages.extend(usages)
        return usages
    
    def _find_current_section(self, lines: list[str], current_line: int) -> str:
        """Find what section we're currently in."""
        section_pattern = r'Section\s+(\d+\.\d+(?:\([a-z]\))?)'
        
        # Look backwards for section header
        for i in range(current_line - 1, max(0, current_line - 50), -1):
            match = re.search(section_pattern, lines[i])
            if match:
                return f"Section {match.group(1)}"
        
        return ""
    
    def find_section_references(self, text: str, document_id: str) -> list[CrossReference]:
        """
        Find all cross-references to sections in other documents.
        
        Args:
            text: Document text to search
            document_id: ID of the source document
        
        Returns:
            List of CrossReference objects
        """
        references = []
        
        # Pattern for section references
        patterns = [
            r'Section\s+(\d+\.\d+(?:\([a-z]\))?)\s+of\s+(?:the\s+)?([A-Z][a-zA-Z\s]+(?:Agreement|Document))',
            r'pursuant\s+to\s+Section\s+(\d+\.\d+(?:\([a-z]\))?)',
            r'as\s+(?:defined|set\s+forth)\s+in\s+Section\s+(\d+\.\d+(?:\([a-z]\))?)',
        ]
        
        for pattern in patterns:
            matches = re.finditer(pattern, text)
            for match in matches:
                ref = CrossReference(
                    source_document_id=document_id,
                    target_section=f"Section {match.group(1)}",
                    reference_text=match.group(0),
                )
                
                # Try to identify target document
                if len(match.groups()) > 1:
                    ref.target_document_type = match.group(2).strip()
                
                references.append(ref)
        
        return references


class DefinedTermsStore:
    """
    Persistent storage for defined terms and their usages.
    """
    
    def __init__(self, data_dir: str):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        self.terms_file = self.data_dir / "defined_terms.json"
        self.usages_file = self.data_dir / "term_usages.json"
        self.refs_file = self.data_dir / "cross_references.json"
    
    def _load_json(self, filepath: Path) -> list:
        if filepath.exists():
            return json.loads(filepath.read_text())
        return []
    
    def _save_json(self, filepath: Path, data: list):
        filepath.write_text(json.dumps(data, indent=2, default=str))
    
    def save_term(self, term: DefinedTerm):
        terms = self._load_json(self.terms_file)
        
        # Update or add
        found = False
        for i, t in enumerate(terms):
            if t.get("id") == term.id or t.get("term") == term.term:
                terms[i] = asdict(term)
                found = True
                break
        
        if not found:
            terms.append(asdict(term))
        
        self._save_json(self.terms_file, terms)
    
    def save_terms(self, terms: list[DefinedTerm]):
        # Convert enums to their values for JSON serialization
        data = []
        for t in terms:
            d = asdict(t)
            # Ensure enums are stored as values, not "Enum.VALUE" strings
            if hasattr(t.source, 'value'):
                d['source'] = t.source.value
            if hasattr(t.category, 'value'):
                d['category'] = t.category.value
            data.append(d)
        self._save_json(self.terms_file, data)
    
    def get_term(self, term_name: str) -> Optional[DefinedTerm]:
        terms = self._load_json(self.terms_file)
        for t in terms:
            if t.get("term") == term_name:
                # Handle enum conversion
                source_val = t.get("source", "credit_agreement")
                if isinstance(source_val, str) and "." in source_val:
                    source_val = source_val.split(".")[-1].lower()
                t["source"] = TermSource(source_val)
                
                cat_val = t.get("category", "general")
                if isinstance(cat_val, str) and "." in cat_val:
                    cat_val = cat_val.split(".")[-1].lower()
                t["category"] = TermCategory(cat_val)
                
                return DefinedTerm(**t)
        return None
    
    def list_terms(self, category: TermCategory = None) -> list[DefinedTerm]:
        terms = self._load_json(self.terms_file)
        result = []
        for t in terms:
            # Handle enum conversion - extract value if it's "Enum.VALUE" format
            source_val = t.get("source", "credit_agreement")
            if isinstance(source_val, str) and "." in source_val:
                source_val = source_val.split(".")[-1].lower()
            
            cat_val = t.get("category", "general")
            if isinstance(cat_val, str) and "." in cat_val:
                cat_val = cat_val.split(".")[-1].lower()
            
            if category and cat_val != category.value:
                continue
            
            t["source"] = TermSource(source_val)
            t["category"] = TermCategory(cat_val)
            result.append(DefinedTerm(**t))
        return result
    
    def save_usages(self, usages: list[TermUsage]):
        data = [asdict(u) for u in usages]
        existing = self._load_json(self.usages_file)
        existing.extend(data)
        self._save_json(self.usages_file, existing)
    
    def get_term_usages(self, term: str) -> list[TermUsage]:
        usages = self._load_json(self.usages_file)
        return [TermUsage(**u) for u in usages if u.get("term") == term]
    
    def save_references(self, refs: list[CrossReference]):
        data = [asdict(r) for r in refs]
        self._save_json(self.refs_file, data)
    
    def list_references(self) -> list[CrossReference]:
        refs = self._load_json(self.refs_file)
        return [CrossReference(**r) for r in refs]


class DefinedTermsAnalyzer:
    """
    Analyzes defined terms for consistency and completeness.
    """
    
    def __init__(self, store: DefinedTermsStore):
        self.store = store
    
    def find_orphaned_terms(self) -> list[DefinedTerm]:
        """Find terms that are defined but never used."""
        terms = self.store.list_terms()
        orphaned = []
        
        for term in terms:
            usages = self.store.get_term_usages(term.term)
            # Filter out the definition itself
            non_definition_usages = [u for u in usages if not u.is_definition]
            if len(non_definition_usages) == 0:
                orphaned.append(term)
        
        return orphaned
    
    def find_undefined_terms(self, document_text: str) -> list[str]:
        """Find capitalized terms that might need definitions."""
        parser = DefinedTermsParser()
        known_terms = {t.term for t in self.store.list_terms()}
        
        # Find all capitalized phrases
        pattern = r'\b([A-Z][a-zA-Z]*(?:\s+[A-Z][a-zA-Z]*){0,3})\b'
        candidates = set(re.findall(pattern, document_text))
        
        # Filter out known terms and common exclusions
        undefined = []
        for candidate in candidates:
            if candidate not in known_terms and candidate not in parser.EXCLUDE_TERMS:
                # Check if it looks like a defined term (used multiple times)
                count = len(re.findall(r'\b' + re.escape(candidate) + r'\b', document_text))
                if count >= 2:  # Used at least twice
                    undefined.append(candidate)
        
        return sorted(undefined)
    
    def check_consistency(self) -> list[dict]:
        """
        Check for inconsistencies in term usage.
        
        Returns issues like:
        - Same term defined differently in different documents
        - Terms used before they're defined
        - Circular references
        """
        issues = []
        terms = self.store.list_terms()
        
        # Check for duplicate definitions
        term_names = {}
        for term in terms:
            if term.term in term_names:
                issues.append({
                    "type": "duplicate_definition",
                    "term": term.term,
                    "message": f"'{term.term}' is defined in both {term_names[term.term]} and {term.source.value}",
                    "severity": "warning",
                })
            else:
                term_names[term.term] = term.source.value
        
        # Check for circular references
        for term in terms:
            visited = set()
            if self._has_circular_reference(term.term, term.cross_references, terms, visited):
                issues.append({
                    "type": "circular_reference",
                    "term": term.term,
                    "message": f"'{term.term}' has a circular reference in its definition chain",
                    "severity": "warning",
                })
        
        return issues
    
    def _has_circular_reference(
        self,
        original_term: str,
        refs: list[str],
        all_terms: list[DefinedTerm],
        visited: set
    ) -> bool:
        """Check if following cross-references leads back to original term."""
        for ref in refs:
            if ref == original_term:
                return True
            if ref in visited:
                continue
            
            visited.add(ref)
            
            # Find the referenced term's cross-references
            for term in all_terms:
                if term.term == ref:
                    if self._has_circular_reference(original_term, term.cross_references, all_terms, visited):
                        return True
        
        return False
    
    def generate_term_report(self) -> dict:
        """Generate a comprehensive report on defined terms."""
        terms = self.store.list_terms()
        
        # Group by category
        by_category = {}
        for term in terms:
            cat = term.category.value
            if cat not in by_category:
                by_category[cat] = []
            by_category[cat].append(term.term)
        
        # Count usages
        usage_counts = {}
        for term in terms:
            usages = self.store.get_term_usages(term.term)
            usage_counts[term.term] = len([u for u in usages if not u.is_definition])
        
        # Find most/least used
        sorted_by_usage = sorted(usage_counts.items(), key=lambda x: x[1], reverse=True)
        
        return {
            "total_terms": len(terms),
            "by_category": by_category,
            "most_used": sorted_by_usage[:10],
            "least_used": sorted_by_usage[-10:] if len(sorted_by_usage) >= 10 else sorted_by_usage,
            "orphaned_count": len(self.find_orphaned_terms()),
            "issues": self.check_consistency(),
        }


# =============================================================================
# SAMPLE CREDIT AGREEMENT DEFINITIONS
# =============================================================================

SAMPLE_DEFINITIONS = '''
"Administrative Agent" means Big Bank, N.A., in its capacity as administrative agent under any of the Loan Documents, or any successor administrative agent.

"Affiliate" means, with respect to any Person, another Person that directly, or indirectly through one or more intermediaries, Controls or is Controlled by or is under common Control with the Person specified.

"Borrower" means ABC Corporation, a Delaware corporation.

"Business Day" means any day that is not a Saturday, Sunday or other day on which commercial banks in New York City are authorized or required by law to remain closed.

"Closing Date" means March 15, 2025.

"Collateral" means all assets and property of any Loan Party, whether real, personal or mixed, tangible or intangible, now owned or hereafter acquired, in which a Lien is purported to be granted pursuant to any Security Document.

"Commitment" means, with respect to each Lender, the commitment of such Lender to make Revolving Loans and to acquire participations in Letters of Credit hereunder, as set forth on Schedule 2.01.

"Control" means the possession, directly or indirectly, of the power to direct or cause the direction of the management or policies of a Person, whether through the ability to exercise voting power, by contract or otherwise.

"Credit Agreement" means this Credit Agreement, dated as of the Closing Date, among the Borrower, the Lenders and the Administrative Agent.

"Default" means any event or condition that constitutes an Event of Default or that, with the giving of any notice, the passage of time, or both, would be an Event of Default.

"EBITDA" means, for any period, Consolidated Net Income for such period plus (a) without duplication and to the extent deducted in determining Consolidated Net Income for such period, the sum of (i) Interest Expense, (ii) income tax expense, (iii) depreciation expense, (iv) amortization expense and (v) other non-cash charges.

"Event of Default" has the meaning assigned to such term in Section 8.01.

"GAAP" means generally accepted accounting principles in the United States set forth in the opinions and pronouncements of the Accounting Principles Board and the American Institute of Certified Public Accountants.

"Governmental Authority" means the government of the United States or any other nation, or of any political subdivision thereof, whether state or local, and any agency, authority, instrumentality, regulatory body, court, central bank or other entity exercising executive, legislative, judicial, taxing, regulatory or administrative powers or functions of or pertaining to government.

"Guaranty" means the Guaranty made by the Guarantors in favor of the Administrative Agent and the Lenders, dated as of the Closing Date.

"Indebtedness" means, with respect to any Person at any date, without duplication: (a) all indebtedness of such Person for borrowed money, (b) all obligations of such Person evidenced by bonds, debentures, notes or other similar instruments, and (c) all obligations of such Person under conditional sale or other title retention agreements.

"Interest Expense" means, for any period, total interest expense of the Borrower and its Subsidiaries for such period determined on a consolidated basis in accordance with GAAP.

"Lender" means each financial institution listed on Schedule 2.01 and any other Person that becomes a party hereto pursuant to an Assignment and Assumption.

"Lien" means, with respect to any asset, any mortgage, lien, pledge, charge, security interest or encumbrance of any kind in respect of such asset.

"Loan Documents" means this Credit Agreement, the Security Agreement, the Guaranty, the Pledge Agreement, each Promissory Note, and all other agreements, instruments and documents executed in connection herewith.

"Loan Parties" means the Borrower and the Guarantors.

"Material Adverse Effect" means a material adverse effect on (a) the business, assets, operations, prospects or condition, financial or otherwise, of the Borrower and its Subsidiaries taken as a whole, (b) the ability of any Loan Party to perform its Obligations, or (c) the rights and remedies of the Administrative Agent and the Lenders under the Loan Documents.

"Maturity Date" means March 15, 2030.

"Obligations" means all unpaid principal of and accrued and unpaid interest on the Loans, all accrued and unpaid fees and all expenses, reimbursements, indemnities and other obligations of the Loan Parties to the Lenders or to any Lender, the Administrative Agent, or any indemnified party arising under the Loan Documents.

"Person" means any natural person, corporation, limited liability company, trust, joint venture, association, company, partnership, Governmental Authority or other entity.

"Permitted Liens" means the Liens permitted pursuant to Section 7.01.

"Revolving Loan" means a loan made by a Lender to the Borrower pursuant to Section 2.01.

"Security Agreement" means the Security Agreement, dated as of the Closing Date, among the Loan Parties and the Administrative Agent.

"Security Documents" means the Security Agreement, the Pledge Agreement, and all other security agreements, pledge agreements, collateral assignments, mortgages, deeds of trust, and other similar agreements now or hereafter entered into by any Loan Party.

"Subsidiary" means, with respect to any Person, any corporation, partnership, limited liability company, association, joint venture or other business entity of which more than 50% of the total voting power of shares of stock or other ownership interests entitled to vote in the election of directors, managers or trustees thereof is owned or controlled, directly or indirectly, by such Person.

"Total Leverage Ratio" means, as of any date of determination, the ratio of (a) Consolidated Total Indebtedness as of such date to (b) EBITDA for the period of four consecutive fiscal quarters ending on or most recently ended prior to such date.
'''
