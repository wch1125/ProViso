"""
[Project Name] - Main Application

This is the entry point for the application.
Replace this docstring with your project description.
"""

# Uncomment and modify as needed:

# FastAPI example:
# from fastapi import FastAPI
# app = FastAPI(title="[Project Name]")
#
# @app.get("/")
# async def root():
#     return {"message": "Hello World"}
#
# if __name__ == "__main__":
#     import uvicorn
#     uvicorn.run(app, host="127.0.0.1", port=8000)

# Flask example:
# from flask import Flask
# app = Flask(__name__)
#
# @app.route("/")
# def hello():
#     return "Hello World"
#
# if __name__ == "__main__":
#     app.run(debug=True)

# Simple script example:
def main():
    """Main entry point."""
    print("Hello from [Project Name]")
    print("Edit src/main.py to get started.")


if __name__ == "__main__":
    main()
