"""
Legal Transaction Engine - Version Control & Audit System

Gwern-inspired features:
1. Git-based version control for all data changes
2. Immutable audit log with cryptographic hashes
3. Point-in-time snapshots
4. Change tracking with diffs
5. Automatic archiving

Every change to the system is:
- Recorded in an append-only audit log
- Committed to a Git repository
- Timestamped with microsecond precision
- Hashed for integrity verification
"""

import os
import json
import hashlib
import subprocess
from datetime import datetime
from pathlib import Path
from typing import Optional, Any
from dataclasses import dataclass, asdict
import shutil


@dataclass
class AuditEntry:
    """An immutable record of a change to the system."""
    timestamp: str
    action: str  # CREATE, UPDATE, DELETE, GENERATE, etc.
    entity_type: str  # transaction, document, party, condition
    entity_id: str
    user: str  # For future multi-user support
    changes: dict  # What changed (before/after for updates)
    checksum: str  # SHA-256 of the entry content
    git_commit: Optional[str] = None  # Git commit SHA if available


class VersionControl:
    """
    Git-based version control for the data directory.
    
    Every change to JSON data files is automatically committed,
    creating a complete history of all modifications.
    """
    
    def __init__(self, repo_path: str):
        self.repo_path = Path(repo_path)
        self.git_available = self._check_git()
        
        if self.git_available:
            self._init_repo()
    
    def _check_git(self) -> bool:
        """Check if git is available."""
        try:
            subprocess.run(["git", "--version"], capture_output=True, check=True)
            return True
        except (subprocess.CalledProcessError, FileNotFoundError):
            return False
    
    def _init_repo(self):
        """Initialize git repo if not already initialized."""
        git_dir = self.repo_path / ".git"
        if not git_dir.exists():
            subprocess.run(
                ["git", "init"],
                cwd=self.repo_path,
                capture_output=True
            )
            
            # Create .gitignore
            gitignore = self.repo_path / ".gitignore"
            gitignore.write_text("*.pyc\n__pycache__/\n*.tmp\n")
            
            # Initial commit
            self._commit("Initial commit - Legal Transaction Engine")
    
    def _commit(self, message: str) -> Optional[str]:
        """Stage all changes and commit."""
        if not self.git_available:
            return None
        
        try:
            # Stage all changes
            subprocess.run(
                ["git", "add", "-A"],
                cwd=self.repo_path,
                capture_output=True
            )
            
            # Commit
            result = subprocess.run(
                ["git", "commit", "-m", message, "--allow-empty"],
                cwd=self.repo_path,
                capture_output=True,
                text=True
            )
            
            # Get commit SHA
            result = subprocess.run(
                ["git", "rev-parse", "HEAD"],
                cwd=self.repo_path,
                capture_output=True,
                text=True
            )
            
            return result.stdout.strip() if result.returncode == 0 else None
            
        except Exception as e:
            print(f"Git commit failed: {e}")
            return None
    
    def commit_change(self, action: str, entity_type: str, entity_id: str, description: str = "") -> Optional[str]:
        """Commit a change with a descriptive message."""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        message = f"[{action}] {entity_type}/{entity_id[:8]}"
        if description:
            message += f": {description}"
        message += f" ({timestamp})"
        
        return self._commit(message)
    
    def get_history(self, limit: int = 50) -> list[dict]:
        """Get commit history."""
        if not self.git_available:
            return []
        
        try:
            result = subprocess.run(
                ["git", "log", f"-{limit}", "--pretty=format:%H|%ai|%s"],
                cwd=self.repo_path,
                capture_output=True,
                text=True
            )
            
            history = []
            for line in result.stdout.strip().split("\n"):
                if line:
                    parts = line.split("|", 2)
                    if len(parts) == 3:
                        history.append({
                            "commit": parts[0],
                            "date": parts[1],
                            "message": parts[2]
                        })
            
            return history
            
        except Exception:
            return []
    
    def get_file_history(self, filepath: str, limit: int = 20) -> list[dict]:
        """Get history for a specific file."""
        if not self.git_available:
            return []
        
        try:
            result = subprocess.run(
                ["git", "log", f"-{limit}", "--pretty=format:%H|%ai|%s", "--", filepath],
                cwd=self.repo_path,
                capture_output=True,
                text=True
            )
            
            history = []
            for line in result.stdout.strip().split("\n"):
                if line:
                    parts = line.split("|", 2)
                    if len(parts) == 3:
                        history.append({
                            "commit": parts[0],
                            "date": parts[1],
                            "message": parts[2]
                        })
            
            return history
            
        except Exception:
            return []
    
    def get_diff(self, commit1: str, commit2: str = "HEAD") -> str:
        """Get diff between two commits."""
        if not self.git_available:
            return ""
        
        try:
            result = subprocess.run(
                ["git", "diff", commit1, commit2],
                cwd=self.repo_path,
                capture_output=True,
                text=True
            )
            return result.stdout
        except Exception:
            return ""
    
    def get_file_at_commit(self, filepath: str, commit: str) -> Optional[str]:
        """Get file contents at a specific commit."""
        if not self.git_available:
            return None
        
        try:
            result = subprocess.run(
                ["git", "show", f"{commit}:{filepath}"],
                cwd=self.repo_path,
                capture_output=True,
                text=True
            )
            return result.stdout if result.returncode == 0 else None
        except Exception:
            return None


class AuditLog:
    """
    Append-only audit log with cryptographic integrity.
    
    Every entry is:
    - Timestamped with microsecond precision
    - Hashed with SHA-256
    - Chained to previous entry (like a simple blockchain)
    - Written to an append-only log file
    """
    
    def __init__(self, log_dir: str):
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self.log_file = self.log_dir / "audit.jsonl"
        self.last_checksum = self._get_last_checksum()
    
    def _get_last_checksum(self) -> str:
        """Get the checksum of the last entry (for chaining)."""
        if not self.log_file.exists():
            return "GENESIS"
        
        try:
            with open(self.log_file, 'r') as f:
                lines = f.readlines()
                if lines:
                    last_entry = json.loads(lines[-1])
                    return last_entry.get("checksum", "GENESIS")
        except Exception:
            pass
        
        return "GENESIS"
    
    def _compute_checksum(self, data: dict, previous_checksum: str) -> str:
        """Compute SHA-256 checksum including chain to previous entry."""
        content = json.dumps(data, sort_keys=True) + previous_checksum
        return hashlib.sha256(content.encode()).hexdigest()
    
    def log(
        self,
        action: str,
        entity_type: str,
        entity_id: str,
        changes: dict = None,
        user: str = "system",
        git_commit: str = None
    ) -> AuditEntry:
        """
        Record an action in the audit log.
        
        Args:
            action: What happened (CREATE, UPDATE, DELETE, GENERATE, etc.)
            entity_type: Type of entity (transaction, document, party, condition)
            entity_id: ID of the entity
            changes: Dictionary of what changed
            user: Who made the change
            git_commit: Associated git commit SHA
        
        Returns:
            The created AuditEntry
        """
        timestamp = datetime.now().isoformat(timespec='microseconds')
        
        entry_data = {
            "timestamp": timestamp,
            "action": action,
            "entity_type": entity_type,
            "entity_id": entity_id,
            "user": user,
            "changes": changes or {},
            "previous_checksum": self.last_checksum,
        }
        
        checksum = self._compute_checksum(entry_data, self.last_checksum)
        
        entry = AuditEntry(
            timestamp=timestamp,
            action=action,
            entity_type=entity_type,
            entity_id=entity_id,
            user=user,
            changes=changes or {},
            checksum=checksum,
            git_commit=git_commit,
        )
        
        # Append to log file
        with open(self.log_file, 'a') as f:
            f.write(json.dumps(asdict(entry)) + "\n")
        
        self.last_checksum = checksum
        return entry
    
    def get_entries(
        self,
        entity_type: str = None,
        entity_id: str = None,
        action: str = None,
        limit: int = 100
    ) -> list[AuditEntry]:
        """Query audit log entries."""
        if not self.log_file.exists():
            return []
        
        entries = []
        with open(self.log_file, 'r') as f:
            for line in f:
                if line.strip():
                    data = json.loads(line)
                    
                    # Apply filters
                    if entity_type and data.get("entity_type") != entity_type:
                        continue
                    if entity_id and data.get("entity_id") != entity_id:
                        continue
                    if action and data.get("action") != action:
                        continue
                    
                    entries.append(AuditEntry(**data))
        
        # Return most recent first, limited
        return list(reversed(entries[-limit:]))
    
    def verify_integrity(self) -> tuple[bool, list[str]]:
        """
        Verify the integrity of the audit log.
        
        Returns:
            (is_valid, list of error messages)
        """
        if not self.log_file.exists():
            return True, []
        
        errors = []
        previous_checksum = "GENESIS"
        
        with open(self.log_file, 'r') as f:
            for line_num, line in enumerate(f, 1):
                if not line.strip():
                    continue
                
                try:
                    data = json.loads(line)
                    stored_checksum = data.pop("checksum")
                    stored_previous = data.pop("previous_checksum", "GENESIS")
                    git_commit = data.pop("git_commit", None)
                    
                    # Verify chain
                    if stored_previous != previous_checksum:
                        errors.append(f"Line {line_num}: Chain broken - expected {previous_checksum[:8]}, got {stored_previous[:8]}")
                    
                    # Verify checksum
                    computed = self._compute_checksum(data, stored_previous)
                    if computed != stored_checksum:
                        errors.append(f"Line {line_num}: Checksum mismatch - data may be corrupted")
                    
                    previous_checksum = stored_checksum
                    
                except json.JSONDecodeError:
                    errors.append(f"Line {line_num}: Invalid JSON")
                except Exception as e:
                    errors.append(f"Line {line_num}: {str(e)}")
        
        return len(errors) == 0, errors
    
    def get_entity_timeline(self, entity_type: str, entity_id: str) -> list[dict]:
        """Get complete timeline of changes for an entity."""
        entries = self.get_entries(entity_type=entity_type, entity_id=entity_id, limit=1000)
        
        timeline = []
        for entry in reversed(entries):  # Chronological order
            timeline.append({
                "timestamp": entry.timestamp,
                "action": entry.action,
                "changes": entry.changes,
                "user": entry.user,
                "checksum": entry.checksum[:8],
            })
        
        return timeline


class SnapshotManager:
    """
    Creates and manages point-in-time snapshots of the entire system.
    
    Useful for:
    - Closing date snapshots (immutable record of closing set)
    - Rollback points
    - Archival
    """
    
    def __init__(self, data_dir: str, snapshot_dir: str):
        self.data_dir = Path(data_dir)
        self.snapshot_dir = Path(snapshot_dir)
        self.snapshot_dir.mkdir(parents=True, exist_ok=True)
    
    def create_snapshot(self, name: str, description: str = "") -> dict:
        """
        Create a named snapshot of the current state.
        
        Args:
            name: Snapshot name (e.g., "closing-2025-03-15")
            description: Optional description
        
        Returns:
            Snapshot metadata
        """
        timestamp = datetime.now()
        snapshot_id = f"{name}_{timestamp.strftime('%Y%m%d_%H%M%S')}"
        snapshot_path = self.snapshot_dir / snapshot_id
        
        # Copy all data files
        shutil.copytree(self.data_dir, snapshot_path)
        
        # Create manifest with checksums
        manifest = {
            "id": snapshot_id,
            "name": name,
            "description": description,
            "created_at": timestamp.isoformat(),
            "files": {}
        }
        
        for filepath in snapshot_path.glob("*.json"):
            content = filepath.read_bytes()
            manifest["files"][filepath.name] = {
                "size": len(content),
                "checksum": hashlib.sha256(content).hexdigest()
            }
        
        # Save manifest
        manifest_path = snapshot_path / "MANIFEST.json"
        manifest_path.write_text(json.dumps(manifest, indent=2))
        
        return manifest
    
    def list_snapshots(self) -> list[dict]:
        """List all snapshots."""
        snapshots = []
        
        for path in sorted(self.snapshot_dir.iterdir()):
            if path.is_dir():
                manifest_path = path / "MANIFEST.json"
                if manifest_path.exists():
                    manifest = json.loads(manifest_path.read_text())
                    snapshots.append(manifest)
        
        return snapshots
    
    def verify_snapshot(self, snapshot_id: str) -> tuple[bool, list[str]]:
        """Verify integrity of a snapshot."""
        snapshot_path = self.snapshot_dir / snapshot_id
        manifest_path = snapshot_path / "MANIFEST.json"
        
        if not manifest_path.exists():
            return False, ["Manifest not found"]
        
        manifest = json.loads(manifest_path.read_text())
        errors = []
        
        for filename, info in manifest.get("files", {}).items():
            filepath = snapshot_path / filename
            
            if not filepath.exists():
                errors.append(f"Missing file: {filename}")
                continue
            
            content = filepath.read_bytes()
            
            if len(content) != info["size"]:
                errors.append(f"Size mismatch: {filename}")
            
            if hashlib.sha256(content).hexdigest() != info["checksum"]:
                errors.append(f"Checksum mismatch: {filename}")
        
        return len(errors) == 0, errors
    
    def restore_snapshot(self, snapshot_id: str, target_dir: str = None) -> bool:
        """
        Restore from a snapshot.
        
        Args:
            snapshot_id: ID of snapshot to restore
            target_dir: Where to restore (defaults to data_dir)
        
        Returns:
            True if successful
        """
        snapshot_path = self.snapshot_dir / snapshot_id
        target = Path(target_dir) if target_dir else self.data_dir
        
        if not snapshot_path.exists():
            return False
        
        # Verify first
        is_valid, errors = self.verify_snapshot(snapshot_id)
        if not is_valid:
            print(f"Snapshot verification failed: {errors}")
            return False
        
        # Backup current state
        backup_name = f"pre_restore_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        self.create_snapshot(backup_name, "Automatic backup before restore")
        
        # Restore files (excluding manifest)
        for filepath in snapshot_path.glob("*.json"):
            if filepath.name != "MANIFEST.json":
                shutil.copy(filepath, target / filepath.name)
        
        return True


class DocumentArchive:
    """
    Archives generated documents with metadata and checksums.
    
    Provides:
    - Immutable storage of generated documents
    - Deduplication via content hashing
    - Metadata tracking (when generated, from what data, etc.)
    """
    
    def __init__(self, archive_dir: str):
        self.archive_dir = Path(archive_dir)
        self.archive_dir.mkdir(parents=True, exist_ok=True)
        self.index_file = self.archive_dir / "index.json"
        self.index = self._load_index()
    
    def _load_index(self) -> dict:
        """Load the archive index."""
        if self.index_file.exists():
            return json.loads(self.index_file.read_text())
        return {"documents": {}}
    
    def _save_index(self):
        """Save the archive index."""
        self.index_file.write_text(json.dumps(self.index, indent=2))
    
    def archive_document(
        self,
        source_path: str,
        doc_type: str,
        transaction_id: str,
        metadata: dict = None
    ) -> dict:
        """
        Archive a generated document.
        
        Args:
            source_path: Path to the document to archive
            doc_type: Type of document (officers_cert, secretary_cert, etc.)
            transaction_id: Associated transaction
            metadata: Additional metadata
        
        Returns:
            Archive entry metadata
        """
        source = Path(source_path)
        if not source.exists():
            raise FileNotFoundError(f"Document not found: {source_path}")
        
        # Compute content hash
        content = source.read_bytes()
        content_hash = hashlib.sha256(content).hexdigest()
        
        # Check for duplicate
        if content_hash in self.index["documents"]:
            existing = self.index["documents"][content_hash]
            existing["access_count"] = existing.get("access_count", 0) + 1
            self._save_index()
            return existing
        
        # Archive the file
        timestamp = datetime.now()
        archive_filename = f"{content_hash[:16]}_{source.name}"
        archive_path = self.archive_dir / archive_filename
        
        shutil.copy(source, archive_path)
        
        # Create entry
        entry = {
            "content_hash": content_hash,
            "original_name": source.name,
            "archive_path": str(archive_path),
            "doc_type": doc_type,
            "transaction_id": transaction_id,
            "created_at": timestamp.isoformat(),
            "size": len(content),
            "metadata": metadata or {},
            "access_count": 1,
        }
        
        self.index["documents"][content_hash] = entry
        self._save_index()
        
        return entry
    
    def get_document(self, content_hash: str) -> Optional[Path]:
        """Get path to an archived document."""
        if content_hash in self.index["documents"]:
            entry = self.index["documents"][content_hash]
            path = Path(entry["archive_path"])
            if path.exists():
                entry["access_count"] = entry.get("access_count", 0) + 1
                self._save_index()
                return path
        return None
    
    def find_documents(
        self,
        transaction_id: str = None,
        doc_type: str = None
    ) -> list[dict]:
        """Find archived documents matching criteria."""
        results = []
        
        for entry in self.index["documents"].values():
            if transaction_id and entry.get("transaction_id") != transaction_id:
                continue
            if doc_type and entry.get("doc_type") != doc_type:
                continue
            results.append(entry)
        
        return sorted(results, key=lambda x: x.get("created_at", ""), reverse=True)
    
    def verify_archive(self) -> tuple[bool, list[str]]:
        """Verify integrity of all archived documents."""
        errors = []
        
        for content_hash, entry in self.index["documents"].items():
            path = Path(entry["archive_path"])
            
            if not path.exists():
                errors.append(f"Missing: {entry['original_name']}")
                continue
            
            actual_hash = hashlib.sha256(path.read_bytes()).hexdigest()
            if actual_hash != content_hash:
                errors.append(f"Corrupted: {entry['original_name']}")
        
        return len(errors) == 0, errors
