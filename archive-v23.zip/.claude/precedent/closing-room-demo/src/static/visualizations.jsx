/**
 * Gwern-Inspired Legal Document Visualizations - Enhanced Edition
 * 
 * Six interconnected visualization systems:
 * 1. Term Usage Heatmap - Interactive Document × Term matrix with sorting/filtering
 * 2. Term Connection Network - Force-directed graph with search & path finding
 * 3. Definition Impact Analysis - Cascade visualization for term changes
 * 4. Condition Flow Network - Dependencies between closing conditions
 * 5. Checklist Tree - Hierarchical document tree
 */

import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import * as d3 from 'd3';

// ============================================================================
// SHARED STYLES & CONSTANTS
// ============================================================================

const COLORS = {
  navy: '#1a2744',
  navyLight: '#2d3f5f',
  gold: '#B8860B',
  goldLight: '#D4A84B',
  cream: '#FAFAF8',
  white: '#ffffff',
  
  // Category colors for terms
  party: '#3b82f6',
  financial: '#10b981',
  date: '#f59e0b',
  document: '#8b5cf6',
  covenant: '#ef4444',
  collateral: '#ec4899',
  facility: '#06b6d4',
  general: '#6b7280',
  
  // Status colors
  satisfied: '#22c55e',
  inProgress: '#3b82f6',
  pending: '#9ca3af',
  waived: '#8b5cf6',
  missing: '#ef4444',
  expected: '#f59e0b',
  
  // Impact colors
  direct: '#ef4444',
  indirect: '#f97316',
  tertiary: '#fbbf24',
};

const CATEGORY_COLORS = {
  party: COLORS.party,
  financial: COLORS.financial,
  date: COLORS.date,
  document: COLORS.document,
  covenant: COLORS.covenant,
  collateral: COLORS.collateral,
  facility: COLORS.facility,
  general: COLORS.general,
};

const STATUS_COLORS = {
  not_started: COLORS.pending,
  drafting: COLORS.inProgress,
  internal_review: '#f59e0b',
  out_for_review: '#f59e0b',
  comments_received: '#f97316',
  final: COLORS.satisfied,
  executed: COLORS.satisfied,
  filed: COLORS.satisfied,
  superseded: '#6b7280',
  pending: COLORS.pending,
  in_progress: COLORS.inProgress,
  satisfied: COLORS.satisfied,
  waived: COLORS.waived,
  not_applicable: '#6b7280',
  missing: COLORS.missing,
  expected: COLORS.expected,
};

const EDGE_TYPE_COLORS = {
  references: COLORS.general,
  defines_as: COLORS.party,
  includes: COLORS.document,
  incorporates: COLORS.financial,
  part_of: COLORS.facility,
  supersedes: COLORS.covenant,
  mutual: COLORS.collateral,
  requires: COLORS.covenant,
  concurrent: COLORS.financial,
  precedes: COLORS.party,
};

// Color schemes for heatmap
const COLOR_SCHEMES = {
  navy: { name: 'Navy/Gold', low: COLORS.cream, high: COLORS.navy },
  heat: { name: 'Heat', low: '#fef3c7', high: '#dc2626' },
  ocean: { name: 'Ocean', low: '#ecfeff', high: '#0e7490' },
  forest: { name: 'Forest', low: '#ecfdf5', high: '#047857' },
  purple: { name: 'Purple', low: '#faf5ff', high: '#7c3aed' },
};

// ============================================================================
// SHARED COMPONENTS
// ============================================================================

function ControlPanel({ children }) {
  return (
    <div style={{
      display: 'flex',
      flexWrap: 'wrap',
      gap: '12px',
      marginBottom: '16px',
      padding: '12px 16px',
      background: COLORS.cream,
      borderRadius: '8px',
      border: `1px solid ${COLORS.goldLight}`,
    }}>
      {children}
    </div>
  );
}

function ControlGroup({ label, children }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
      <label style={{ fontSize: '10px', fontWeight: '600', color: COLORS.navy, textTransform: 'uppercase', letterSpacing: '0.5px' }}>
        {label}
      </label>
      {children}
    </div>
  );
}

function Select({ value, onChange, options }) {
  return (
    <select
      value={value}
      onChange={(e) => onChange(e.target.value)}
      style={{
        padding: '6px 10px',
        borderRadius: '4px',
        border: `1px solid ${COLORS.goldLight}`,
        background: COLORS.white,
        fontSize: '12px',
        color: COLORS.navy,
        cursor: 'pointer',
        minWidth: '120px',
      }}
    >
      {options.map(opt => (
        <option key={opt.value} value={opt.value}>{opt.label}</option>
      ))}
    </select>
  );
}

function SearchInput({ value, onChange, placeholder }) {
  return (
    <input
      type="text"
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      style={{
        padding: '6px 10px',
        borderRadius: '4px',
        border: `1px solid ${COLORS.goldLight}`,
        background: COLORS.white,
        fontSize: '12px',
        color: COLORS.navy,
        width: '180px',
      }}
    />
  );
}

function Button({ onClick, active, children, small }) {
  return (
    <button
      onClick={onClick}
      style={{
        padding: small ? '4px 8px' : '6px 12px',
        borderRadius: '4px',
        border: 'none',
        background: active ? COLORS.navy : COLORS.goldLight,
        color: active ? COLORS.white : COLORS.navy,
        fontSize: small ? '10px' : '12px',
        fontWeight: '500',
        cursor: 'pointer',
        transition: 'all 0.15s',
      }}
    >
      {children}
    </button>
  );
}

function Tooltip({ show, x, y, children }) {
  if (!show) return null;
  return (
    <div style={{
      position: 'absolute',
      left: x,
      top: y,
      transform: 'translate(-50%, -100%)',
      background: COLORS.navy,
      color: '#fff',
      padding: '8px 12px',
      borderRadius: '6px',
      fontSize: '12px',
      maxWidth: '280px',
      pointerEvents: 'none',
      boxShadow: '0 4px 12px rgba(0,0,0,0.25)',
      zIndex: 1000,
    }}>
      {children}
    </div>
  );
}

// ============================================================================
// 1. ENHANCED INTERACTIVE HEATMAP
// ============================================================================

export function TermUsageHeatmap({ terms, documents, usageMatrix }) {
  const svgRef = useRef(null);
  const containerRef = useRef(null);
  const [tooltip, setTooltip] = useState({ show: false, x: 0, y: 0, content: '' });
  const [selectedTerm, setSelectedTerm] = useState(null);
  const [selectedDoc, setSelectedDoc] = useState(null);
  
  // Controls
  const [colorScheme, setColorScheme] = useState('navy');
  const [sortBy, setSortBy] = useState('default');
  const [filterCategory, setFilterCategory] = useState('all');
  const [showValues, setShowValues] = useState(true);
  
  // Get unique categories
  const categories = useMemo(() => {
    const cats = new Set(terms.map(t => t.category));
    return ['all', ...Array.from(cats)];
  }, [terms]);
  
  // Sort and filter terms
  const processedData = useMemo(() => {
    let filteredTerms = terms;
    let filteredMatrix = usageMatrix;
    
    // Filter by category
    if (filterCategory !== 'all') {
      const indices = terms.map((t, i) => t.category === filterCategory ? i : -1).filter(i => i !== -1);
      filteredTerms = indices.map(i => terms[i]);
      filteredMatrix = indices.map(i => usageMatrix[i]);
    }
    
    // Create sortable array with indices
    let sortableTerms = filteredTerms.map((t, i) => ({
      term: t,
      matrix: filteredMatrix[i],
      originalIndex: i,
      totalUsage: filteredMatrix[i]?.reduce((a, b) => a + b, 0) || 0,
    }));
    
    // Sort
    switch (sortBy) {
      case 'alpha':
        sortableTerms.sort((a, b) => a.term.term.localeCompare(b.term.term));
        break;
      case 'usage-high':
        sortableTerms.sort((a, b) => b.totalUsage - a.totalUsage);
        break;
      case 'usage-low':
        sortableTerms.sort((a, b) => a.totalUsage - b.totalUsage);
        break;
      case 'category':
        sortableTerms.sort((a, b) => a.term.category.localeCompare(b.term.category));
        break;
    }
    
    return {
      terms: sortableTerms.map(s => s.term),
      matrix: sortableTerms.map(s => s.matrix),
    };
  }, [terms, usageMatrix, sortBy, filterCategory]);
  
  // Compute dimensions
  const margin = { top: 140, right: 40, bottom: 40, left: 200 };
  const cellSize = 28;
  const width = margin.left + margin.right + documents.length * cellSize;
  const height = margin.top + margin.bottom + processedData.terms.length * cellSize;
  
  useEffect(() => {
    if (!svgRef.current || !processedData.terms.length || !documents.length) return;
    
    const svg = d3.select(svgRef.current);
    svg.selectAll('*').remove();
    
    const scheme = COLOR_SCHEMES[colorScheme];
    
    const defs = svg.append('defs');
    
    const g = svg.append('g')
      .attr('transform', `translate(${margin.left}, ${margin.top})`);
    
    // Color scale
    const maxUsage = d3.max(processedData.matrix.flat()) || 1;
    const colorScale = d3.scaleSequential()
      .domain([0, maxUsage])
      .interpolator(d3.interpolate(scheme.low, scheme.high));
    
    // Document labels (columns)
    g.append('g')
      .attr('class', 'doc-labels')
      .selectAll('text')
      .data(documents)
      .join('text')
      .attr('x', (d, i) => i * cellSize + cellSize / 2)
      .attr('y', -10)
      .attr('text-anchor', 'start')
      .attr('transform', (d, i) => `rotate(-45, ${i * cellSize + cellSize / 2}, -10)`)
      .style('font-size', '11px')
      .style('font-family', 'Source Sans 3, sans-serif')
      .style('fill', d => selectedDoc === d.id ? COLORS.gold : COLORS.navy)
      .style('font-weight', d => selectedDoc === d.id ? '600' : '400')
      .style('cursor', 'pointer')
      .text(d => d.title.length > 20 ? d.title.slice(0, 18) + '…' : d.title)
      .on('click', (event, d) => setSelectedDoc(selectedDoc === d.id ? null : d.id));
    
    // Term labels (rows)
    g.append('g')
      .attr('class', 'term-labels')
      .selectAll('text')
      .data(processedData.terms)
      .join('text')
      .attr('x', -8)
      .attr('y', (d, i) => i * cellSize + cellSize / 2)
      .attr('text-anchor', 'end')
      .attr('dominant-baseline', 'middle')
      .style('font-size', '11px')
      .style('font-family', 'Source Sans 3, sans-serif')
      .style('fill', d => selectedTerm === d.term ? COLORS.gold : COLORS.navy)
      .style('font-weight', d => selectedTerm === d.term ? '600' : '400')
      .style('cursor', 'pointer')
      .text(d => d.term.length > 25 ? d.term.slice(0, 23) + '…' : d.term)
      .on('click', (event, d) => setSelectedTerm(selectedTerm === d.term ? null : d.term));
    
    // Category indicators
    g.append('g')
      .attr('class', 'category-indicators')
      .selectAll('rect')
      .data(processedData.terms)
      .join('rect')
      .attr('x', -margin.left + 10)
      .attr('y', (d, i) => i * cellSize + 4)
      .attr('width', 4)
      .attr('height', cellSize - 8)
      .attr('rx', 2)
      .attr('fill', d => CATEGORY_COLORS[d.category] || COLORS.general);
    
    // Heatmap cells
    const cells = g.append('g').attr('class', 'heatmap-cells');
    
    processedData.terms.forEach((term, i) => {
      documents.forEach((doc, j) => {
        const usage = processedData.matrix[i]?.[j] || 0;
        const isHighlighted = selectedTerm === term.term || selectedDoc === doc.id;
        
        cells.append('rect')
          .attr('x', j * cellSize + 1)
          .attr('y', i * cellSize + 1)
          .attr('width', cellSize - 2)
          .attr('height', cellSize - 2)
          .attr('rx', 3)
          .attr('fill', usage > 0 ? colorScale(usage) : scheme.low)
          .attr('stroke', isHighlighted ? COLORS.gold : 'transparent')
          .attr('stroke-width', 2)
          .style('cursor', 'pointer')
          .style('opacity', (selectedTerm || selectedDoc) && !isHighlighted ? 0.4 : 1)
          .on('mouseenter', function(event) {
            d3.select(this).attr('stroke', COLORS.gold).attr('stroke-width', 2);
            const rect = event.target.getBoundingClientRect();
            const containerRect = containerRef.current.getBoundingClientRect();
            setTooltip({
              show: true,
              x: rect.left - containerRect.left + cellSize / 2,
              y: rect.top - containerRect.top - 10,
              content: `"${term.term}" in ${doc.title}: ${usage} occurrence${usage !== 1 ? 's' : ''}`
            });
          })
          .on('mouseleave', function() {
            d3.select(this).attr('stroke', isHighlighted ? COLORS.gold : 'transparent');
            setTooltip({ show: false, x: 0, y: 0, content: '' });
          });
        
        // Usage count in cell
        if (showValues && usage > 0) {
          cells.append('text')
            .attr('x', j * cellSize + cellSize / 2)
            .attr('y', i * cellSize + cellSize / 2)
            .attr('text-anchor', 'middle')
            .attr('dominant-baseline', 'middle')
            .style('font-size', '10px')
            .style('font-weight', '500')
            .style('fill', usage > maxUsage * 0.5 ? '#fff' : COLORS.navy)
            .style('pointer-events', 'none')
            .style('opacity', (selectedTerm || selectedDoc) && !isHighlighted ? 0.4 : 1)
            .text(usage);
        }
      });
    });
    
    // Legend
    const legendWidth = 120;
    const legend = svg.append('g')
      .attr('transform', `translate(${width - margin.right - legendWidth}, 20)`);
    
    const legendGradient = defs.append('linearGradient')
      .attr('id', 'legend-gradient')
      .attr('x1', '0%').attr('y1', '0%')
      .attr('x2', '100%').attr('y2', '0%');
    
    legendGradient.append('stop').attr('offset', '0%').attr('stop-color', scheme.low);
    legendGradient.append('stop').attr('offset', '100%').attr('stop-color', scheme.high);
    
    legend.append('rect')
      .attr('width', legendWidth)
      .attr('height', 10)
      .attr('rx', 2)
      .attr('fill', 'url(#legend-gradient)');
    
    legend.append('text')
      .attr('y', -4)
      .style('font-size', '10px')
      .style('fill', COLORS.navy)
      .text('Usage Frequency');
    
    legend.append('text')
      .attr('y', 22)
      .style('font-size', '9px')
      .style('fill', COLORS.general)
      .text('0');
    
    legend.append('text')
      .attr('x', legendWidth)
      .attr('y', 22)
      .attr('text-anchor', 'end')
      .style('font-size', '9px')
      .style('fill', COLORS.general)
      .text(maxUsage);
    
  }, [processedData, documents, selectedTerm, selectedDoc, colorScheme, showValues, margin, cellSize, width]);
  
  return (
    <div>
      <ControlPanel>
        <ControlGroup label="Color Scheme">
          <Select
            value={colorScheme}
            onChange={setColorScheme}
            options={Object.entries(COLOR_SCHEMES).map(([k, v]) => ({ value: k, label: v.name }))}
          />
        </ControlGroup>
        <ControlGroup label="Sort By">
          <Select
            value={sortBy}
            onChange={setSortBy}
            options={[
              { value: 'default', label: 'Default' },
              { value: 'alpha', label: 'Alphabetical' },
              { value: 'usage-high', label: 'Usage (High→Low)' },
              { value: 'usage-low', label: 'Usage (Low→High)' },
              { value: 'category', label: 'Category' },
            ]}
          />
        </ControlGroup>
        <ControlGroup label="Filter Category">
          <Select
            value={filterCategory}
            onChange={setFilterCategory}
            options={categories.map(c => ({ value: c, label: c === 'all' ? 'All Categories' : c }))}
          />
        </ControlGroup>
        <ControlGroup label="Display">
          <Button onClick={() => setShowValues(!showValues)} active={showValues}>
            {showValues ? '✓ Show Values' : 'Show Values'}
          </Button>
        </ControlGroup>
        {(selectedTerm || selectedDoc) && (
          <ControlGroup label="Selection">
            <Button onClick={() => { setSelectedTerm(null); setSelectedDoc(null); }}>
              Clear Selection
            </Button>
          </ControlGroup>
        )}
      </ControlPanel>
      
      <div ref={containerRef} style={{ position: 'relative', overflowX: 'auto' }}>
        <svg ref={svgRef} width={width} height={height} style={{ fontFamily: 'Source Sans 3, sans-serif' }} />
        <Tooltip show={tooltip.show} x={tooltip.x} y={tooltip.y}>
          {tooltip.content}
        </Tooltip>
      </div>
    </div>
  );
}

// ============================================================================
// 2. ENHANCED TERM CONNECTION NETWORK
// ============================================================================

export function TermConnectionNetwork({ terms, edges }) {
  const svgRef = useRef(null);
  const containerRef = useRef(null);
  const [dimensions, setDimensions] = useState({ width: 800, height: 600 });
  const [selectedNode, setSelectedNode] = useState(null);
  const [tooltip, setTooltip] = useState({ show: false, x: 0, y: 0, content: '', subContent: '' });
  
  // Controls
  const [searchTerm, setSearchTerm] = useState('');
  const [filterEdgeType, setFilterEdgeType] = useState('all');
  const [filterCategory, setFilterCategory] = useState('all');
  const [showLabels, setShowLabels] = useState(true);
  const [highlightPath, setHighlightPath] = useState(null);
  
  // Get unique edge types and categories
  const edgeTypes = useMemo(() => ['all', ...new Set(edges.map(e => e.type || 'references'))], [edges]);
  const categories = useMemo(() => ['all', ...new Set(terms.map(t => t.category))], [terms]);
  
  // Process data for D3
  const { nodes, links, maxWeight } = useMemo(() => {
    const nodeMap = new Map();
    terms.forEach(t => {
      const matchesSearch = !searchTerm || t.term.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesCategory = filterCategory === 'all' || t.category === filterCategory;
      
      if (matchesSearch && matchesCategory) {
        nodeMap.set(t.term, {
          id: t.term,
          category: t.category,
          definition: t.definition,
          crossRefs: t.cross_references?.length || 0,
        });
      }
    });
    
    let maxW = 1;
    const processedLinks = edges
      .filter(e => {
        const typeMatch = filterEdgeType === 'all' || e.type === filterEdgeType;
        return typeMatch && nodeMap.has(e.source) && nodeMap.has(e.target);
      })
      .map(e => {
        maxW = Math.max(maxW, e.weight || 1);
        return {
          source: e.source,
          target: e.target,
          weight: e.weight || 1,
          type: e.type || 'references',
        };
      });
    
    return {
      nodes: Array.from(nodeMap.values()),
      links: processedLinks,
      maxWeight: maxW,
    };
  }, [terms, edges, searchTerm, filterEdgeType, filterCategory]);
  
  // Find path between two nodes (for highlight feature)
  const findPath = useCallback((start, end) => {
    if (!start || !end || start === end) return null;
    
    const graph = new Map();
    links.forEach(l => {
      const src = typeof l.source === 'object' ? l.source.id : l.source;
      const tgt = typeof l.target === 'object' ? l.target.id : l.target;
      if (!graph.has(src)) graph.set(src, []);
      if (!graph.has(tgt)) graph.set(tgt, []);
      graph.get(src).push(tgt);
      graph.get(tgt).push(src); // Bidirectional for pathfinding
    });
    
    // BFS
    const queue = [[start]];
    const visited = new Set([start]);
    
    while (queue.length > 0) {
      const path = queue.shift();
      const node = path[path.length - 1];
      
      if (node === end) return path;
      
      for (const neighbor of graph.get(node) || []) {
        if (!visited.has(neighbor)) {
          visited.add(neighbor);
          queue.push([...path, neighbor]);
        }
      }
    }
    
    return null;
  }, [links]);
  
  useEffect(() => {
    const updateDimensions = () => {
      if (containerRef.current) {
        const { width, height } = containerRef.current.getBoundingClientRect();
        setDimensions({ width: Math.max(width, 600), height: Math.max(height, 500) });
      }
    };
    updateDimensions();
    window.addEventListener('resize', updateDimensions);
    return () => window.removeEventListener('resize', updateDimensions);
  }, []);
  
  useEffect(() => {
    if (!svgRef.current || !nodes.length) return;
    
    const { width, height } = dimensions;
    const svg = d3.select(svgRef.current);
    svg.selectAll('*').remove();
    
    const defs = svg.append('defs');
    
    // Glow filter
    const glow = defs.append('filter')
      .attr('id', 'glow')
      .attr('x', '-50%').attr('y', '-50%')
      .attr('width', '200%').attr('height', '200%');
    glow.append('feGaussianBlur').attr('stdDeviation', '4').attr('result', 'coloredBlur');
    const glowMerge = glow.append('feMerge');
    glowMerge.append('feMergeNode').attr('in', 'coloredBlur');
    glowMerge.append('feMergeNode').attr('in', 'SourceGraphic');
    
    // Arrow markers for each edge type
    Object.entries(EDGE_TYPE_COLORS).forEach(([type, color]) => {
      defs.append('marker')
        .attr('id', `arrow-${type}`)
        .attr('viewBox', '-0 -5 10 10')
        .attr('refX', 20)
        .attr('refY', 0)
        .attr('orient', 'auto')
        .attr('markerWidth', 6)
        .attr('markerHeight', 6)
        .append('path')
        .attr('d', 'M 0,-5 L 10 ,0 L 0,5')
        .attr('fill', color)
        .style('opacity', 0.7);
    });
    
    const g = svg.append('g');
    
    // Zoom
    const zoom = d3.zoom()
      .scaleExtent([0.2, 4])
      .on('zoom', (event) => g.attr('transform', event.transform));
    svg.call(zoom);
    
    // Simulation
    const simulation = d3.forceSimulation(nodes)
      .force('link', d3.forceLink(links).id(d => d.id).distance(120).strength(0.5))
      .force('charge', d3.forceManyBody().strength(-300))
      .force('center', d3.forceCenter(width / 2, height / 2))
      .force('collision', d3.forceCollide().radius(40));
    
    const linkWidthScale = d3.scaleLinear().domain([1, maxWeight]).range([1, 6]);
    
    // Links
    const link = g.append('g')
      .selectAll('path')
      .data(links)
      .join('path')
      .attr('fill', 'none')
      .attr('stroke', d => EDGE_TYPE_COLORS[d.type] || COLORS.general)
      .attr('stroke-width', d => linkWidthScale(d.weight))
      .attr('stroke-opacity', d => {
        if (highlightPath) {
          const src = typeof d.source === 'object' ? d.source.id : d.source;
          const tgt = typeof d.target === 'object' ? d.target.id : d.target;
          const pathSet = new Set(highlightPath);
          if (pathSet.has(src) && pathSet.has(tgt)) return 1;
          return 0.1;
        }
        return 0.6;
      })
      .attr('marker-end', d => `url(#arrow-${d.type})`)
      .style('cursor', 'pointer')
      .on('mouseenter', function(event, d) {
        d3.select(this).attr('stroke-opacity', 1).attr('stroke-width', linkWidthScale(d.weight) + 2);
        const src = typeof d.source === 'object' ? d.source.id : d.source;
        const tgt = typeof d.target === 'object' ? d.target.id : d.target;
        setTooltip({
          show: true,
          x: event.offsetX,
          y: event.offsetY - 10,
          content: `${src} → ${tgt}`,
          subContent: `Type: ${d.type}`
        });
      })
      .on('mouseleave', function(event, d) {
        d3.select(this).attr('stroke-opacity', highlightPath ? 0.1 : 0.6).attr('stroke-width', linkWidthScale(d.weight));
        setTooltip({ show: false, x: 0, y: 0, content: '', subContent: '' });
      });
    
    // Nodes
    const node = g.append('g')
      .selectAll('g')
      .data(nodes)
      .join('g')
      .style('cursor', 'pointer')
      .call(d3.drag()
        .on('start', (event, d) => { if (!event.active) simulation.alphaTarget(0.3).restart(); d.fx = d.x; d.fy = d.y; })
        .on('drag', (event, d) => { d.fx = event.x; d.fy = event.y; })
        .on('end', (event, d) => { if (!event.active) simulation.alphaTarget(0); d.fx = null; d.fy = null; }));
    
    const nodeRadius = d => 8 + Math.min(d.crossRefs * 2, 14);
    
    // Node circles
    node.append('circle')
      .attr('r', nodeRadius)
      .attr('fill', d => CATEGORY_COLORS[d.category] || COLORS.general)
      .attr('stroke', d => {
        if (highlightPath?.includes(d.id)) return COLORS.gold;
        if (selectedNode === d.id) return COLORS.gold;
        return COLORS.white;
      })
      .attr('stroke-width', d => (highlightPath?.includes(d.id) || selectedNode === d.id) ? 3 : 2)
      .attr('filter', d => (highlightPath?.includes(d.id) || selectedNode === d.id) ? 'url(#glow)' : null)
      .style('opacity', d => highlightPath && !highlightPath.includes(d.id) ? 0.3 : 1)
      .on('click', (event, d) => {
        if (event.shiftKey && selectedNode && selectedNode !== d.id) {
          const path = findPath(selectedNode, d.id);
          setHighlightPath(path);
        } else {
          setSelectedNode(selectedNode === d.id ? null : d.id);
          setHighlightPath(null);
        }
      })
      .on('mouseenter', function(event, d) {
        d3.select(this.parentNode).raise();
        setTooltip({
          show: true,
          x: event.offsetX,
          y: event.offsetY - nodeRadius(d) - 10,
          content: d.id,
          subContent: `Category: ${d.category} | References: ${d.crossRefs}`
        });
      })
      .on('mouseleave', () => setTooltip({ show: false, x: 0, y: 0, content: '', subContent: '' }));
    
    // Node labels
    if (showLabels) {
      node.append('text')
        .attr('dy', d => nodeRadius(d) + 12)
        .attr('text-anchor', 'middle')
        .style('font-size', '10px')
        .style('font-weight', '500')
        .style('fill', COLORS.navy)
        .style('pointer-events', 'none')
        .style('opacity', d => highlightPath && !highlightPath.includes(d.id) ? 0.3 : 1)
        .text(d => d.id.length > 15 ? d.id.slice(0, 13) + '…' : d.id);
    }
    
    // Simulation tick
    simulation.on('tick', () => {
      link.attr('d', d => {
        const dx = d.target.x - d.source.x;
        const dy = d.target.y - d.source.y;
        const dr = Math.sqrt(dx * dx + dy * dy) * 2;
        return `M${d.source.x},${d.source.y}A${dr},${dr} 0 0,1 ${d.target.x},${d.target.y}`;
      });
      node.attr('transform', d => `translate(${d.x}, ${d.y})`);
    });
    
    return () => simulation.stop();
  }, [nodes, links, maxWeight, dimensions, selectedNode, showLabels, highlightPath, findPath]);
  
  return (
    <div style={{ height: '100%' }}>
      <ControlPanel>
        <ControlGroup label="Search">
          <SearchInput
            value={searchTerm}
            onChange={setSearchTerm}
            placeholder="Search terms..."
          />
        </ControlGroup>
        <ControlGroup label="Edge Type">
          <Select
            value={filterEdgeType}
            onChange={setFilterEdgeType}
            options={edgeTypes.map(t => ({ value: t, label: t === 'all' ? 'All Types' : t }))}
          />
        </ControlGroup>
        <ControlGroup label="Category">
          <Select
            value={filterCategory}
            onChange={setFilterCategory}
            options={categories.map(c => ({ value: c, label: c === 'all' ? 'All' : c }))}
          />
        </ControlGroup>
        <ControlGroup label="Display">
          <Button onClick={() => setShowLabels(!showLabels)} active={showLabels}>
            {showLabels ? '✓ Labels' : 'Labels'}
          </Button>
        </ControlGroup>
        {highlightPath && (
          <ControlGroup label="Path">
            <Button onClick={() => setHighlightPath(null)}>Clear Path</Button>
          </ControlGroup>
        )}
      </ControlPanel>
      
      <div style={{ 
        fontSize: '11px', 
        color: COLORS.general, 
        marginBottom: '8px',
        padding: '8px 12px',
        background: COLORS.cream,
        borderRadius: '4px',
      }}>
        💡 <strong>Tip:</strong> Click a node to select, then <strong>Shift+Click</strong> another to find the path between them. Drag nodes to rearrange. Scroll to zoom.
      </div>
      
      <div ref={containerRef} style={{ position: 'relative', height: 'calc(100% - 120px)', minHeight: '400px' }}>
        <svg ref={svgRef} width={dimensions.width} height={dimensions.height} style={{ background: COLORS.cream }} />
        <Tooltip show={tooltip.show} x={tooltip.x} y={tooltip.y}>
          <div style={{ fontWeight: '600' }}>{tooltip.content}</div>
          {tooltip.subContent && <div style={{ fontSize: '10px', opacity: 0.8, marginTop: '4px' }}>{tooltip.subContent}</div>}
        </Tooltip>
        
        {/* Legend */}
        <div style={{
          position: 'absolute',
          bottom: '10px',
          left: '10px',
          background: 'rgba(255,255,255,0.95)',
          border: `1px solid ${COLORS.goldLight}`,
          borderRadius: '6px',
          padding: '10px',
          fontSize: '10px',
        }}>
          <div style={{ fontWeight: '600', marginBottom: '6px', color: COLORS.navy }}>Edge Types</div>
          {Object.entries(EDGE_TYPE_COLORS).slice(0, 6).map(([type, color]) => (
            <div key={type} style={{ display: 'flex', alignItems: 'center', gap: '6px', marginTop: '3px' }}>
              <div style={{ width: '16px', height: '3px', background: color, borderRadius: '2px' }} />
              <span style={{ color: COLORS.navy }}>{type}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ============================================================================
// 3. DEFINITION IMPACT ANALYSIS
// ============================================================================

export function DefinitionImpactAnalysis({ terms, edges }) {
  const svgRef = useRef(null);
  const containerRef = useRef(null);
  const [selectedTerm, setSelectedTerm] = useState(null);
  const [dimensions, setDimensions] = useState({ width: 800, height: 500 });
  const [tooltip, setTooltip] = useState({ show: false, x: 0, y: 0, content: '' });
  const [impactDepth, setImpactDepth] = useState(3);
  
  // Build adjacency for impact analysis
  const adjacency = useMemo(() => {
    const adj = new Map();
    edges.forEach(e => {
      // Reverse direction: if A references B, changing B impacts A
      if (!adj.has(e.target)) adj.set(e.target, []);
      adj.get(e.target).push({ term: e.source, type: e.type });
    });
    return adj;
  }, [edges]);
  
  // Calculate impact cascade
  const impactData = useMemo(() => {
    if (!selectedTerm) return { nodes: [], links: [], levels: [] };
    
    const visited = new Map(); // term -> level
    const links = [];
    const levels = [[], [], [], []]; // Up to 4 levels
    
    const traverse = (term, level) => {
      if (level > impactDepth || visited.has(term)) return;
      visited.set(term, level);
      
      if (level < levels.length) {
        levels[level].push(term);
      }
      
      const dependents = adjacency.get(term) || [];
      dependents.forEach(dep => {
        if (!visited.has(dep.term)) {
          links.push({ source: term, target: dep.term, level, type: dep.type });
          traverse(dep.term, level + 1);
        }
      });
    };
    
    traverse(selectedTerm, 0);
    
    const nodes = Array.from(visited.entries()).map(([term, level]) => ({
      id: term,
      level,
      category: terms.find(t => t.term === term)?.category || 'general',
    }));
    
    return { nodes, links, levels };
  }, [selectedTerm, adjacency, impactDepth, terms]);
  
  useEffect(() => {
    const updateDimensions = () => {
      if (containerRef.current) {
        const rect = containerRef.current.getBoundingClientRect();
        setDimensions({ width: Math.max(rect.width, 600), height: Math.max(rect.height, 400) });
      }
    };
    updateDimensions();
    window.addEventListener('resize', updateDimensions);
    return () => window.removeEventListener('resize', updateDimensions);
  }, []);
  
  useEffect(() => {
    if (!svgRef.current) return;
    
    const svg = d3.select(svgRef.current);
    svg.selectAll('*').remove();
    
    const { width, height } = dimensions;
    const g = svg.append('g');
    
    // Zoom
    svg.call(d3.zoom().scaleExtent([0.3, 3]).on('zoom', e => g.attr('transform', e.transform)));
    
    if (!selectedTerm || !impactData.nodes.length) {
      // Show selection prompt
      g.append('text')
        .attr('x', width / 2)
        .attr('y', height / 2)
        .attr('text-anchor', 'middle')
        .style('font-size', '14px')
        .style('fill', COLORS.general)
        .text('Select a term below to see its change impact');
      return;
    }
    
    const levelColors = [COLORS.gold, COLORS.direct, COLORS.indirect, COLORS.tertiary];
    const levelLabels = ['Selected Term', 'Direct Impact', 'Secondary Impact', 'Tertiary Impact'];
    
    // Layout: concentric circles
    const centerX = width / 2;
    const centerY = height / 2;
    const radiusStep = Math.min(width, height) / 6;
    
    // Position nodes
    impactData.levels.forEach((levelNodes, level) => {
      const radius = level * radiusStep;
      const angleStep = levelNodes.length > 0 ? (2 * Math.PI) / levelNodes.length : 0;
      
      levelNodes.forEach((term, i) => {
        const node = impactData.nodes.find(n => n.id === term);
        if (node) {
          if (level === 0) {
            node.x = centerX;
            node.y = centerY;
          } else {
            const angle = i * angleStep - Math.PI / 2;
            node.x = centerX + radius * Math.cos(angle);
            node.y = centerY + radius * Math.sin(angle);
          }
        }
      });
    });
    
    // Draw level circles
    for (let i = 1; i <= impactDepth; i++) {
      g.append('circle')
        .attr('cx', centerX)
        .attr('cy', centerY)
        .attr('r', i * radiusStep)
        .attr('fill', 'none')
        .attr('stroke', levelColors[i] || COLORS.general)
        .attr('stroke-width', 1)
        .attr('stroke-dasharray', '4,4')
        .attr('opacity', 0.3);
    }
    
    // Draw links
    const nodeMap = new Map(impactData.nodes.map(n => [n.id, n]));
    
    // Arrow marker
    svg.append('defs').append('marker')
      .attr('id', 'impact-arrow')
      .attr('viewBox', '0 -5 10 10')
      .attr('refX', 15)
      .attr('refY', 0)
      .attr('markerWidth', 6)
      .attr('markerHeight', 6)
      .attr('orient', 'auto')
      .append('path')
      .attr('d', 'M0,-5L10,0L0,5')
      .attr('fill', COLORS.general);
    
    g.append('g')
      .selectAll('line')
      .data(impactData.links)
      .join('line')
      .attr('x1', d => nodeMap.get(d.source)?.x || 0)
      .attr('y1', d => nodeMap.get(d.source)?.y || 0)
      .attr('x2', d => nodeMap.get(d.target)?.x || 0)
      .attr('y2', d => nodeMap.get(d.target)?.y || 0)
      .attr('stroke', d => levelColors[d.level + 1] || COLORS.general)
      .attr('stroke-width', 2)
      .attr('stroke-opacity', 0.6)
      .attr('marker-end', 'url(#impact-arrow)');
    
    // Draw nodes
    const nodeGroups = g.append('g')
      .selectAll('g')
      .data(impactData.nodes)
      .join('g')
      .attr('transform', d => `translate(${d.x}, ${d.y})`)
      .style('cursor', 'pointer');
    
    nodeGroups.append('circle')
      .attr('r', d => d.level === 0 ? 20 : 14 - d.level * 2)
      .attr('fill', d => d.level === 0 ? COLORS.gold : levelColors[d.level] || COLORS.general)
      .attr('stroke', COLORS.white)
      .attr('stroke-width', 2)
      .on('mouseenter', function(event, d) {
        setTooltip({
          show: true,
          x: d.x,
          y: d.y - 30,
          content: `${d.id} (${levelLabels[d.level] || 'Impact Level ' + d.level})`
        });
      })
      .on('mouseleave', () => setTooltip({ show: false, x: 0, y: 0, content: '' }));
    
    nodeGroups.append('text')
      .attr('dy', d => (d.level === 0 ? 20 : 14 - d.level * 2) + 14)
      .attr('text-anchor', 'middle')
      .style('font-size', d => d.level === 0 ? '11px' : '9px')
      .style('font-weight', d => d.level === 0 ? '600' : '400')
      .style('fill', COLORS.navy)
      .text(d => d.id.length > 12 ? d.id.slice(0, 10) + '…' : d.id);
    
    // Legend
    const legend = svg.append('g').attr('transform', 'translate(20, 20)');
    
    legend.append('text')
      .attr('y', 0)
      .style('font-size', '11px')
      .style('font-weight', '600')
      .style('fill', COLORS.navy)
      .text('Impact Levels');
    
    levelLabels.slice(0, impactDepth + 1).forEach((label, i) => {
      const row = legend.append('g').attr('transform', `translate(0, ${i * 18 + 15})`);
      row.append('circle').attr('r', 6).attr('fill', levelColors[i]);
      row.append('text').attr('x', 14).attr('y', 4).style('font-size', '10px').style('fill', COLORS.navy).text(label);
    });
    
  }, [selectedTerm, impactData, dimensions, impactDepth]);
  
  return (
    <div>
      <ControlPanel>
        <ControlGroup label="Select Term">
          <Select
            value={selectedTerm || ''}
            onChange={setSelectedTerm}
            options={[
              { value: '', label: 'Choose a term...' },
              ...terms.map(t => ({ value: t.term, label: t.term }))
            ]}
          />
        </ControlGroup>
        <ControlGroup label="Impact Depth">
          <Select
            value={impactDepth}
            onChange={v => setImpactDepth(parseInt(v))}
            options={[
              { value: 1, label: '1 Level' },
              { value: 2, label: '2 Levels' },
              { value: 3, label: '3 Levels' },
            ]}
          />
        </ControlGroup>
        {selectedTerm && (
          <ControlGroup label="Stats">
            <div style={{ 
              padding: '6px 12px', 
              background: COLORS.white, 
              borderRadius: '4px',
              fontSize: '12px',
              color: COLORS.navy,
            }}>
              <strong>{impactData.nodes.length - 1}</strong> terms affected
            </div>
          </ControlGroup>
        )}
      </ControlPanel>
      
      <div style={{ 
        fontSize: '11px', 
        color: COLORS.general, 
        marginBottom: '8px',
        padding: '8px 12px',
        background: COLORS.cream,
        borderRadius: '4px',
      }}>
        💡 This visualization shows which terms would be affected if you change the selected term's definition. 
        Inner rings = direct impact, outer rings = cascading effects.
      </div>
      
      <div ref={containerRef} style={{ position: 'relative', height: '450px' }}>
        <svg ref={svgRef} width={dimensions.width} height={dimensions.height} style={{ background: COLORS.cream }} />
        <Tooltip show={tooltip.show} x={tooltip.x} y={tooltip.y}>
          {tooltip.content}
        </Tooltip>
      </div>
    </div>
  );
}

// ============================================================================
// 4. CONDITION FLOW NETWORK
// ============================================================================

export function ConditionFlowNetwork({ conditions, conditionDependencies }) {
  const svgRef = useRef(null);
  const containerRef = useRef(null);
  const [dimensions, setDimensions] = useState({ width: 800, height: 500 });
  const [selectedCondition, setSelectedCondition] = useState(null);
  const [tooltip, setTooltip] = useState({ show: false, x: 0, y: 0, content: '', status: '' });
  const [filterStatus, setFilterStatus] = useState('all');
  
  // Process conditions into nodes and edges
  const { nodes, links } = useMemo(() => {
    let filteredConditions = conditions;
    if (filterStatus !== 'all') {
      filteredConditions = conditions.filter(c => c.status === filterStatus);
    }
    
    const nodeMap = new Map();
    filteredConditions.forEach(c => {
      nodeMap.set(c.id, {
        id: c.id,
        title: c.title,
        section: c.section_reference,
        status: c.status,
        category: c.category,
        description: c.description,
      });
    });
    
    // Use provided dependencies or generate logical ones
    const deps = conditionDependencies || generateLogicalDependencies(filteredConditions);
    const processedLinks = deps.filter(d => nodeMap.has(d.source) && nodeMap.has(d.target));
    
    return {
      nodes: Array.from(nodeMap.values()),
      links: processedLinks,
    };
  }, [conditions, conditionDependencies, filterStatus]);
  
  // Generate logical dependencies based on section order
  function generateLogicalDependencies(conds) {
    const deps = [];
    const sorted = [...conds].sort((a, b) => a.section_reference.localeCompare(b.section_reference));
    
    // Simple chain: each condition depends on previous
    for (let i = 1; i < sorted.length; i++) {
      // Some logical dependencies
      if (sorted[i].category === 'Security Documents' && sorted[i-1].category === 'Credit Agreement') {
        deps.push({ source: sorted[i-1].id, target: sorted[i].id, type: 'requires' });
      } else if (sorted[i].category === 'UCC Filings' && sorted[i-1].category === 'Security Documents') {
        deps.push({ source: sorted[i-1].id, target: sorted[i].id, type: 'requires' });
      } else if (sorted[i].category === 'Certificates' && sorted[i-1].category === 'Corporate Documents') {
        deps.push({ source: sorted[i-1].id, target: sorted[i].id, type: 'concurrent' });
      }
    }
    
    // Add some concurrent conditions
    const corporateDocs = sorted.filter(c => c.category === 'Corporate Documents');
    if (corporateDocs.length > 1) {
      deps.push({ source: corporateDocs[0].id, target: corporateDocs[1]?.id, type: 'concurrent' });
    }
    
    return deps;
  }
  
  const statuses = useMemo(() => {
    const s = new Set(conditions.map(c => c.status));
    return ['all', ...Array.from(s)];
  }, [conditions]);
  
  useEffect(() => {
    const updateDimensions = () => {
      if (containerRef.current) {
        const rect = containerRef.current.getBoundingClientRect();
        setDimensions({ width: Math.max(rect.width, 600), height: Math.max(rect.height, 400) });
      }
    };
    updateDimensions();
    window.addEventListener('resize', updateDimensions);
    return () => window.removeEventListener('resize', updateDimensions);
  }, []);
  
  useEffect(() => {
    if (!svgRef.current || !nodes.length) return;
    
    const { width, height } = dimensions;
    const svg = d3.select(svgRef.current);
    svg.selectAll('*').remove();
    
    const g = svg.append('g');
    svg.call(d3.zoom().scaleExtent([0.3, 3]).on('zoom', e => g.attr('transform', e.transform)));
    
    const defs = svg.append('defs');
    
    // Arrow markers
    ['requires', 'concurrent', 'precedes'].forEach(type => {
      defs.append('marker')
        .attr('id', `cond-arrow-${type}`)
        .attr('viewBox', '0 -5 10 10')
        .attr('refX', 25)
        .attr('refY', 0)
        .attr('markerWidth', 6)
        .attr('markerHeight', 6)
        .attr('orient', 'auto')
        .append('path')
        .attr('d', 'M0,-5L10,0L0,5')
        .attr('fill', EDGE_TYPE_COLORS[type] || COLORS.general);
    });
    
    // Simulation
    const simulation = d3.forceSimulation(nodes)
      .force('link', d3.forceLink(links).id(d => d.id).distance(150).strength(0.3))
      .force('charge', d3.forceManyBody().strength(-400))
      .force('center', d3.forceCenter(width / 2, height / 2))
      .force('collision', d3.forceCollide().radius(60));
    
    // Links
    const link = g.append('g')
      .selectAll('path')
      .data(links)
      .join('path')
      .attr('fill', 'none')
      .attr('stroke', d => EDGE_TYPE_COLORS[d.type] || COLORS.general)
      .attr('stroke-width', 2)
      .attr('stroke-opacity', 0.6)
      .attr('stroke-dasharray', d => d.type === 'concurrent' ? '5,5' : 'none')
      .attr('marker-end', d => `url(#cond-arrow-${d.type})`);
    
    // Nodes
    const node = g.append('g')
      .selectAll('g')
      .data(nodes)
      .join('g')
      .style('cursor', 'pointer')
      .call(d3.drag()
        .on('start', (event, d) => { if (!event.active) simulation.alphaTarget(0.3).restart(); d.fx = d.x; d.fy = d.y; })
        .on('drag', (event, d) => { d.fx = event.x; d.fy = event.y; })
        .on('end', (event, d) => { if (!event.active) simulation.alphaTarget(0); d.fx = null; d.fy = null; }));
    
    // Node rectangles
    node.append('rect')
      .attr('x', -50)
      .attr('y', -20)
      .attr('width', 100)
      .attr('height', 40)
      .attr('rx', 6)
      .attr('fill', d => STATUS_COLORS[d.status] || COLORS.pending)
      .attr('stroke', d => selectedCondition === d.id ? COLORS.gold : COLORS.white)
      .attr('stroke-width', d => selectedCondition === d.id ? 3 : 2)
      .on('click', (event, d) => setSelectedCondition(selectedCondition === d.id ? null : d.id))
      .on('mouseenter', function(event, d) {
        d3.select(this).attr('stroke', COLORS.gold).attr('stroke-width', 3);
        setTooltip({
          show: true,
          x: event.offsetX,
          y: event.offsetY - 50,
          content: d.title,
          status: d.status
        });
      })
      .on('mouseleave', function(event, d) {
        d3.select(this).attr('stroke', selectedCondition === d.id ? COLORS.gold : COLORS.white).attr('stroke-width', selectedCondition === d.id ? 3 : 2);
        setTooltip({ show: false, x: 0, y: 0, content: '', status: '' });
      });
    
    // Node labels
    node.append('text')
      .attr('text-anchor', 'middle')
      .attr('dy', -4)
      .style('font-size', '9px')
      .style('font-weight', '600')
      .style('fill', COLORS.white)
      .style('pointer-events', 'none')
      .text(d => d.section);
    
    node.append('text')
      .attr('text-anchor', 'middle')
      .attr('dy', 10)
      .style('font-size', '8px')
      .style('fill', COLORS.white)
      .style('pointer-events', 'none')
      .text(d => d.title.length > 14 ? d.title.slice(0, 12) + '…' : d.title);
    
    simulation.on('tick', () => {
      link.attr('d', d => {
        const dx = d.target.x - d.source.x;
        const dy = d.target.y - d.source.y;
        return `M${d.source.x},${d.source.y}L${d.target.x},${d.target.y}`;
      });
      node.attr('transform', d => `translate(${d.x}, ${d.y})`);
    });
    
    return () => simulation.stop();
  }, [nodes, links, dimensions, selectedCondition]);
  
  return (
    <div>
      <ControlPanel>
        <ControlGroup label="Filter Status">
          <Select
            value={filterStatus}
            onChange={setFilterStatus}
            options={statuses.map(s => ({ value: s, label: s === 'all' ? 'All Statuses' : s.replace(/_/g, ' ') }))}
          />
        </ControlGroup>
        <ControlGroup label="Legend">
          <div style={{ display: 'flex', gap: '12px', fontSize: '10px' }}>
            <span style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
              <span style={{ width: '20px', height: '3px', background: EDGE_TYPE_COLORS.requires }} />
              requires
            </span>
            <span style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
              <span style={{ width: '20px', height: '3px', background: EDGE_TYPE_COLORS.concurrent, borderTop: '1px dashed' }} />
              concurrent
            </span>
          </div>
        </ControlGroup>
      </ControlPanel>
      
      <div style={{ 
        fontSize: '11px', 
        color: COLORS.general, 
        marginBottom: '8px',
        padding: '8px 12px',
        background: COLORS.cream,
        borderRadius: '4px',
      }}>
        💡 Conditions are shown with their dependencies. Solid arrows = required first. Dashed = can be concurrent. 
        Node colors indicate status: <span style={{ color: COLORS.satisfied }}>■ satisfied</span>, 
        <span style={{ color: COLORS.inProgress }}> ■ in progress</span>, 
        <span style={{ color: COLORS.pending }}> ■ pending</span>
      </div>
      
      <div ref={containerRef} style={{ position: 'relative', height: '450px' }}>
        <svg ref={svgRef} width={dimensions.width} height={dimensions.height} style={{ background: COLORS.cream }} />
        <Tooltip show={tooltip.show} x={tooltip.x} y={tooltip.y}>
          <div style={{ fontWeight: '600' }}>{tooltip.content}</div>
          <div style={{ fontSize: '10px', marginTop: '4px', textTransform: 'capitalize' }}>
            Status: {tooltip.status?.replace(/_/g, ' ')}
          </div>
        </Tooltip>
      </div>
    </div>
  );
}

// ============================================================================
// 5. CHECKLIST TREE (Simplified)
// ============================================================================

export function ChecklistTree({ categories, items, expectedItems }) {
  const [expanded, setExpanded] = useState(new Set(['root', ...categories.map(c => c.id)]));
  
  const toggleExpand = (id) => {
    const newExpanded = new Set(expanded);
    if (newExpanded.has(id)) {
      newExpanded.delete(id);
    } else {
      newExpanded.add(id);
    }
    setExpanded(newExpanded);
  };
  
  // Group items by category
  const groupedItems = useMemo(() => {
    const groups = new Map();
    categories.forEach(c => groups.set(c.id, []));
    items.forEach(item => {
      const cat = groups.get(item.category_id);
      if (cat) cat.push(item);
    });
    expectedItems.forEach(exp => {
      const cat = groups.get(exp.category_id);
      if (cat) cat.push({ ...exp, isExpected: true, status: 'expected' });
    });
    return groups;
  }, [categories, items, expectedItems]);
  
  return (
    <div style={{ maxHeight: '500px', overflowY: 'auto' }}>
      {categories.map(category => {
        const categoryItems = groupedItems.get(category.id) || [];
        const isExpanded = expanded.has(category.id);
        const satisfiedCount = categoryItems.filter(i => i.status === 'satisfied' || i.status === 'executed' || i.status === 'final').length;
        
        return (
          <div key={category.id} style={{ marginBottom: '8px' }}>
            <div
              onClick={() => toggleExpand(category.id)}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                padding: '10px 12px',
                background: COLORS.navy,
                color: COLORS.white,
                borderRadius: '6px',
                cursor: 'pointer',
                fontSize: '13px',
                fontWeight: '600',
              }}
            >
              <span style={{ transform: isExpanded ? 'rotate(90deg)' : 'none', transition: 'transform 0.2s' }}>▶</span>
              <span style={{ flex: 1 }}>{category.section} {category.title}</span>
              <span style={{ 
                background: satisfiedCount === categoryItems.length ? COLORS.satisfied : COLORS.goldLight,
                color: satisfiedCount === categoryItems.length ? COLORS.white : COLORS.navy,
                padding: '2px 8px',
                borderRadius: '10px',
                fontSize: '11px',
              }}>
                {satisfiedCount}/{categoryItems.length}
              </span>
            </div>
            
            {isExpanded && (
              <div style={{ marginTop: '4px', marginLeft: '20px' }}>
                {categoryItems.map((item, i) => (
                  <div
                    key={item.id || i}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '8px',
                      padding: '8px 12px',
                      background: COLORS.white,
                      borderRadius: '4px',
                      marginTop: '4px',
                      border: item.isExpected ? `2px dashed ${COLORS.expected}` : `1px solid ${COLORS.goldLight}`,
                    }}
                  >
                    <span style={{
                      width: '8px',
                      height: '8px',
                      borderRadius: '50%',
                      background: STATUS_COLORS[item.status] || COLORS.pending,
                    }} />
                    <span style={{ flex: 1, fontSize: '12px', color: COLORS.navy }}>
                      {item.title}
                    </span>
                    {item.isExpected && (
                      <span style={{
                        fontSize: '9px',
                        background: COLORS.expected,
                        color: COLORS.white,
                        padding: '2px 6px',
                        borderRadius: '3px',
                        fontWeight: '600',
                      }}>
                        EXPECTED
                      </span>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

// ============================================================================
// MAIN VISUALIZATION DASHBOARD
// ============================================================================

export default function LegalVisualizationDashboard({ data }) {
  const [activeTab, setActiveTab] = useState('network');
  
  const tabs = [
    { id: 'network', label: 'Term Connections', icon: '◎', description: 'Interactive graph of term relationships' },
    { id: 'impact', label: 'Impact Analysis', icon: '◉', description: 'See cascading effects of definition changes' },
    { id: 'heatmap', label: 'Term Usage', icon: '▤', description: 'Document × Term usage matrix' },
    { id: 'conditions', label: 'Condition Flow', icon: '⇢', description: 'Dependencies between closing conditions' },
    { id: 'tree', label: 'Checklist', icon: '☰', description: 'Hierarchical checklist view' },
  ];
  
  return (
    <div style={{
      fontFamily: 'Source Sans 3, sans-serif',
      background: COLORS.cream,
      minHeight: '100vh',
      padding: '20px',
    }}>
      {/* Header */}
      <div style={{
        background: COLORS.navy,
        borderRadius: '8px',
        padding: '20px 24px',
        marginBottom: '20px',
        color: '#fff',
      }}>
        <h1 style={{
          fontFamily: 'Cormorant Garamond, serif',
          fontSize: '28px',
          fontWeight: '600',
          margin: 0,
        }}>
          Document Visualizations
        </h1>
        <p style={{ opacity: 0.7, marginTop: '4px', fontSize: '14px' }}>
          Interactive analysis of your credit agreement document set
        </p>
      </div>
      
      {/* Tab navigation */}
      <div style={{
        display: 'flex',
        gap: '6px',
        marginBottom: '20px',
        background: '#fff',
        padding: '6px',
        borderRadius: '8px',
        boxShadow: '0 2px 8px rgba(0,0,0,0.05)',
        flexWrap: 'wrap',
      }}>
        {tabs.map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            title={tab.description}
            style={{
              flex: '1 1 auto',
              minWidth: '120px',
              padding: '10px 14px',
              border: 'none',
              borderRadius: '6px',
              background: activeTab === tab.id ? COLORS.navy : 'transparent',
              color: activeTab === tab.id ? '#fff' : COLORS.navy,
              fontSize: '12px',
              fontWeight: '600',
              cursor: 'pointer',
              transition: 'all 0.2s',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '6px',
            }}
          >
            <span style={{ fontSize: '14px' }}>{tab.icon}</span>
            {tab.label}
          </button>
        ))}
      </div>
      
      {/* Visualization container */}
      <div style={{
        background: '#fff',
        borderRadius: '8px',
        boxShadow: '0 4px 12px rgba(0,0,0,0.08)',
        overflow: 'hidden',
      }}>
        <div style={{ padding: '20px' }}>
          {activeTab === 'heatmap' && (
            <div>
              <h2 style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: '20px', fontWeight: '600', color: COLORS.navy, marginBottom: '16px' }}>
                Term Usage Across Documents
              </h2>
              <TermUsageHeatmap terms={data.terms} documents={data.documents} usageMatrix={data.usageMatrix} />
            </div>
          )}
          
          {activeTab === 'network' && (
            <div style={{ height: '650px' }}>
              <h2 style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: '20px', fontWeight: '600', color: COLORS.navy, marginBottom: '16px' }}>
                Term Connection Network
              </h2>
              <TermConnectionNetwork terms={data.terms} edges={data.edges} />
            </div>
          )}
          
          {activeTab === 'impact' && (
            <div>
              <h2 style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: '20px', fontWeight: '600', color: COLORS.navy, marginBottom: '16px' }}>
                Definition Impact Analysis
              </h2>
              <DefinitionImpactAnalysis terms={data.terms} edges={data.edges} />
            </div>
          )}
          
          {activeTab === 'conditions' && (
            <div style={{ height: '600px' }}>
              <h2 style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: '20px', fontWeight: '600', color: COLORS.navy, marginBottom: '16px' }}>
                Condition Dependencies
              </h2>
              <ConditionFlowNetwork 
                conditions={data.conditions || []} 
                conditionDependencies={data.conditionDependencies || []} 
              />
            </div>
          )}
          
          {activeTab === 'tree' && (
            <div>
              <h2 style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: '20px', fontWeight: '600', color: COLORS.navy, marginBottom: '16px' }}>
                Closing Checklist
              </h2>
              <ChecklistTree categories={data.categories} items={data.checklistItems} expectedItems={data.expectedItems} />
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
