"""
Legal Transaction Engine - Document Generator

Generates professional Word documents for credit agreement closings.
Uses docx-js via Node.js for document creation.

Supported document types:
- Officer's Certificate
- Secretary's Certificate  
- Closing Certificate
- Solvency Certificate
- Compliance Certificate
"""

import json
import subprocess
import tempfile
from pathlib import Path
from datetime import date, datetime
from typing import Optional
import shutil

from models import (
    Transaction, Document, Party, ConditionPrecedent,
    DocumentType, PartyRole
)
from store import DataStore


class DocumentGenerator:
    """
    Generates Word documents from transaction data using templates.
    
    Uses docx-js (Node.js) for document generation, which produces
    high-quality, professional Word documents.
    """
    
    def __init__(self, data_dir: str = "./data", output_dir: str = "./output"):
        self.store = DataStore(data_dir)
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        # Get the directory where this script lives
        self.script_dir = Path(__file__).parent
        self.templates_dir = self.script_dir.parent / "templates" / "docx"
    
    def _get_party_by_role(self, txn: Transaction, role: PartyRole) -> Optional[Party]:
        """Get the first party with a specific role."""
        for party_id in txn.party_ids:
            party = self.store.get_party(party_id)
            if party and role in party.roles:
                return party
        return None
    
    def _get_borrower(self, txn: Transaction) -> Optional[Party]:
        """Get the borrower party."""
        if txn.borrower_id:
            return self.store.get_party(txn.borrower_id)
        return self._get_party_by_role(txn, PartyRole.BORROWER)
    
    def _get_agent(self, txn: Transaction) -> Optional[Party]:
        """Get the administrative agent party."""
        if txn.agent_id:
            return self.store.get_party(txn.agent_id)
        return self._get_party_by_role(txn, PartyRole.ADMINISTRATIVE_AGENT)
    
    def _format_date(self, d: Optional[date]) -> str:
        """Format a date for document display."""
        if not d:
            return "[DATE]"
        return d.strftime("%B %d, %Y")
    
    def _format_currency(self, amount: float) -> str:
        """Format currency for document display."""
        if amount >= 1_000_000_000:
            return f"${amount:,.0f} ({amount/1_000_000_000:.1f} billion dollars)"
        elif amount >= 1_000_000:
            return f"${amount:,.0f} ({amount/1_000_000:.0f} million dollars)"
        else:
            return f"${amount:,.2f}"
    
    def _run_docx_generator(self, script_content: str, output_filename: str) -> Path:
        """Run a docx-js script to generate a document."""
        output_path = self.output_dir / output_filename
        
        # Create temp directory for the script
        with tempfile.TemporaryDirectory() as tmpdir:
            script_path = Path(tmpdir) / "generate.js"
            
            # Write the script
            script_path.write_text(script_content)
            
            # Run with Node.js
            result = subprocess.run(
                ["node", str(script_path)],
                capture_output=True,
                text=True,
                cwd=tmpdir
            )
            
            if result.returncode != 0:
                raise RuntimeError(f"Document generation failed: {result.stderr}")
            
            # Move generated file to output directory
            generated_file = Path(tmpdir) / "output.docx"
            if generated_file.exists():
                shutil.move(str(generated_file), str(output_path))
            else:
                raise RuntimeError("Document was not generated")
        
        return output_path
    
    def generate_officers_certificate(
        self,
        txn_id: str,
        officer_name: str = "[OFFICER NAME]",
        officer_title: str = "Chief Financial Officer",
        include_mac_rep: bool = True,
        include_no_default: bool = True,
        include_reps_true: bool = True,
    ) -> Path:
        """
        Generate an Officer's Certificate for closing.
        
        This certificate is typically delivered by a senior officer (CFO, CEO)
        certifying various matters required by the Credit Agreement.
        """
        txn = self.store.get_transaction(txn_id)
        if not txn:
            raise ValueError(f"Transaction {txn_id} not found")
        
        borrower = self._get_borrower(txn)
        agent = self._get_agent(txn)
        
        borrower_name = borrower.name if borrower else "[BORROWER NAME]"
        borrower_short = borrower.short_name if borrower else "[BORROWER]"
        agent_name = agent.name if agent else "[ADMINISTRATIVE AGENT]"
        closing_date = self._format_date(txn.closing_date)
        facility_amount = self._format_currency(txn.facility_amount)
        
        # Build certification items
        cert_items = []
        if include_reps_true:
            cert_items.append("the representations and warranties of the Borrower and each other Credit Party contained in Article III of the Credit Agreement or any other Loan Document are true and correct in all material respects on and as of the date hereof (except to the extent such representations and warranties specifically relate to an earlier date, in which case they were true and correct in all material respects as of such earlier date)")
        
        if include_no_default:
            cert_items.append("no Default or Event of Default has occurred and is continuing or would result from the initial Credit Extension")
        
        if include_mac_rep:
            cert_items.append("since the date of the most recent financial statements delivered to the Administrative Agent, there has been no event or circumstance, either individually or in the aggregate, that has had or could reasonably be expected to have a Material Adverse Effect")
        
        cert_items.append("all conditions precedent set forth in Section 4.01 of the Credit Agreement have been satisfied or waived")
        
        # Generate the numbered certifications JavaScript
        cert_js_items = []
        for i, item in enumerate(cert_items, 1):
            cert_js_items.append(f'''
        new Paragraph({{
            numbering: {{ reference: "cert-list", level: 0 }},
            spacing: {{ after: 200 }},
            children: [new TextRun({{ text: "{item}", size: 24 }})]
        }}),''')
        
        certifications_js = "\n".join(cert_js_items)
        
        script = f'''
const {{ Document, Packer, Paragraph, TextRun, AlignmentType, Header, Footer, 
         PageNumber, LevelFormat, UnderlineType }} = require("docx");
const fs = require("fs");

const doc = new Document({{
    styles: {{
        default: {{
            document: {{
                run: {{ font: "Times New Roman", size: 24 }}
            }}
        }},
        paragraphStyles: [
            {{
                id: "Title",
                name: "Title",
                basedOn: "Normal",
                run: {{ size: 28, bold: true }},
                paragraph: {{ spacing: {{ before: 0, after: 240 }}, alignment: AlignmentType.CENTER }}
            }}
        ]
    }},
    numbering: {{
        config: [
            {{
                reference: "cert-list",
                levels: [{{
                    level: 0,
                    format: LevelFormat.DECIMAL,
                    text: "(%1)",
                    alignment: AlignmentType.LEFT,
                    style: {{ paragraph: {{ indent: {{ left: 1080, hanging: 360 }} }} }}
                }}]
            }}
        ]
    }},
    sections: [{{
        properties: {{
            page: {{
                margin: {{ top: 1440, right: 1440, bottom: 1440, left: 1440 }}
            }}
        }},
        children: [
            // Title
            new Paragraph({{
                alignment: AlignmentType.CENTER,
                spacing: {{ after: 480 }},
                children: [
                    new TextRun({{ text: "OFFICER'S CERTIFICATE", bold: true, size: 28 }})
                ]
            }}),
            
            // Reference to Credit Agreement
            new Paragraph({{
                spacing: {{ after: 240 }},
                children: [
                    new TextRun({{ text: "Reference is made to that certain Credit Agreement dated as of {closing_date} (as amended, restated, supplemented or otherwise modified from time to time, the ", size: 24 }}),
                    new TextRun({{ text: '"Credit Agreement"', bold: true, size: 24 }}),
                    new TextRun({{ text: "), among {borrower_name}, as borrower (the ", size: 24 }}),
                    new TextRun({{ text: '"Borrower"', bold: true, size: 24 }}),
                    new TextRun({{ text: "), the Lenders from time to time party thereto, and {agent_name}, as administrative agent (in such capacity, the ", size: 24 }}),
                    new TextRun({{ text: '"Administrative Agent"', bold: true, size: 24 }}),
                    new TextRun({{ text: "). Capitalized terms used but not defined herein have the meanings assigned to such terms in the Credit Agreement.", size: 24 }})
                ]
            }}),
            
            // Officer certification intro
            new Paragraph({{
                spacing: {{ after: 240 }},
                children: [
                    new TextRun({{ text: "The undersigned, {officer_name}, the {officer_title} of {borrower_short}, hereby certifies, in such capacity and not in any individual capacity, solely for the purposes of the Credit Agreement and on behalf of the Borrower, that:", size: 24 }})
                ]
            }}),
            
            // Certifications
            {certifications_js}
            
            // Signature block header
            new Paragraph({{
                spacing: {{ before: 480, after: 240 }},
                children: [
                    new TextRun({{ text: "[Signature Page Follows]", italics: true, size: 24 }})
                ],
                alignment: AlignmentType.CENTER
            }}),
            
            // Page break for signature
            new Paragraph({{ children: [] }}),
            new Paragraph({{ children: [] }}),
            new Paragraph({{ children: [] }}),
            new Paragraph({{ children: [] }}),
            
            // Signature block
            new Paragraph({{
                spacing: {{ before: 480 }},
                children: [
                    new TextRun({{ text: "IN WITNESS WHEREOF, the undersigned has executed this Officer's Certificate as of {closing_date}.", size: 24 }})
                ]
            }}),
            
            new Paragraph({{ spacing: {{ before: 720 }}, children: [] }}),
            
            new Paragraph({{
                children: [
                    new TextRun({{ text: "{borrower_name.upper()}", bold: true, size: 24 }})
                ]
            }}),
            
            new Paragraph({{ spacing: {{ before: 480 }}, children: [] }}),
            
            new Paragraph({{
                children: [
                    new TextRun({{ text: "By: ", size: 24 }}),
                    new TextRun({{ text: "_".repeat(40), size: 24 }})
                ]
            }}),
            
            new Paragraph({{
                indent: {{ left: 720 }},
                children: [
                    new TextRun({{ text: "Name: {officer_name}", size: 24 }})
                ]
            }}),
            
            new Paragraph({{
                indent: {{ left: 720 }},
                children: [
                    new TextRun({{ text: "Title: {officer_title}", size: 24 }})
                ]
            }})
        ]
    }}]
}});

Packer.toBuffer(doc).then(buffer => {{
    fs.writeFileSync("output.docx", buffer);
}});
'''
        
        filename = f"Officers_Certificate_{borrower_short.replace(' ', '_')}_{txn.closing_date or 'DRAFT'}.docx"
        return self._run_docx_generator(script, filename)
    
    def generate_secretary_certificate(
        self,
        txn_id: str,
        secretary_name: str = "[SECRETARY NAME]",
        include_resolutions: bool = True,
        include_incumbency: bool = True,
        include_charter_docs: bool = True,
    ) -> Path:
        """
        Generate a Secretary's Certificate for closing.
        
        This certificate is delivered by the corporate secretary certifying
        organizational documents, resolutions, and officer incumbency.
        """
        txn = self.store.get_transaction(txn_id)
        if not txn:
            raise ValueError(f"Transaction {txn_id} not found")
        
        borrower = self._get_borrower(txn)
        agent = self._get_agent(txn)
        
        borrower_name = borrower.name if borrower else "[BORROWER NAME]"
        borrower_short = borrower.short_name if borrower else "[BORROWER]"
        jurisdiction = borrower.jurisdiction if borrower else "[STATE]"
        entity_type = borrower.entity_type if borrower else "corporation"
        agent_name = agent.name if agent else "[ADMINISTRATIVE AGENT]"
        closing_date = self._format_date(txn.closing_date)
        
        # Build certification items
        cert_items = []
        
        if include_charter_docs:
            cert_items.append(f"Attached hereto as Exhibit A is a true, correct and complete copy of the Certificate of Incorporation of the Company, as filed with the Secretary of State of the State of {jurisdiction}, and such Certificate of Incorporation has not been amended, modified, rescinded or revoked since the date of filing and is in full force and effect")
            cert_items.append("Attached hereto as Exhibit B is a true, correct and complete copy of the Bylaws of the Company as currently in effect, and such Bylaws have not been amended, modified, rescinded or revoked and are in full force and effect")
        
        if include_resolutions:
            cert_items.append("Attached hereto as Exhibit C is a true, correct and complete copy of the resolutions duly adopted by the Board of Directors of the Company authorizing the execution, delivery and performance of the Credit Agreement and the other Loan Documents to which the Company is a party, and such resolutions have not been amended, modified, rescinded or revoked and are in full force and effect")
        
        if include_incumbency:
            cert_items.append("Each of the persons listed on Schedule 1 hereto is a duly elected or appointed, qualified and acting officer of the Company, holding the office set forth opposite such person's name, and the signature appearing opposite such person's name is such person's genuine signature")
        
        cert_items.append("The Company is duly organized, validly existing and in good standing under the laws of the State of " + jurisdiction)
        
        # Generate the numbered certifications JavaScript
        cert_js_items = []
        for i, item in enumerate(cert_items, 1):
            # Escape quotes for JavaScript
            escaped_item = item.replace('"', '\\"')
            cert_js_items.append(f'''
        new Paragraph({{
            numbering: {{ reference: "cert-list", level: 0 }},
            spacing: {{ after: 200 }},
            children: [new TextRun({{ text: "{escaped_item}", size: 24 }})]
        }}),''')
        
        certifications_js = "\n".join(cert_js_items)
        
        script = f'''
const {{ Document, Packer, Paragraph, TextRun, AlignmentType, LevelFormat }} = require("docx");
const fs = require("fs");

const doc = new Document({{
    styles: {{
        default: {{
            document: {{
                run: {{ font: "Times New Roman", size: 24 }}
            }}
        }}
    }},
    numbering: {{
        config: [
            {{
                reference: "cert-list",
                levels: [{{
                    level: 0,
                    format: LevelFormat.DECIMAL,
                    text: "%1.",
                    alignment: AlignmentType.LEFT,
                    style: {{ paragraph: {{ indent: {{ left: 1080, hanging: 360 }} }} }}
                }}]
            }}
        ]
    }},
    sections: [{{
        properties: {{
            page: {{
                margin: {{ top: 1440, right: 1440, bottom: 1440, left: 1440 }}
            }}
        }},
        children: [
            // Title
            new Paragraph({{
                alignment: AlignmentType.CENTER,
                spacing: {{ after: 480 }},
                children: [
                    new TextRun({{ text: "SECRETARY'S CERTIFICATE", bold: true, size: 28 }})
                ]
            }}),
            
            // Company intro
            new Paragraph({{
                alignment: AlignmentType.CENTER,
                spacing: {{ after: 240 }},
                children: [
                    new TextRun({{ text: "of", size: 24 }})
                ]
            }}),
            
            new Paragraph({{
                alignment: AlignmentType.CENTER,
                spacing: {{ after: 480 }},
                children: [
                    new TextRun({{ text: "{borrower_name.upper()}", bold: true, size: 24 }})
                ]
            }}),
            
            // Reference paragraph
            new Paragraph({{
                spacing: {{ after: 240 }},
                children: [
                    new TextRun({{ text: "Reference is made to that certain Credit Agreement dated as of {closing_date} (the ", size: 24 }}),
                    new TextRun({{ text: '"Credit Agreement"', bold: true, size: 24 }}),
                    new TextRun({{ text: "), among {borrower_name} (the ", size: 24 }}),
                    new TextRun({{ text: '"Company"', bold: true, size: 24 }}),
                    new TextRun({{ text: "), the Lenders from time to time party thereto, and {agent_name}, as administrative agent.", size: 24 }})
                ]
            }}),
            
            // Secretary certification intro
            new Paragraph({{
                spacing: {{ after: 240 }},
                children: [
                    new TextRun({{ text: "The undersigned, {secretary_name}, the Secretary of the Company, a {entity_type} organized under the laws of the State of {jurisdiction}, hereby certifies that:", size: 24 }})
                ]
            }}),
            
            // Certifications
            {certifications_js}
            
            // Witness clause
            new Paragraph({{
                spacing: {{ before: 480 }},
                children: [
                    new TextRun({{ text: "IN WITNESS WHEREOF, I have hereunto set my hand as of {closing_date}.", size: 24 }})
                ]
            }}),
            
            new Paragraph({{ spacing: {{ before: 720 }}, children: [] }}),
            
            // Signature
            new Paragraph({{
                children: [
                    new TextRun({{ text: "_".repeat(40), size: 24 }})
                ]
            }}),
            
            new Paragraph({{
                children: [
                    new TextRun({{ text: "Name: {secretary_name}", size: 24 }})
                ]
            }}),
            
            new Paragraph({{
                children: [
                    new TextRun({{ text: "Title: Secretary", size: 24 }})
                ]
            }})
        ]
    }}]
}});

Packer.toBuffer(doc).then(buffer => {{
    fs.writeFileSync("output.docx", buffer);
}});
'''
        
        filename = f"Secretary_Certificate_{borrower_short.replace(' ', '_')}_{txn.closing_date or 'DRAFT'}.docx"
        return self._run_docx_generator(script, filename)
    
    def generate_solvency_certificate(
        self,
        txn_id: str,
        officer_name: str = "[OFFICER NAME]",
        officer_title: str = "Chief Financial Officer",
    ) -> Path:
        """
        Generate a Solvency Certificate for closing.
        
        This certificate is typically delivered by the CFO certifying
        that the Borrower and its subsidiaries are solvent after giving
        effect to the transactions contemplated by the Credit Agreement.
        """
        txn = self.store.get_transaction(txn_id)
        if not txn:
            raise ValueError(f"Transaction {txn_id} not found")
        
        borrower = self._get_borrower(txn)
        agent = self._get_agent(txn)
        
        borrower_name = borrower.name if borrower else "[BORROWER NAME]"
        borrower_short = borrower.short_name if borrower else "[BORROWER]"
        agent_name = agent.name if agent else "[ADMINISTRATIVE AGENT]"
        closing_date = self._format_date(txn.closing_date)
        facility_amount = self._format_currency(txn.facility_amount)
        
        script = f'''
const {{ Document, Packer, Paragraph, TextRun, AlignmentType, LevelFormat }} = require("docx");
const fs = require("fs");

const doc = new Document({{
    styles: {{
        default: {{
            document: {{
                run: {{ font: "Times New Roman", size: 24 }}
            }}
        }}
    }},
    numbering: {{
        config: [
            {{
                reference: "solvency-list",
                levels: [{{
                    level: 0,
                    format: LevelFormat.LOWER_LETTER,
                    text: "(%1)",
                    alignment: AlignmentType.LEFT,
                    style: {{ paragraph: {{ indent: {{ left: 1440, hanging: 360 }} }} }}
                }}]
            }}
        ]
    }},
    sections: [{{
        properties: {{
            page: {{
                margin: {{ top: 1440, right: 1440, bottom: 1440, left: 1440 }}
            }}
        }},
        children: [
            // Title
            new Paragraph({{
                alignment: AlignmentType.CENTER,
                spacing: {{ after: 480 }},
                children: [
                    new TextRun({{ text: "SOLVENCY CERTIFICATE", bold: true, size: 28 }})
                ]
            }}),
            
            // Date
            new Paragraph({{
                alignment: AlignmentType.CENTER,
                spacing: {{ after: 480 }},
                children: [
                    new TextRun({{ text: "{closing_date}", size: 24 }})
                ]
            }}),
            
            // Reference paragraph
            new Paragraph({{
                spacing: {{ after: 240 }},
                children: [
                    new TextRun({{ text: "Reference is made to that certain Credit Agreement dated as of {closing_date} (the ", size: 24 }}),
                    new TextRun({{ text: '"Credit Agreement"', bold: true, size: 24 }}),
                    new TextRun({{ text: "), among {borrower_name} (the ", size: 24 }}),
                    new TextRun({{ text: '"Borrower"', bold: true, size: 24 }}),
                    new TextRun({{ text: "), the Lenders from time to time party thereto, and {agent_name}, as administrative agent. Capitalized terms used but not defined herein have the meanings assigned to such terms in the Credit Agreement.", size: 24 }})
                ]
            }}),
            
            // Intro paragraph
            new Paragraph({{
                spacing: {{ after: 240 }},
                children: [
                    new TextRun({{ text: "The undersigned, {officer_name}, the {officer_title} of the Borrower, in such capacity and not in an individual capacity, hereby certifies as follows:", size: 24 }})
                ]
            }}),
            
            // Certification 1 - Review
            new Paragraph({{
                spacing: {{ after: 240 }},
                children: [
                    new TextRun({{ text: "1. I have reviewed the Credit Agreement, the other Loan Documents, and the financial statements and other documents and information delivered in connection therewith.", size: 24 }})
                ]
            }}),
            
            // Certification 2 - Solvency
            new Paragraph({{
                spacing: {{ after: 120 }},
                children: [
                    new TextRun({{ text: "2. Based on my review and analysis, as of the date hereof, after giving effect to the consummation of the transactions contemplated by the Credit Agreement and the other Loan Documents, including the making of the initial Credit Extension:", size: 24 }})
                ]
            }}),
            
            // Solvency items
            new Paragraph({{
                numbering: {{ reference: "solvency-list", level: 0 }},
                spacing: {{ after: 120 }},
                children: [new TextRun({{ text: "the fair value of the assets of the Borrower and its Subsidiaries, on a consolidated basis, exceeds, on a consolidated basis, their debts and liabilities, subordinated, contingent or otherwise;", size: 24 }})]
            }}),
            
            new Paragraph({{
                numbering: {{ reference: "solvency-list", level: 0 }},
                spacing: {{ after: 120 }},
                children: [new TextRun({{ text: "the present fair saleable value of the property of the Borrower and its Subsidiaries, on a consolidated basis, is greater than the amount that will be required to pay the probable liability, on a consolidated basis, of their debts and other liabilities, subordinated, contingent or otherwise, as such debts and other liabilities become absolute and matured;", size: 24 }})]
            }}),
            
            new Paragraph({{
                numbering: {{ reference: "solvency-list", level: 0 }},
                spacing: {{ after: 120 }},
                children: [new TextRun({{ text: "the Borrower and its Subsidiaries, on a consolidated basis, are able to pay their debts and liabilities, subordinated, contingent or otherwise, as such debts and liabilities become absolute and matured; and", size: 24 }})]
            }}),
            
            new Paragraph({{
                numbering: {{ reference: "solvency-list", level: 0 }},
                spacing: {{ after: 240 }},
                children: [new TextRun({{ text: "the Borrower and its Subsidiaries, on a consolidated basis, are not engaged in, and are not about to engage in, business for which their property would constitute unreasonably small capital.", size: 24 }})]
            }}),
            
            // Witness clause
            new Paragraph({{
                spacing: {{ before: 480 }},
                children: [
                    new TextRun({{ text: "IN WITNESS WHEREOF, I have executed this Solvency Certificate as of the date first written above.", size: 24 }})
                ]
            }}),
            
            new Paragraph({{ spacing: {{ before: 720 }}, children: [] }}),
            
            // Signature block
            new Paragraph({{
                children: [
                    new TextRun({{ text: "{borrower_name.upper()}", bold: true, size: 24 }})
                ]
            }}),
            
            new Paragraph({{ spacing: {{ before: 480 }}, children: [] }}),
            
            new Paragraph({{
                children: [
                    new TextRun({{ text: "By: ", size: 24 }}),
                    new TextRun({{ text: "_".repeat(40), size: 24 }})
                ]
            }}),
            
            new Paragraph({{
                indent: {{ left: 720 }},
                children: [
                    new TextRun({{ text: "Name: {officer_name}", size: 24 }})
                ]
            }}),
            
            new Paragraph({{
                indent: {{ left: 720 }},
                children: [
                    new TextRun({{ text: "Title: {officer_title}", size: 24 }})
                ]
            }})
        ]
    }}]
}});

Packer.toBuffer(doc).then(buffer => {{
    fs.writeFileSync("output.docx", buffer);
}});
'''
        
        filename = f"Solvency_Certificate_{borrower_short.replace(' ', '_')}_{txn.closing_date or 'DRAFT'}.docx"
        return self._run_docx_generator(script, filename)
    
    def generate_closing_checklist(self, txn_id: str) -> Path:
        """
        Generate a Closing Checklist document.
        
        Creates a professional Word document listing all closing deliverables
        with their status.
        """
        txn = self.store.get_transaction(txn_id)
        if not txn:
            raise ValueError(f"Transaction {txn_id} not found")
        
        borrower = self._get_borrower(txn)
        agent = self._get_agent(txn)
        
        borrower_name = borrower.name if borrower else "[BORROWER NAME]"
        borrower_short = borrower.short_name if borrower else "[BORROWER]"
        agent_name = agent.name if agent else "[ADMINISTRATIVE AGENT]"
        closing_date = self._format_date(txn.closing_date)
        facility_amount = self._format_currency(txn.facility_amount)
        
        # Get documents grouped by type
        documents = self.store.list_documents(txn_id)
        
        # Build document rows for the table
        doc_rows = []
        for i, doc in enumerate(documents, 1):
            status = doc.status.value if hasattr(doc.status, 'value') else str(doc.status)
            status_display = status.replace('_', ' ').title()
            
            # Escape title for JavaScript
            title = doc.title.replace('"', '\\"')
            
            doc_rows.append(f'''
        new TableRow({{
            children: [
                new TableCell({{
                    borders: cellBorders,
                    width: {{ size: 600, type: WidthType.DXA }},
                    children: [new Paragraph({{ alignment: AlignmentType.CENTER, children: [new TextRun({{ text: "{i}", size: 20 }})] }})]
                }}),
                new TableCell({{
                    borders: cellBorders,
                    width: {{ size: 5400, type: WidthType.DXA }},
                    children: [new Paragraph({{ children: [new TextRun({{ text: "{title}", size: 20 }})] }})]
                }}),
                new TableCell({{
                    borders: cellBorders,
                    width: {{ size: 1800, type: WidthType.DXA }},
                    children: [new Paragraph({{ alignment: AlignmentType.CENTER, children: [new TextRun({{ text: "{status_display}", size: 20 }})] }})]
                }}),
                new TableCell({{
                    borders: cellBorders,
                    width: {{ size: 1560, type: WidthType.DXA }},
                    children: [new Paragraph({{ children: [new TextRun({{ text: "", size: 20 }})] }})]
                }})
            ]
        }}),''')
        
        table_rows_js = "\n".join(doc_rows)
        
        script = f'''
const {{ Document, Packer, Paragraph, TextRun, AlignmentType, Table, TableRow, TableCell, 
         BorderStyle, WidthType, ShadingType }} = require("docx");
const fs = require("fs");

const tableBorder = {{ style: BorderStyle.SINGLE, size: 1, color: "000000" }};
const cellBorders = {{ top: tableBorder, bottom: tableBorder, left: tableBorder, right: tableBorder }};

const doc = new Document({{
    styles: {{
        default: {{
            document: {{
                run: {{ font: "Arial", size: 22 }}
            }}
        }}
    }},
    sections: [{{
        properties: {{
            page: {{
                margin: {{ top: 1440, right: 1080, bottom: 1440, left: 1080 }}
            }}
        }},
        children: [
            // Title
            new Paragraph({{
                alignment: AlignmentType.CENTER,
                spacing: {{ after: 240 }},
                children: [
                    new TextRun({{ text: "CLOSING CHECKLIST", bold: true, size: 32 }})
                ]
            }}),
            
            // Deal name
            new Paragraph({{
                alignment: AlignmentType.CENTER,
                spacing: {{ after: 120 }},
                children: [
                    new TextRun({{ text: "{txn.name}", bold: true, size: 24 }})
                ]
            }}),
            
            // Closing date
            new Paragraph({{
                alignment: AlignmentType.CENTER,
                spacing: {{ after: 480 }},
                children: [
                    new TextRun({{ text: "Closing Date: {closing_date}", size: 22 }})
                ]
            }}),
            
            // Table
            new Table({{
                columnWidths: [600, 5400, 1800, 1560],
                rows: [
                    // Header row
                    new TableRow({{
                        tableHeader: true,
                        children: [
                            new TableCell({{
                                borders: cellBorders,
                                width: {{ size: 600, type: WidthType.DXA }},
                                shading: {{ fill: "D9D9D9", type: ShadingType.CLEAR }},
                                children: [new Paragraph({{ alignment: AlignmentType.CENTER, children: [new TextRun({{ text: "#", bold: true, size: 20 }})] }})]
                            }}),
                            new TableCell({{
                                borders: cellBorders,
                                width: {{ size: 5400, type: WidthType.DXA }},
                                shading: {{ fill: "D9D9D9", type: ShadingType.CLEAR }},
                                children: [new Paragraph({{ children: [new TextRun({{ text: "Document", bold: true, size: 20 }})] }})]
                            }}),
                            new TableCell({{
                                borders: cellBorders,
                                width: {{ size: 1800, type: WidthType.DXA }},
                                shading: {{ fill: "D9D9D9", type: ShadingType.CLEAR }},
                                children: [new Paragraph({{ alignment: AlignmentType.CENTER, children: [new TextRun({{ text: "Status", bold: true, size: 20 }})] }})]
                            }}),
                            new TableCell({{
                                borders: cellBorders,
                                width: {{ size: 1560, type: WidthType.DXA }},
                                shading: {{ fill: "D9D9D9", type: ShadingType.CLEAR }},
                                children: [new Paragraph({{ alignment: AlignmentType.CENTER, children: [new TextRun({{ text: "Notes", bold: true, size: 20 }})] }})]
                            }})
                        ]
                    }}),
                    {table_rows_js}
                ]
            }})
        ]
    }}]
}});

Packer.toBuffer(doc).then(buffer => {{
    fs.writeFileSync("output.docx", buffer);
}});
'''
        
        filename = f"Closing_Checklist_{borrower_short.replace(' ', '_')}_{txn.closing_date or 'DRAFT'}.docx"
        return self._run_docx_generator(script, filename)


def main():
    """Test the document generator."""
    import sys
    
    if len(sys.argv) < 3:
        print("Usage: python docgen.py <transaction_id> <document_type>")
        print("Document types: officers, secretary, solvency, checklist")
        return
    
    txn_id = sys.argv[1]
    doc_type = sys.argv[2]
    
    # Determine paths
    script_dir = Path(__file__).parent
    data_dir = script_dir.parent / "data"
    output_dir = script_dir.parent / "output"
    
    generator = DocumentGenerator(str(data_dir), str(output_dir))
    
    try:
        if doc_type == "officers":
            path = generator.generate_officers_certificate(txn_id)
        elif doc_type == "secretary":
            path = generator.generate_secretary_certificate(txn_id)
        elif doc_type == "solvency":
            path = generator.generate_solvency_certificate(txn_id)
        elif doc_type == "checklist":
            path = generator.generate_closing_checklist(txn_id)
        else:
            print(f"Unknown document type: {doc_type}")
            return
        
        print(f"Generated: {path}")
    except Exception as e:
        print(f"Error: {e}")


if __name__ == "__main__":
    main()
