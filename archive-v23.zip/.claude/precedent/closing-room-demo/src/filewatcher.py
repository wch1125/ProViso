"""
Legal Transaction Engine - File Watcher & Smart Checklist

This module monitors actual document files on disk and generates
checklists based on what's present vs. what's expected.

Key features:
- Scan a folder for document files (.docx, .pdf, .doc)
- Match files to expected documents using fuzzy matching
- Track file metadata (size, modified date, checksum)
- Generate checklists showing present/missing/outdated files
- Sync file presence back to document status
- Watch for changes (new files, modifications, deletions)
"""

import os
import re
import hashlib
from pathlib import Path
from datetime import datetime
from dataclasses import dataclass, field, asdict
from typing import Optional
from enum import Enum
import json


class FileStatus(Enum):
    """Status of a file on disk."""
    MISSING = "missing"           # Expected but not found
    PRESENT = "present"           # Found and matches expectations
    OUTDATED = "outdated"         # Found but older than expected
    UNEXPECTED = "unexpected"     # Found but not in expected list
    MULTIPLE = "multiple"         # Multiple files match same document
    DRAFT = "draft"              # File name indicates draft status


@dataclass
class FileInfo:
    """Information about a file on disk."""
    path: str
    filename: str
    extension: str
    size: int
    modified_at: str
    created_at: str
    checksum: str  # MD5 for quick comparison
    
    @classmethod
    def from_path(cls, filepath: Path) -> 'FileInfo':
        """Create FileInfo from a file path."""
        stat = filepath.stat()
        
        # Calculate MD5 checksum
        with open(filepath, 'rb') as f:
            checksum = hashlib.md5(f.read()).hexdigest()
        
        return cls(
            path=str(filepath),
            filename=filepath.name,
            extension=filepath.suffix.lower(),
            size=stat.st_size,
            modified_at=datetime.fromtimestamp(stat.st_mtime).isoformat(),
            created_at=datetime.fromtimestamp(stat.st_ctime).isoformat(),
            checksum=checksum,
        )


@dataclass
class ChecklistMatch:
    """A match between an expected document and a file on disk."""
    document_id: str
    document_title: str
    document_type: str
    document_status: str
    expected: bool = True
    
    # File info (if found)
    file_found: bool = False
    file_path: Optional[str] = None
    file_size: Optional[int] = None
    file_modified: Optional[str] = None
    file_checksum: Optional[str] = None
    
    # Match quality
    match_confidence: float = 0.0  # 0.0 to 1.0
    match_method: str = ""  # How we matched (exact, fuzzy, pattern)
    
    # Status
    file_status: FileStatus = FileStatus.MISSING
    notes: str = ""


@dataclass 
class ChecklistSummary:
    """Summary of checklist status."""
    transaction_id: str
    transaction_name: str
    scan_folder: str
    scan_time: str
    
    total_expected: int = 0
    total_found: int = 0
    total_missing: int = 0
    total_unexpected: int = 0
    
    ready_percentage: float = 0.0
    
    items: list = field(default_factory=list)
    unexpected_files: list = field(default_factory=list)


class FilePatternMatcher:
    """
    Matches files to expected documents using various strategies.
    """
    
    # Common document type patterns
    DOCUMENT_PATTERNS = {
        'credit_agreement': [
            r'credit.?agreement',
            r'loan.?agreement',
            r'facility.?agreement',
        ],
        'officers_certificate': [
            r'officer.*cert',
            r'cfo.*cert',
            r'closing.*cert',
        ],
        'secretary_certificate': [
            r'secretary.*cert',
            r'incumbency',
        ],
        'good_standing': [
            r'good.?standing',
            r'certificate.*existence',
            r'status.*cert',
        ],
        'resolutions': [
            r'resolution',
            r'board.*consent',
            r'unanimous.*consent',
        ],
        'security_agreement': [
            r'security.?agreement',
            r'collateral.?agreement',
        ],
        'pledge_agreement': [
            r'pledge',
            r'stock.?pledge',
        ],
        'guaranty': [
            r'guarant[y|ee]',
            r'subsidiary.*guarant',
        ],
        'ucc_financing_statement': [
            r'ucc',
            r'financing.?statement',
            r'ucc.?1',
        ],
        'legal_opinion': [
            r'legal.?opinion',
            r'opinion.*letter',
            r'counsel.*opinion',
        ],
        'solvency_certificate': [
            r'solvency',
        ],
        'financial_statements': [
            r'financial.*statement',
            r'balance.?sheet',
            r'income.?statement',
            r'financials',
        ],
        'fee_letter': [
            r'fee.?letter',
            r'engagement.?letter',
        ],
        'closing_checklist': [
            r'checklist',
            r'closing.*list',
        ],
    }
    
    # Draft indicators
    DRAFT_PATTERNS = [
        r'draft',
        r'v\d+',
        r'_v\d+',
        r'\(\d+\)',
        r'working',
        r'wip',
        r'preliminary',
    ]
    
    def __init__(self):
        # Compile patterns for efficiency
        self.compiled_patterns = {}
        for doc_type, patterns in self.DOCUMENT_PATTERNS.items():
            self.compiled_patterns[doc_type] = [
                re.compile(p, re.IGNORECASE) for p in patterns
            ]
        
        self.draft_patterns = [re.compile(p, re.IGNORECASE) for p in self.DRAFT_PATTERNS]
    
    def match_file_to_document(
        self,
        filename: str,
        expected_documents: list[dict]
    ) -> tuple[Optional[dict], float, str]:
        """
        Try to match a filename to an expected document.
        
        Args:
            filename: The filename to match
            expected_documents: List of expected document dicts
        
        Returns:
            (matched_document, confidence, method) or (None, 0, "")
        """
        filename_lower = filename.lower()
        filename_base = Path(filename).stem.lower()
        
        best_match = None
        best_confidence = 0.0
        best_method = ""
        
        for doc in expected_documents:
            doc_title = doc.get('title', '').lower()
            doc_type = doc.get('document_type', '').lower()
            
            # Method 1: Exact title match
            if doc_title and doc_title in filename_lower:
                confidence = 0.95
                if confidence > best_confidence:
                    best_match = doc
                    best_confidence = confidence
                    best_method = "exact_title"
                continue
            
            # Method 2: Document type pattern match
            if doc_type in self.compiled_patterns:
                for pattern in self.compiled_patterns[doc_type]:
                    if pattern.search(filename_base):
                        confidence = 0.8
                        if confidence > best_confidence:
                            best_match = doc
                            best_confidence = confidence
                            best_method = f"pattern_{doc_type}"
                        break
            
            # Method 3: Fuzzy word match
            doc_words = set(re.findall(r'\w+', doc_title))
            file_words = set(re.findall(r'\w+', filename_base))
            
            if doc_words and file_words:
                # Remove common words
                common_ignore = {'the', 'of', 'and', 'a', 'an', 'to', 'for', 'in', 'on'}
                doc_words -= common_ignore
                file_words -= common_ignore
                
                if doc_words:
                    overlap = len(doc_words & file_words) / len(doc_words)
                    if overlap > 0.5 and overlap > best_confidence:
                        best_match = doc
                        best_confidence = overlap * 0.7  # Scale down fuzzy matches
                        best_method = "fuzzy_words"
        
        return best_match, best_confidence, best_method
    
    def is_draft(self, filename: str) -> bool:
        """Check if filename indicates a draft."""
        for pattern in self.draft_patterns:
            if pattern.search(filename):
                return True
        return False
    
    def extract_version(self, filename: str) -> Optional[int]:
        """Try to extract version number from filename."""
        # Look for v1, v2, _v1, (1), etc.
        match = re.search(r'[_\s\(]?v?(\d+)[_\s\)]?', filename, re.IGNORECASE)
        if match:
            return int(match.group(1))
        return None


class FolderScanner:
    """
    Scans folders for document files and tracks their status.
    """
    
    SUPPORTED_EXTENSIONS = {'.docx', '.doc', '.pdf', '.xlsx', '.xls', '.pptx'}
    
    def __init__(self, base_folder: str):
        self.base_folder = Path(base_folder)
        self.matcher = FilePatternMatcher()
        self.file_cache: dict[str, FileInfo] = {}
        self.last_scan: Optional[datetime] = None
    
    def scan_folder(self, subfolder: str = "") -> list[FileInfo]:
        """
        Scan a folder for document files.
        
        Args:
            subfolder: Optional subfolder within base_folder
        
        Returns:
            List of FileInfo objects
        """
        scan_path = self.base_folder / subfolder if subfolder else self.base_folder
        
        if not scan_path.exists():
            return []
        
        files = []
        for filepath in scan_path.rglob('*'):
            if filepath.is_file() and filepath.suffix.lower() in self.SUPPORTED_EXTENSIONS:
                # Skip hidden files and temp files
                if filepath.name.startswith('.') or filepath.name.startswith('~'):
                    continue
                
                try:
                    file_info = FileInfo.from_path(filepath)
                    files.append(file_info)
                    self.file_cache[str(filepath)] = file_info
                except Exception as e:
                    print(f"Error scanning {filepath}: {e}")
        
        self.last_scan = datetime.now()
        return files
    
    def get_file_changes(self, subfolder: str = "") -> dict:
        """
        Compare current folder state to cached state.
        
        Returns:
            Dict with 'added', 'modified', 'deleted' lists
        """
        old_cache = self.file_cache.copy()
        new_files = self.scan_folder(subfolder)
        
        new_paths = {f.path for f in new_files}
        old_paths = set(old_cache.keys())
        
        added = [f for f in new_files if f.path not in old_paths]
        deleted = [old_cache[p] for p in old_paths - new_paths]
        
        modified = []
        for f in new_files:
            if f.path in old_cache:
                old_file = old_cache[f.path]
                if f.checksum != old_file.checksum:
                    modified.append(f)
        
        return {
            'added': added,
            'modified': modified,
            'deleted': deleted,
        }


class SmartChecklist:
    """
    Generates smart checklists by comparing expected documents
    with actual files on disk.
    """
    
    def __init__(self, engine, docs_folder: str):
        """
        Args:
            engine: TransactionEngine instance
            docs_folder: Base folder where documents are stored
        """
        self.engine = engine
        self.docs_folder = Path(docs_folder)
        self.scanner = FolderScanner(docs_folder)
        self.matcher = FilePatternMatcher()
    
    def generate_checklist(
        self,
        txn_id: str,
        scan_subfolder: str = ""
    ) -> ChecklistSummary:
        """
        Generate a checklist comparing expected docs to actual files.
        
        Args:
            txn_id: Transaction ID
            scan_subfolder: Optional subfolder to scan (e.g., transaction name)
        
        Returns:
            ChecklistSummary with all matches
        """
        # Get transaction
        txn = self.engine.store.get_transaction(txn_id)
        if not txn:
            raise ValueError(f"Transaction {txn_id} not found")
        
        # Get expected documents
        documents = self.engine.store.list_documents(txn_id)
        expected = [
            {
                'id': d.id,
                'title': d.title,
                'document_type': d.document_type.value,
                'status': d.status.value,
            }
            for d in documents
        ]
        
        # Scan folder
        scan_path = scan_subfolder or self._get_transaction_folder(txn)
        files = self.scanner.scan_folder(scan_path)
        
        # Match files to documents
        items = []
        matched_files = set()
        
        for doc in expected:
            match = ChecklistMatch(
                document_id=doc['id'],
                document_title=doc['title'],
                document_type=doc['document_type'],
                document_status=doc['status'],
            )
            
            # Try to find a matching file
            for file_info in files:
                if file_info.path in matched_files:
                    continue
                
                matched_doc, confidence, method = self.matcher.match_file_to_document(
                    file_info.filename, [doc]
                )
                
                if matched_doc and confidence > 0.5:
                    match.file_found = True
                    match.file_path = file_info.path
                    match.file_size = file_info.size
                    match.file_modified = file_info.modified_at
                    match.file_checksum = file_info.checksum
                    match.match_confidence = confidence
                    match.match_method = method
                    
                    # Determine status
                    if self.matcher.is_draft(file_info.filename):
                        match.file_status = FileStatus.DRAFT
                        match.notes = "File appears to be a draft"
                    else:
                        match.file_status = FileStatus.PRESENT
                    
                    matched_files.add(file_info.path)
                    break
            
            if not match.file_found:
                match.file_status = FileStatus.MISSING
            
            items.append(match)
        
        # Find unexpected files
        unexpected = []
        for file_info in files:
            if file_info.path not in matched_files:
                unexpected.append({
                    'filename': file_info.filename,
                    'path': file_info.path,
                    'size': file_info.size,
                    'modified': file_info.modified_at,
                })
        
        # Calculate summary
        found_count = sum(1 for i in items if i.file_found)
        missing_count = sum(1 for i in items if not i.file_found)
        
        summary = ChecklistSummary(
            transaction_id=txn_id,
            transaction_name=txn.name,
            scan_folder=str(self.docs_folder / scan_path) if scan_path else str(self.docs_folder),
            scan_time=datetime.now().isoformat(),
            total_expected=len(expected),
            total_found=found_count,
            total_missing=missing_count,
            total_unexpected=len(unexpected),
            ready_percentage=(found_count / len(expected) * 100) if expected else 0,
            items=[self._serialize_match(i) for i in items],
            unexpected_files=unexpected,
        )
        
        return summary
    
    def _serialize_match(self, match: ChecklistMatch) -> dict:
        """Convert a ChecklistMatch to a dict with enum values as strings."""
        d = asdict(match)
        # Convert enum to its value
        if hasattr(match.file_status, 'value'):
            d['file_status'] = match.file_status.value
        return d
    
    def _get_transaction_folder(self, txn) -> str:
        """Generate expected folder name for a transaction."""
        # Clean transaction name for folder
        safe_name = re.sub(r'[^\w\s-]', '', txn.name)
        safe_name = re.sub(r'\s+', '_', safe_name)
        return safe_name[:50]
    
    def sync_status_from_files(self, txn_id: str, scan_subfolder: str = "") -> list[dict]:
        """
        Update document statuses based on file presence.
        
        Returns list of documents that were updated.
        """
        from models import DocumentStatus
        
        checklist = self.generate_checklist(txn_id, scan_subfolder)
        updated = []
        
        for item in checklist.items:
            if item['file_found'] and item['document_status'] == 'not_started':
                # File exists but status is not_started - update to drafting or final
                doc = self.engine.store.get_document(item['document_id'])
                if doc:
                    if item['file_status'] == 'draft':
                        doc.status = DocumentStatus.DRAFTING
                    else:
                        doc.status = DocumentStatus.FINAL
                    
                    self.engine.store.save_document(doc)
                    updated.append({
                        'document_id': item['document_id'],
                        'title': item['document_title'],
                        'old_status': item['document_status'],
                        'new_status': doc.status.value,
                    })
        
        return updated
    
    def export_checklist_to_json(self, summary: ChecklistSummary, output_path: str):
        """Export checklist to JSON file."""
        with open(output_path, 'w') as f:
            json.dump(asdict(summary), f, indent=2, default=str)
    
    def generate_checklist_report(self, summary: ChecklistSummary) -> str:
        """Generate a text report from checklist summary."""
        lines = []
        lines.append("=" * 70)
        lines.append(f" CLOSING CHECKLIST: {summary.transaction_name}")
        lines.append("=" * 70)
        lines.append(f"Scanned: {summary.scan_folder}")
        lines.append(f"Time: {summary.scan_time}")
        lines.append("")
        lines.append(f"Ready: {summary.ready_percentage:.1f}% ({summary.total_found}/{summary.total_expected} documents)")
        lines.append("")
        
        # Group by status
        found = [i for i in summary.items if i['file_found'] and i['file_status'] != 'draft']
        drafts = [i for i in summary.items if i['file_status'] == 'draft']
        missing = [i for i in summary.items if not i['file_found']]
        
        if found:
            lines.append("✓ PRESENT")
            lines.append("-" * 40)
            for item in found:
                lines.append(f"  ● {item['document_title']}")
                lines.append(f"    → {Path(item['file_path']).name}")
            lines.append("")
        
        if drafts:
            lines.append("◐ DRAFTS")
            lines.append("-" * 40)
            for item in drafts:
                lines.append(f"  ○ {item['document_title']}")
                lines.append(f"    → {Path(item['file_path']).name}")
            lines.append("")
        
        if missing:
            lines.append("✗ MISSING")
            lines.append("-" * 40)
            for item in missing:
                lines.append(f"  □ {item['document_title']}")
            lines.append("")
        
        if summary.unexpected_files:
            lines.append("? UNEXPECTED FILES")
            lines.append("-" * 40)
            for f in summary.unexpected_files:
                lines.append(f"  ? {f['filename']}")
            lines.append("")
        
        return "\n".join(lines)


class TransactionFolderManager:
    """
    Manages folder structure for transactions.
    Creates organized folder hierarchies for closing documents.
    """
    
    STANDARD_SUBFOLDERS = [
        "1_Credit_Agreement",
        "2_Corporate_Documents",
        "3_Security_Documents",
        "4_Legal_Opinions",
        "5_Certificates",
        "6_Financial_Documents",
        "7_UCC_Filings",
        "8_Miscellaneous",
        "9_Executed_Originals",
    ]
    
    def __init__(self, base_folder: str):
        self.base_folder = Path(base_folder)
        self.base_folder.mkdir(parents=True, exist_ok=True)
    
    def create_transaction_folder(self, txn_name: str, create_subfolders: bool = True) -> Path:
        """
        Create a folder structure for a transaction.
        
        Args:
            txn_name: Transaction name
            create_subfolders: Whether to create standard subfolders
        
        Returns:
            Path to the created transaction folder
        """
        # Clean name for folder
        safe_name = re.sub(r'[^\w\s-]', '', txn_name)
        safe_name = re.sub(r'\s+', '_', safe_name)[:50]
        
        txn_folder = self.base_folder / safe_name
        txn_folder.mkdir(exist_ok=True)
        
        if create_subfolders:
            for subfolder in self.STANDARD_SUBFOLDERS:
                (txn_folder / subfolder).mkdir(exist_ok=True)
        
        # Create a README
        readme = txn_folder / "README.txt"
        readme.write_text(f"""Transaction: {txn_name}
Created: {datetime.now().isoformat()}

Folder Structure:
{chr(10).join('  ' + s for s in self.STANDARD_SUBFOLDERS)}

Place documents in the appropriate folders.
The system will auto-detect and match files to the closing checklist.
""")
        
        return txn_folder
    
    def suggest_folder_for_document(self, document_type: str) -> str:
        """Suggest which subfolder a document type should go in."""
        mapping = {
            'credit_agreement': '1_Credit_Agreement',
            'amendment': '1_Credit_Agreement',
            'officers_certificate': '5_Certificates',
            'secretary_certificate': '2_Corporate_Documents',
            'good_standing': '2_Corporate_Documents',
            'resolutions': '2_Corporate_Documents',
            'charter_documents': '2_Corporate_Documents',
            'bylaws': '2_Corporate_Documents',
            'security_agreement': '3_Security_Documents',
            'pledge_agreement': '3_Security_Documents',
            'guaranty': '3_Security_Documents',
            'perfection_certificate': '3_Security_Documents',
            'ucc_financing_statement': '7_UCC_Filings',
            'legal_opinion': '4_Legal_Opinions',
            'solvency_certificate': '5_Certificates',
            'closing_certificate': '5_Certificates',
            'financial_statements': '6_Financial_Documents',
            'fee_letter': '8_Miscellaneous',
        }
        return mapping.get(document_type.lower(), '8_Miscellaneous')
