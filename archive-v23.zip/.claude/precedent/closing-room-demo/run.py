#!/usr/bin/env python3
"""
Convenience script to run the Legal Transaction Engine CLI from the project root.

Usage:
    python run.py list
    python run.py status abc123
    python run.py create "Deal Name" --amount 100000000
"""

import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / "src"))

# Import and run the CLI
from cli import main

if __name__ == "__main__":
    main()
