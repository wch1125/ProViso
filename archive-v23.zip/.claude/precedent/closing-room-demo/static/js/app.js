/**
 * [Project Name] - Main JavaScript
 * 
 * Application logic and interactivity.
 * Customize as needed.
 */

// ===== Configuration =====
const CONFIG = {
    apiBaseUrl: '/api',
    debug: true
};

// ===== Utilities =====

/**
 * Log message if debug mode is enabled
 */
function debugLog(...args) {
    if (CONFIG.debug) {
        console.log('[DEBUG]', ...args);
    }
}

/**
 * Make an API request
 */
async function apiRequest(endpoint, options = {}) {
    const url = `${CONFIG.apiBaseUrl}${endpoint}`;
    
    try {
        const response = await fetch(url, {
            headers: {
                'Content-Type': 'application/json',
                ...options.headers
            },
            ...options
        });
        
        if (!response.ok) {
            throw new Error(`API error: ${response.status}`);
        }
        
        return await response.json();
    } catch (error) {
        debugLog('API request failed:', error);
        throw error;
    }
}

/**
 * Select element(s) from DOM
 */
function $(selector) {
    return document.querySelector(selector);
}

function $$(selector) {
    return document.querySelectorAll(selector);
}

// ===== Event Handlers =====

/**
 * Handle form submission
 */
function handleFormSubmit(event) {
    event.preventDefault();
    debugLog('Form submitted');
    // Add your form handling logic here
}

// ===== Initialization =====

/**
 * Initialize the application
 */
function init() {
    debugLog('Initializing application...');
    
    // Add event listeners
    const forms = $$('form');
    forms.forEach(form => {
        form.addEventListener('submit', handleFormSubmit);
    });
    
    debugLog('Application initialized');
}

// Run initialization when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
} else {
    init();
}
