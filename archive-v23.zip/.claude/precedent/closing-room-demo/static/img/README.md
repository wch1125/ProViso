# Images

Static image assets for the project.

## Guidelines

- Optimize images for web (compress, appropriate format)
- Use descriptive file names: `hero-banner.jpg` not `img1.jpg`
- Consider using SVG for icons and logos
- Keep original/source files elsewhere

## Formats

| Format | Use For |
|--------|---------|
| SVG | Icons, logos, illustrations |
| PNG | Screenshots, images with transparency |
| JPG | Photos, complex images |
| WebP | Modern alternative to JPG/PNG |
