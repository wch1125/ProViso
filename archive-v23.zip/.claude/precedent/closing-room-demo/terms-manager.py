#!/usr/bin/env python3
"""
Legal Transaction Engine - Terms Manager v1.0
Local web interface for managing defined terms.

SETUP:
    pip install flask

USAGE:
    python terms-manager.py
    Open http://localhost:5002

Features:
- Add/edit/delete defined terms
- Visual preview of term annotations
- Import from existing JSON
- Export to demo site format
- Validate term relationships
- Git commit and push integration
"""

import os
import re
import subprocess
import json
import uuid
from datetime import datetime
from pathlib import Path

from flask import Flask, render_template_string, request, redirect, url_for, jsonify

app = Flask(__name__)
app.secret_key = 'terms-manager-2024'

# Configuration - update these paths for your setup
MANAGER_ROOT = Path(__file__).parent.resolve()
TERMS_FILE = MANAGER_ROOT / "defined_terms.json"

# Valid categories for terms
CATEGORIES = [
    ('party', 'Party', 'Borrower, Lender, Agent'),
    ('document', 'Document', 'Credit Agreement, Guaranty'),
    ('date', 'Date', 'Closing Date, Maturity Date'),
    ('facility', 'Facility', 'Revolving Loan, Commitment'),
    ('collateral', 'Collateral', 'Collateral, Pledged Stock'),
    ('covenant', 'Covenant', 'Permitted Liens, Permitted Debt'),
    ('general', 'General', 'Person, Business Day, MAE'),
]

# =============================================================================
# DATA MANAGEMENT
# =============================================================================

def load_terms():
    """Load terms from JSON file."""
    if not TERMS_FILE.exists():
        return []
    
    try:
        with open(TERMS_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        print(f"Error loading terms: {e}")
        return []


def save_terms(terms):
    """Save terms to JSON file."""
    try:
        with open(TERMS_FILE, 'w', encoding='utf-8') as f:
            json.dump(terms, f, indent=2, ensure_ascii=False)
        return True
    except Exception as e:
        print(f"Error saving terms: {e}")
        return False


def get_term_by_id(term_id):
    """Get a single term by ID."""
    terms = load_terms()
    for term in terms:
        if term.get('id') == term_id:
            return term
    return None


def generate_id():
    """Generate a unique ID for a new term."""
    return str(uuid.uuid4())


def extract_cross_references(definition, all_terms):
    """Auto-detect cross-references in a definition."""
    refs = []
    term_names = [t['term'] for t in all_terms]
    
    for term_name in term_names:
        # Look for the term (case-insensitive, word boundary)
        pattern = r'\b' + re.escape(term_name) + r's?\b'
        if re.search(pattern, definition, re.IGNORECASE):
            if term_name not in refs:
                refs.append(term_name)
    
    return refs


def validate_term(term, all_terms):
    """Validate a term and return any issues."""
    issues = []
    
    if not term.get('term'):
        issues.append("Term name is required")
    
    if not term.get('definition'):
        issues.append("Definition is required")
    
    # Check for duplicate term names
    for other in all_terms:
        if other.get('id') != term.get('id') and other.get('term', '').lower() == term.get('term', '').lower():
            issues.append(f"Duplicate term name: '{term.get('term')}'")
    
    # Check cross-references point to valid terms
    term_names = {t['term'].lower() for t in all_terms}
    for ref in term.get('cross_references', []):
        if ref.lower() not in term_names and ref.lower() != term.get('term', '').lower():
            issues.append(f"Cross-reference '{ref}' not found in terms list")
    
    return issues


# =============================================================================
# GIT OPERATIONS
# =============================================================================

def git_status():
    """Check if there are uncommitted changes."""
    try:
        result = subprocess.run(
            ['git', 'status', '--porcelain'],
            cwd=MANAGER_ROOT,
            capture_output=True,
            text=True
        )
        return len(result.stdout.strip()) > 0
    except:
        return False


def git_commit_and_push(message):
    """Commit all changes and push to remote."""
    try:
        subprocess.run(['git', 'add', '.'], cwd=MANAGER_ROOT, check=True)
        subprocess.run(['git', 'commit', '-m', message], cwd=MANAGER_ROOT, check=True)
        subprocess.run(['git', 'push'], cwd=MANAGER_ROOT, check=True)
        return True, "Changes committed and pushed successfully!"
    except subprocess.CalledProcessError as e:
        return False, f"Git error: {e}"
    except Exception as e:
        return False, f"Error: {e}"


# =============================================================================
# HTML TEMPLATE
# =============================================================================

HTML_TEMPLATE = '''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Terms Manager — Legal Transaction Engine</title>
    <link href="https://fonts.googleapis.com/css2?family=EB+Garamond:wght@400;500;600&family=DM+Sans:wght@400;500&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg: #FAFAF8;
            --paper: #FFFFFF;
            --ink: #151515;
            --ink-light: #4A4A48;
            --muted: #8A8A82;
            --line: #E8E8E4;
            --gold: #B8860B;
            --gold-light: #D4A84B;
            --gold-muted: rgba(184, 134, 11, 0.15);
            --navy: #1a1a2e;
            --success: #22c55e;
            --error: #ef4444;
            --warning: #f59e0b;
        }
        
        * { box-sizing: border-box; margin: 0; padding: 0; }
        
        body { 
            font-family: 'DM Sans', sans-serif; 
            background: var(--bg); 
            color: var(--ink); 
            line-height: 1.6; 
        }
        
        .container { 
            max-width: 1100px; 
            margin: 0 auto; 
            padding: 2rem; 
        }
        
        header { 
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem; 
            padding-bottom: 1.5rem; 
            border-bottom: 2px solid var(--gold); 
        }
        
        .logo {
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        
        .logo-icon {
            width: 48px;
            height: 48px;
            background: var(--navy);
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--gold);
            font-family: 'EB Garamond', serif;
            font-size: 1.5rem;
            font-weight: 600;
        }
        
        h1 { 
            font-family: 'EB Garamond', serif; 
            font-size: 1.75rem; 
            font-weight: 500; 
        }
        
        .subtitle { 
            color: var(--muted); 
            font-size: 0.9rem;
        }
        
        .header-stats {
            display: flex;
            gap: 1.5rem;
        }
        
        .header-stat {
            text-align: center;
        }
        
        .header-stat-value {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--gold);
        }
        
        .header-stat-label {
            font-size: 0.7rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            color: var(--muted);
        }
        
        /* Tabs */
        .tabs { 
            display: flex; 
            gap: 0.5rem; 
            margin-bottom: 2rem; 
            border-bottom: 1px solid var(--line); 
        }
        
        .tab { 
            padding: 0.75rem 1.5rem; 
            background: none; 
            border: none; 
            font-family: inherit; 
            color: var(--muted); 
            cursor: pointer; 
            text-decoration: none; 
            border-radius: 4px 4px 0 0;
            font-size: 0.95rem;
        }
        
        .tab:hover { 
            color: var(--ink); 
            background: var(--paper); 
        }
        
        .tab.active { 
            color: var(--gold); 
            background: var(--paper); 
            font-weight: 500;
            border-bottom: 2px solid var(--gold);
            margin-bottom: -1px;
        }
        
        /* Cards */
        .card { 
            background: var(--paper); 
            border: 1px solid var(--line); 
            border-radius: 8px; 
            padding: 1.5rem; 
            margin-bottom: 1.5rem; 
            box-shadow: 0 1px 3px rgba(0,0,0,0.05);
        }
        
        .card h3 { 
            font-family: 'EB Garamond', serif; 
            font-size: 1.25rem; 
            margin-bottom: 1rem;
            color: var(--navy);
        }
        
        /* Forms */
        .form-row { 
            margin-bottom: 1.25rem; 
        }
        
        .form-row-split { 
            display: grid; 
            grid-template-columns: 1fr 1fr; 
            gap: 1rem; 
        }
        
        .form-row-triple { 
            display: grid; 
            grid-template-columns: 1fr 1fr 1fr; 
            gap: 1rem; 
        }
        
        label { 
            display: block; 
            font-size: 0.75rem; 
            font-weight: 500; 
            color: var(--ink-light); 
            margin-bottom: 0.4rem; 
            text-transform: uppercase; 
            letter-spacing: 0.05em; 
        }
        
        input, select, textarea { 
            width: 100%; 
            padding: 0.75rem; 
            border: 1px solid var(--line); 
            border-radius: 4px; 
            font-family: inherit; 
            font-size: 0.95rem; 
            background: var(--bg); 
        }
        
        input:focus, select:focus, textarea:focus { 
            outline: none; 
            border-color: var(--gold); 
            box-shadow: 0 0 0 3px var(--gold-muted);
        }
        
        textarea { 
            min-height: 100px; 
            resize: vertical; 
        }
        
        .help-text { 
            font-size: 0.8rem; 
            color: var(--muted); 
            margin-top: 0.25rem; 
        }
        
        /* Buttons */
        .btn { 
            display: inline-flex; 
            align-items: center; 
            gap: 0.5rem;
            padding: 0.75rem 1.5rem; 
            font-family: inherit; 
            font-size: 0.95rem; 
            font-weight: 500; 
            border: none; 
            border-radius: 4px; 
            cursor: pointer; 
            text-decoration: none; 
        }
        
        .btn-primary { 
            background: var(--navy); 
            color: var(--paper); 
        }
        
        .btn-primary:hover { 
            background: #2a2a4e; 
        }
        
        .btn-gold { 
            background: var(--gold); 
            color: white; 
        }
        
        .btn-gold:hover { 
            background: var(--gold-light); 
        }
        
        .btn-secondary { 
            background: var(--paper); 
            color: var(--ink); 
            border: 1px solid var(--line); 
        }
        
        .btn-secondary:hover { 
            border-color: var(--gold); 
            color: var(--gold); 
        }
        
        .btn-danger { 
            background: var(--error); 
            color: white; 
        }
        
        .btn-danger:hover { 
            background: #dc2626; 
        }
        
        .btn-small { 
            padding: 0.4rem 0.75rem; 
            font-size: 0.8rem; 
        }
        
        .btn-full { 
            width: 100%; 
            justify-content: center; 
        }
        
        /* Alerts */
        .alert { 
            padding: 1rem; 
            border-radius: 4px; 
            margin-bottom: 1.5rem; 
        }
        
        .alert-success { 
            background: rgba(34, 197, 94, 0.1); 
            border: 1px solid rgba(34, 197, 94, 0.3); 
            color: #166534; 
        }
        
        .alert-error { 
            background: rgba(239, 68, 68, 0.1); 
            border: 1px solid rgba(239, 68, 68, 0.3); 
            color: #b91c1c; 
        }
        
        .alert-warning { 
            background: rgba(245, 158, 11, 0.1); 
            border: 1px solid rgba(245, 158, 11, 0.3); 
            color: #92400e; 
        }
        
        /* Terms List */
        .terms-list { 
            display: flex; 
            flex-direction: column; 
            gap: 0.75rem; 
        }
        
        .term-item { 
            display: flex; 
            align-items: flex-start; 
            gap: 1rem; 
            padding: 1rem; 
            background: var(--bg); 
            border-radius: 6px;
            border-left: 3px solid var(--line);
            transition: all 0.15s ease;
        }
        
        .term-item:hover {
            border-left-color: var(--gold);
        }
        
        .term-item.validated {
            border-left-color: var(--success);
        }
        
        .term-item.has-issues {
            border-left-color: var(--warning);
        }
        
        .term-item-main { 
            flex: 1; 
        }
        
        .term-item-name { 
            font-family: 'EB Garamond', serif; 
            font-size: 1.1rem;
            font-weight: 500;
            color: var(--navy);
        }
        
        .term-item-definition { 
            font-size: 0.9rem; 
            color: var(--ink-light);
            margin-top: 0.25rem;
            line-height: 1.5;
        }
        
        .term-item-meta { 
            display: flex;
            gap: 1rem;
            margin-top: 0.5rem;
            font-size: 0.75rem; 
            color: var(--muted); 
        }
        
        .term-item-actions { 
            display: flex; 
            gap: 0.5rem;
            flex-shrink: 0;
        }
        
        .category-badge {
            display: inline-block;
            padding: 0.2rem 0.5rem;
            border-radius: 3px;
            font-size: 0.7rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            font-weight: 500;
        }
        
        .category-party { background: rgba(59, 130, 246, 0.15); color: #2563eb; }
        .category-document { background: rgba(139, 92, 246, 0.15); color: #7c3aed; }
        .category-date { background: rgba(245, 158, 11, 0.15); color: #d97706; }
        .category-facility { background: rgba(6, 182, 212, 0.15); color: #0891b2; }
        .category-collateral { background: rgba(236, 72, 153, 0.15); color: #db2777; }
        .category-covenant { background: rgba(239, 68, 68, 0.15); color: #dc2626; }
        .category-general { background: rgba(107, 114, 128, 0.15); color: #4b5563; }
        
        /* Search/Filter */
        .search-bar {
            display: flex;
            gap: 1rem;
            margin-bottom: 1.5rem;
        }
        
        .search-bar input {
            flex: 1;
        }
        
        .search-bar select {
            width: 200px;
        }
        
        /* Preview Panel */
        .preview-panel {
            background: var(--paper);
            border: 1px solid var(--line);
            border-radius: 8px;
            padding: 1.5rem;
            margin-top: 1.5rem;
        }
        
        .preview-content {
            font-family: 'EB Garamond', serif;
            font-size: 1.1rem;
            line-height: 1.75;
        }
        
        .preview-term {
            color: var(--navy);
            font-weight: 500;
            background: linear-gradient(180deg, transparent 60%, var(--gold-muted) 60%);
            padding: 0 2px;
            border-bottom: 1px dotted var(--gold);
            cursor: help;
        }
        
        .preview-term:hover {
            background: var(--gold-muted);
        }
        
        /* Cross References */
        .cross-refs {
            display: flex;
            flex-wrap: wrap;
            gap: 0.5rem;
            margin-top: 0.5rem;
        }
        
        .cross-ref {
            display: inline-flex;
            align-items: center;
            gap: 0.25rem;
            padding: 0.2rem 0.5rem;
            background: var(--bg);
            border: 1px solid var(--line);
            border-radius: 3px;
            font-size: 0.75rem;
            color: var(--ink-light);
        }
        
        .cross-ref-remove {
            color: var(--muted);
            cursor: pointer;
            font-size: 1rem;
            line-height: 1;
        }
        
        .cross-ref-remove:hover {
            color: var(--error);
        }
        
        /* Validation */
        .validation-issues {
            margin-top: 0.5rem;
        }
        
        .validation-issue {
            font-size: 0.8rem;
            color: var(--warning);
            display: flex;
            align-items: center;
            gap: 0.25rem;
        }
        
        /* Stats Grid */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 1rem;
            margin-bottom: 1.5rem;
        }
        
        .stat-card {
            background: var(--paper);
            border: 1px solid var(--line);
            border-radius: 6px;
            padding: 1rem;
            text-align: center;
        }
        
        .stat-value {
            font-size: 2rem;
            font-weight: 600;
            color: var(--gold);
        }
        
        .stat-label {
            font-size: 0.75rem;
            color: var(--muted);
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }
        
        /* Footer */
        footer { 
            margin-top: 3rem; 
            padding-top: 1.5rem; 
            border-top: 1px solid var(--line); 
            text-align: center; 
            font-size: 0.85rem; 
            color: var(--muted); 
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .form-row-split, .form-row-triple { 
                grid-template-columns: 1fr; 
            }
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            .header {
                flex-direction: column;
                gap: 1rem;
            }
        }
        
        /* Empty state */
        .empty-state {
            text-align: center;
            padding: 3rem;
            color: var(--muted);
        }
        
        .empty-state-icon {
            font-size: 3rem;
            margin-bottom: 1rem;
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <div class="logo">
                <div class="logo-icon">§</div>
                <div>
                    <h1>Terms Manager</h1>
                    <div class="subtitle">Legal Transaction Engine</div>
                </div>
            </div>
            <div class="header-stats">
                <div class="header-stat">
                    <div class="header-stat-value">{{ terms|length }}</div>
                    <div class="header-stat-label">Total Terms</div>
                </div>
                <div class="header-stat">
                    <div class="header-stat-value">{{ validated_count }}</div>
                    <div class="header-stat-label">Validated</div>
                </div>
            </div>
        </header>
        
        {% if message %}
        <div class="alert alert-{{ 'success' if success == 'true' else 'error' }}">
            {{ message }}
        </div>
        {% endif %}
        
        <div class="tabs">
            <a href="?tab=terms" class="tab {{ 'active' if tab == 'terms' else '' }}">📚 All Terms</a>
            <a href="?tab=add" class="tab {{ 'active' if tab == 'add' else '' }}">➕ Add Term</a>
            <a href="?tab=preview" class="tab {{ 'active' if tab == 'preview' else '' }}">👁️ Preview</a>
            <a href="?tab=validate" class="tab {{ 'active' if tab == 'validate' else '' }}">✓ Validate</a>
            <a href="?tab=export" class="tab {{ 'active' if tab == 'export' else '' }}">📤 Export</a>
        </div>
        
        {% if tab == 'terms' %}
        <!-- TERMS LIST TAB -->
        <div class="search-bar">
            <input type="text" id="search-input" placeholder="Search terms..." oninput="filterTerms()">
            <select id="category-filter" onchange="filterTerms()">
                <option value="">All Categories</option>
                {% for cat_id, cat_name, cat_desc in categories %}
                <option value="{{ cat_id }}">{{ cat_name }}</option>
                {% endfor %}
            </select>
        </div>
        
        {% if terms %}
        <div class="terms-list" id="terms-list">
            {% for term in terms %}
            <div class="term-item {% if term.validated %}validated{% endif %}" 
                 data-term="{{ term.term|lower }}" 
                 data-category="{{ term.category }}">
                <div class="term-item-main">
                    <div class="term-item-name">"{{ term.term }}"</div>
                    <div class="term-item-definition">{{ term.definition[:200] }}{% if term.definition|length > 200 %}...{% endif %}</div>
                    <div class="term-item-meta">
                        <span class="category-badge category-{{ term.category }}">{{ term.category }}</span>
                        {% if term.section_reference %}
                        <span>{{ term.section_reference }}</span>
                        {% endif %}
                        {% if term.cross_references %}
                        <span>{{ term.cross_references|length }} cross-refs</span>
                        {% endif %}
                    </div>
                </div>
                <div class="term-item-actions">
                    <a href="?tab=edit&id={{ term.id }}" class="btn btn-secondary btn-small">Edit</a>
                    <form action="/delete" method="POST" style="display:inline" onsubmit="return confirm('Delete this term?')">
                        <input type="hidden" name="id" value="{{ term.id }}">
                        <button type="submit" class="btn btn-danger btn-small">×</button>
                    </form>
                </div>
            </div>
            {% endfor %}
        </div>
        {% else %}
        <div class="empty-state">
            <div class="empty-state-icon">📝</div>
            <h3>No terms yet</h3>
            <p>Add your first defined term to get started.</p>
            <a href="?tab=add" class="btn btn-gold" style="margin-top: 1rem">Add Term</a>
        </div>
        {% endif %}
        
        {% elif tab == 'add' %}
        <!-- ADD TERM TAB -->
        <div class="card">
            <h3>Add New Term</h3>
            <form action="/add" method="POST">
                <div class="form-row">
                    <label for="term">Term Name *</label>
                    <input type="text" id="term" name="term" required placeholder='e.g., "Borrower"'>
                    <div class="help-text">The defined term exactly as it appears in the agreement (include quotes if appropriate)</div>
                </div>
                
                <div class="form-row">
                    <label for="definition">Definition *</label>
                    <textarea id="definition" name="definition" required placeholder="Enter the full definition text..."></textarea>
                </div>
                
                <div class="form-row-split">
                    <div class="form-row">
                        <label for="category">Category *</label>
                        <select id="category" name="category" required>
                            {% for cat_id, cat_name, cat_desc in categories %}
                            <option value="{{ cat_id }}">{{ cat_name }} — {{ cat_desc }}</option>
                            {% endfor %}
                        </select>
                    </div>
                    
                    <div class="form-row">
                        <label for="section_reference">Section Reference</label>
                        <input type="text" id="section_reference" name="section_reference" placeholder="e.g., Section 1.01">
                    </div>
                </div>
                
                <div class="form-row">
                    <label for="cross_references">Cross-References</label>
                    <input type="text" id="cross_references" name="cross_references" placeholder="Comma-separated: Lender, Borrower, Loan Documents">
                    <div class="help-text">Terms referenced in this definition (will be auto-detected if left blank)</div>
                </div>
                
                <div class="form-row">
                    <label for="notes">Notes (Internal)</label>
                    <input type="text" id="notes" name="notes" placeholder="e.g., Standard boilerplate - safe to use">
                </div>
                
                <div style="display: flex; gap: 1rem; margin-top: 1.5rem;">
                    <button type="submit" class="btn btn-gold">Add Term</button>
                    <button type="submit" name="add_another" value="1" class="btn btn-secondary">Add & Continue</button>
                </div>
            </form>
        </div>
        
        {% elif tab == 'edit' %}
        <!-- EDIT TERM TAB -->
        {% if edit_term %}
        <div class="card">
            <h3>Edit Term</h3>
            <form action="/update" method="POST">
                <input type="hidden" name="id" value="{{ edit_term.id }}">
                
                <div class="form-row">
                    <label for="term">Term Name *</label>
                    <input type="text" id="term" name="term" required value="{{ edit_term.term }}">
                </div>
                
                <div class="form-row">
                    <label for="definition">Definition *</label>
                    <textarea id="definition" name="definition" required>{{ edit_term.definition }}</textarea>
                </div>
                
                <div class="form-row-split">
                    <div class="form-row">
                        <label for="category">Category *</label>
                        <select id="category" name="category" required>
                            {% for cat_id, cat_name, cat_desc in categories %}
                            <option value="{{ cat_id }}" {% if edit_term.category == cat_id %}selected{% endif %}>{{ cat_name }}</option>
                            {% endfor %}
                        </select>
                    </div>
                    
                    <div class="form-row">
                        <label for="section_reference">Section Reference</label>
                        <input type="text" id="section_reference" name="section_reference" value="{{ edit_term.section_reference or '' }}">
                    </div>
                </div>
                
                <div class="form-row">
                    <label for="cross_references">Cross-References</label>
                    <input type="text" id="cross_references" name="cross_references" value="{{ edit_term.cross_references|join(', ') if edit_term.cross_references else '' }}">
                </div>
                
                <div class="form-row">
                    <label for="notes">Notes</label>
                    <input type="text" id="notes" name="notes" value="{{ edit_term.notes or '' }}">
                </div>
                
                <div class="form-row">
                    <label class="checkbox-row">
                        <input type="checkbox" name="validated" value="1" {% if edit_term.validated %}checked{% endif %}>
                        <span>Mark as validated</span>
                    </label>
                </div>
                
                <div style="display: flex; gap: 1rem; margin-top: 1.5rem;">
                    <button type="submit" class="btn btn-gold">Save Changes</button>
                    <a href="?tab=terms" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>
        {% else %}
        <div class="alert alert-error">Term not found</div>
        {% endif %}
        
        {% elif tab == 'preview' %}
        <!-- PREVIEW TAB -->
        <div class="card">
            <h3>Interactive Preview</h3>
            <p class="help-text" style="margin-bottom: 1rem;">See how your terms will look with Gwern-style annotations. Hover over highlighted terms to see definitions.</p>
            
            <div class="preview-panel">
                <div class="preview-content" id="preview-content">
                    Subject to the terms and conditions set forth herein, each <span class="preview-term" title="each financial institution listed on Schedule 2.01 and any other Person that becomes a party hereto pursuant to an Assignment and Assumption.">Lender</span> 
                    severally agrees to make <span class="preview-term" title="a loan made by a Lender to the Borrower pursuant to Section 2.01.">Revolving Loans</span> to the 
                    <span class="preview-term" title="ABC Corporation, a Delaware corporation.">Borrower</span> from time to time, on any 
                    <span class="preview-term" title="any day that is not a Saturday, Sunday or other day on which commercial banks in New York City are authorized or required by law to remain closed.">Business Day</span> during the period from the 
                    <span class="preview-term" title="March 15, 2025.">Closing Date</span> until the 
                    <span class="preview-term" title="March 15, 2030.">Maturity Date</span>.
                </div>
            </div>
            
            <div class="card" style="margin-top: 1.5rem;">
                <h3>Test Your Text</h3>
                <form action="/preview-text" method="POST">
                    <div class="form-row">
                        <label for="test-text">Paste agreement text to preview</label>
                        <textarea id="test-text" name="text" rows="6" placeholder="Paste a paragraph from your credit agreement here..."></textarea>
                    </div>
                    <button type="submit" class="btn btn-gold">Preview with Annotations</button>
                </form>
                
                {% if preview_html %}
                <div class="preview-panel" style="margin-top: 1rem;">
                    <div class="preview-content">{{ preview_html|safe }}</div>
                </div>
                {% endif %}
            </div>
        </div>
        
        {% elif tab == 'validate' %}
        <!-- VALIDATE TAB -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-value">{{ terms|length }}</div>
                <div class="stat-label">Total Terms</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">{{ validated_count }}</div>
                <div class="stat-label">Validated</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">{{ terms|length - validated_count }}</div>
                <div class="stat-label">Pending</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">{{ issues_count }}</div>
                <div class="stat-label">Issues</div>
            </div>
        </div>
        
        <div class="card">
            <h3>Terms Needing Review</h3>
            {% set pending_terms = terms|selectattr('validated', 'false')|list %}
            {% if pending_terms %}
            <div class="terms-list">
                {% for term in pending_terms %}
                {% set term_issues = validation_results.get(term.id, []) %}
                <div class="term-item {% if term_issues %}has-issues{% endif %}">
                    <div class="term-item-main">
                        <div class="term-item-name">"{{ term.term }}"</div>
                        <div class="term-item-definition">{{ term.definition[:150] }}...</div>
                        {% if term_issues %}
                        <div class="validation-issues">
                            {% for issue in term_issues %}
                            <div class="validation-issue">⚠️ {{ issue }}</div>
                            {% endfor %}
                        </div>
                        {% endif %}
                    </div>
                    <div class="term-item-actions">
                        <form action="/validate-term" method="POST" style="display:inline">
                            <input type="hidden" name="id" value="{{ term.id }}">
                            <button type="submit" class="btn btn-small btn-gold">✓ Validate</button>
                        </form>
                        <a href="?tab=edit&id={{ term.id }}" class="btn btn-secondary btn-small">Edit</a>
                    </div>
                </div>
                {% endfor %}
            </div>
            {% else %}
            <div class="empty-state">
                <div class="empty-state-icon">✅</div>
                <h3>All terms validated!</h3>
            </div>
            {% endif %}
        </div>
        
        {% elif tab == 'export' %}
        <!-- EXPORT TAB -->
        <div class="card">
            <h3>Export Terms</h3>
            <p class="help-text" style="margin-bottom: 1.5rem;">Export your terms for use in the demo site or other applications.</p>
            
            <div class="form-row-split">
                <div>
                    <a href="/export/json" class="btn btn-gold btn-full">Download JSON</a>
                    <div class="help-text" style="margin-top: 0.5rem;">For the demo site (defined_terms.json)</div>
                </div>
                <div>
                    <a href="/export/html" class="btn btn-secondary btn-full">Download HTML Snippet</a>
                    <div class="help-text" style="margin-top: 0.5rem;">Interactive doc markup</div>
                </div>
            </div>
        </div>
        
        <div class="card">
            <h3>Deploy to Demo Site</h3>
            {% if has_changes %}
            <div class="alert alert-warning">You have uncommitted changes.</div>
            {% endif %}
            
            <form action="/deploy" method="POST">
                <div class="form-row">
                    <label for="commit_message">Commit Message</label>
                    <input type="text" id="commit_message" name="commit_message" value="Update defined terms" required>
                </div>
                <button type="submit" class="btn btn-primary">Commit & Push to GitHub</button>
            </form>
        </div>
        
        {% endif %}
        
        <footer>
            Legal Transaction Engine — Terms Manager v1.0<br>
            <span style="font-size: 0.8rem;">Data: {{ terms_file }}</span>
        </footer>
    </div>
    
    <script>
        function filterTerms() {
            const searchTerm = document.getElementById('search-input').value.toLowerCase();
            const category = document.getElementById('category-filter').value;
            const items = document.querySelectorAll('.term-item');
            
            items.forEach(item => {
                const termName = item.dataset.term;
                const termCategory = item.dataset.category;
                
                const matchesSearch = !searchTerm || termName.includes(searchTerm);
                const matchesCategory = !category || termCategory === category;
                
                item.style.display = (matchesSearch && matchesCategory) ? 'flex' : 'none';
            });
        }
    </script>
</body>
</html>
'''

# =============================================================================
# ROUTES
# =============================================================================

@app.route('/')
def index():
    terms = load_terms()
    tab = request.args.get('tab', 'terms')
    message = request.args.get('message')
    success = request.args.get('success', 'true')
    
    # Calculate stats
    validated_count = sum(1 for t in terms if t.get('validated'))
    
    # Validation results
    validation_results = {}
    issues_count = 0
    for term in terms:
        issues = validate_term(term, terms)
        if issues:
            validation_results[term['id']] = issues
            issues_count += len(issues)
    
    # For edit tab
    edit_term = None
    if tab == 'edit':
        edit_id = request.args.get('id')
        edit_term = get_term_by_id(edit_id)
    
    return render_template_string(
        HTML_TEMPLATE,
        terms=terms,
        tab=tab,
        message=message,
        success=success,
        categories=CATEGORIES,
        validated_count=validated_count,
        issues_count=issues_count,
        validation_results=validation_results,
        edit_term=edit_term,
        has_changes=git_status(),
        terms_file=str(TERMS_FILE),
        preview_html=None
    )


@app.route('/add', methods=['POST'])
def add_term():
    terms = load_terms()
    
    term_name = request.form.get('term', '').strip()
    definition = request.form.get('definition', '').strip()
    category = request.form.get('category', 'general')
    section_ref = request.form.get('section_reference', '').strip()
    notes = request.form.get('notes', '').strip()
    cross_refs_str = request.form.get('cross_references', '').strip()
    
    # Parse cross-references
    if cross_refs_str:
        cross_refs = [r.strip() for r in cross_refs_str.split(',') if r.strip()]
    else:
        # Auto-detect cross-references
        cross_refs = extract_cross_references(definition, terms)
    
    new_term = {
        'id': generate_id(),
        'term': term_name,
        'definition': definition,
        'source': 'credit_agreement',
        'section_reference': section_ref or 'Section 1.01',
        'category': category,
        'cross_references': cross_refs,
        'usage_locations': [],
        'created_at': datetime.now().isoformat(),
        'updated_at': datetime.now().isoformat(),
        'notes': notes,
        'validated': False,
        'supersedes_id': None,
        'superseded_by_id': None
    }
    
    # Validate
    issues = validate_term(new_term, terms)
    if issues:
        return redirect(url_for('index', tab='add', message=f"Error: {'; '.join(issues)}", success='false'))
    
    terms.append(new_term)
    
    # Sort alphabetically
    terms.sort(key=lambda t: t.get('term', '').lower())
    
    save_terms(terms)
    
    # Check if user wants to add another
    if request.form.get('add_another'):
        return redirect(url_for('index', tab='add', message=f'Added "{term_name}"', success='true'))
    
    return redirect(url_for('index', tab='terms', message=f'Added "{term_name}"', success='true'))


@app.route('/update', methods=['POST'])
def update_term():
    terms = load_terms()
    term_id = request.form.get('id')
    
    for term in terms:
        if term.get('id') == term_id:
            term['term'] = request.form.get('term', '').strip()
            term['definition'] = request.form.get('definition', '').strip()
            term['category'] = request.form.get('category', 'general')
            term['section_reference'] = request.form.get('section_reference', '').strip()
            term['notes'] = request.form.get('notes', '').strip()
            term['validated'] = request.form.get('validated') == '1'
            term['updated_at'] = datetime.now().isoformat()
            
            # Parse cross-references
            cross_refs_str = request.form.get('cross_references', '').strip()
            if cross_refs_str:
                term['cross_references'] = [r.strip() for r in cross_refs_str.split(',') if r.strip()]
            else:
                term['cross_references'] = []
            
            break
    
    # Re-sort
    terms.sort(key=lambda t: t.get('term', '').lower())
    
    save_terms(terms)
    
    return redirect(url_for('index', tab='terms', message='Term updated', success='true'))


@app.route('/delete', methods=['POST'])
def delete_term():
    terms = load_terms()
    term_id = request.form.get('id')
    
    deleted_name = None
    for term in terms:
        if term.get('id') == term_id:
            deleted_name = term.get('term')
            break
    
    terms = [t for t in terms if t.get('id') != term_id]
    save_terms(terms)
    
    return redirect(url_for('index', tab='terms', message=f'Deleted "{deleted_name}"', success='true'))


@app.route('/validate-term', methods=['POST'])
def validate_term_route():
    terms = load_terms()
    term_id = request.form.get('id')
    
    for term in terms:
        if term.get('id') == term_id:
            term['validated'] = True
            term['updated_at'] = datetime.now().isoformat()
            break
    
    save_terms(terms)
    
    return redirect(url_for('index', tab='validate', message='Term validated', success='true'))


@app.route('/preview-text', methods=['POST'])
def preview_text():
    terms = load_terms()
    text = request.form.get('text', '')
    
    # Create annotated HTML
    html = text
    
    # Sort terms by length (longest first) to avoid partial matches
    sorted_terms = sorted(terms, key=lambda t: len(t.get('term', '')), reverse=True)
    
    for term in sorted_terms:
        term_name = term.get('term', '')
        definition = term.get('definition', '')
        
        # Escape definition for HTML title attribute
        safe_def = definition.replace('"', '&quot;').replace("'", "&#39;")
        
        # Replace term occurrences (case-insensitive, word boundary)
        pattern = r'\b(' + re.escape(term_name) + r's?)\b'
        replacement = f'<span class="preview-term" title="{safe_def}">\\1</span>'
        html = re.sub(pattern, replacement, html, flags=re.IGNORECASE)
    
    # Store in session or pass back
    terms = load_terms()
    validated_count = sum(1 for t in terms if t.get('validated'))
    
    return render_template_string(
        HTML_TEMPLATE,
        terms=terms,
        tab='preview',
        message=None,
        success='true',
        categories=CATEGORIES,
        validated_count=validated_count,
        issues_count=0,
        validation_results={},
        edit_term=None,
        has_changes=git_status(),
        terms_file=str(TERMS_FILE),
        preview_html=html
    )


@app.route('/export/json')
def export_json():
    terms = load_terms()
    
    # Clean up internal fields for export
    export_terms = []
    for term in terms:
        export_term = {
            'id': term.get('id'),
            'term': term.get('term'),
            'definition': term.get('definition'),
            'source': term.get('source', 'credit_agreement'),
            'section_reference': term.get('section_reference'),
            'category': term.get('category'),
            'cross_references': term.get('cross_references', []),
            'usage_locations': term.get('usage_locations', []),
            'created_at': term.get('created_at'),
            'updated_at': term.get('updated_at'),
            'notes': term.get('notes', ''),
            'supersedes_id': term.get('supersedes_id'),
            'superseded_by_id': term.get('superseded_by_id')
        }
        export_terms.append(export_term)
    
    response = app.response_class(
        response=json.dumps(export_terms, indent=2),
        status=200,
        mimetype='application/json'
    )
    response.headers['Content-Disposition'] = 'attachment; filename=defined_terms.json'
    return response


@app.route('/export/html')
def export_html():
    terms = load_terms()
    
    # Generate HTML snippet for each term
    lines = ['<!-- Defined Terms for Interactive Document -->']
    lines.append('<!-- Copy these spans into your document text -->')
    lines.append('')
    
    for term in terms:
        term_name = term.get('term', '')
        lines.append(f'<span class="defined-term" data-term="{term_name}">{term_name}</span>')
    
    response = app.response_class(
        response='\n'.join(lines),
        status=200,
        mimetype='text/html'
    )
    response.headers['Content-Disposition'] = 'attachment; filename=term_spans.html'
    return response


@app.route('/deploy', methods=['POST'])
def deploy():
    message = request.form.get('commit_message', 'Update defined terms')
    success, result = git_commit_and_push(message)
    return redirect(url_for('index', tab='export', message=result, success=str(success).lower()))


# =============================================================================
# MAIN
# =============================================================================

if __name__ == '__main__':
    print(f"""
{'='*60}
  Legal Transaction Engine — Terms Manager v1.0
{'='*60}

  Working Directory: {MANAGER_ROOT}
  Terms File:        {TERMS_FILE}
  
  Open: http://localhost:5002

{'='*60}
""")
    
    # Create empty terms file if it doesn't exist
    if not TERMS_FILE.exists():
        save_terms([])
        print(f"  Created empty terms file: {TERMS_FILE}")
    
    app.run(debug=True, port=5002)
