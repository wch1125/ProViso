# [Project Name] - Current Status

## Last Updated
YYYY-MM-DD HH:MM by [Role]

## Project Health
🟢 On Track / 🟡 Minor Issues / 🔴 Blocked

## Current Phase
[Scout / Build / Test / Review / Document / Maintenance]

## What's Working
- [List working features]

## What's In Progress
- [Current work items]

## Known Issues
- [ ] [Issue 1]
- [ ] [Issue 2]

## Blockers
- [Any blockers preventing progress]

## Open Questions
- [ ] [Question needing decision]

## Next Steps
1. [Next action item]
2. [Following action item]

## Notes for Next Claude Instance
[Any context that would help the next session]

---

*Update this file at the end of every Claude session.*
