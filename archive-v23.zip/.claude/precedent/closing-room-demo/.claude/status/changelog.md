# [Project Name] Changelog

All notable changes to this project are documented here.

## [Unreleased]

### Added
- Initial project setup

### Changed
- 

### Fixed
- 

---

## [0.1.0] - YYYY-MM-DD

### Added
- Project scaffolding
- Basic structure

### Notes
- Initial setup, not yet functional

---

<!--
CHANGELOG GUIDELINES:

Update this file at the end of every Claude session.

Categories:
- Added: New features
- Changed: Changes to existing functionality
- Deprecated: Features to be removed
- Removed: Features removed
- Fixed: Bug fixes
- Security: Security-related changes

Format:
## [Version] - YYYY-MM-DD
or
## YYYY-MM-DD - [Role] (for session-based updates)
-->
