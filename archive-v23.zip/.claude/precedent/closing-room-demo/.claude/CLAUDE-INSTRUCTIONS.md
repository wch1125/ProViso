# Claude Workflow Instructions

> **This file should be read by every Claude instance at the start of a session.**
> Location: `.claude/CLAUDE-INSTRUCTIONS.md` in each project

## Your Role in This Project

You are one of several Claude instances that may work on this project. To maintain consistency and enable smooth handoffs, follow these conventions.

---

## Directory Structure You Must Maintain

```
project-root/
├── .claude/                      # WORKFLOW ARTIFACTS - YOU MANAGE THIS
│   ├── CLAUDE-INSTRUCTIONS.md    # This file
│   ├── logs/                     # Session logs (one per session)
│   ├── decisions/                # Architecture Decision Records
│   └── status/                   # Project status tracking
│       ├── current-status.md     # Current state (update each session)
│       └── changelog.md          # Running log of all changes
│
├── src/                          # Source code
├── templates/                    # HTML/Jinja templates
├── static/                       # CSS, JS, images
├── tests/                        # Test suite
├── data/                         # Data files (may be gitignored)
├── docs/                         # User-facing documentation
│
├── README.md                     # Project overview
├── CHANGELOG.md                  # (symlink to .claude/status/changelog.md or copy)
└── requirements.txt              # Dependencies
```

---

## What You Must Do Each Session

### 1. At Session Start

- Read `.claude/status/current-status.md` to understand where things stand
- Check `.claude/logs/` for recent session logs if you need context
- Note any blockers or open questions from previous sessions

### 2. During Your Session

- Make atomic, testable changes
- Document decisions as you make them
- If you make an architectural decision, create an ADR (see below)

### 3. At Session End

**Create a session log** in `.claude/logs/`:

Filename format: `YYYY-MM-DD-[role]-[brief-description].md`

Example: `2025-01-18-builder-calendar-integration.md`

```markdown
# [ROLE] Session Log - YYYY-MM-DD

## Objective
What this session aimed to accomplish

## Work Completed
### 1. [Task]
- What was done
- Files modified: `path/to/file.py`
- How it was verified

## Decisions Made
| Decision | Rationale |
|----------|-----------|
| Used X instead of Y | Because Z |

## Open Questions
- [ ] Question for user
- [ ] Question for next Claude instance

## Handoff Notes
### For Next Session
- Continue with...
- Watch out for...

## Files Changed
```
modified: src/main.py
added: templates/calendar.html
```
```

**Update `.claude/status/current-status.md`:**

```markdown
# [Project Name] - Current Status

## Last Updated
YYYY-MM-DD HH:MM by [Role]

## Current Phase
[Scout / Build / Test / Review / Document / Maintenance]

## What's Working
- Feature A ✓
- Feature B ✓

## What's In Progress
- Feature C (80% complete)

## Known Issues
- [ ] Bug X
- [ ] Bug Y

## Blockers
- Waiting on user decision about Z

## Next Steps
1. Finish Feature C
2. Test edge cases
3. Hand off to Tester

## Notes for Next Claude Instance
[Anything the next Claude should know]
```

**Update `.claude/status/changelog.md`:**

```markdown
## YYYY-MM-DD - [Role]

### Added
- New feature X

### Changed  
- Modified Y to do Z

### Fixed
- Bug in W
```

---

## Architecture Decision Records (ADRs)

When you make a significant technical decision, document it in `.claude/decisions/`:

Filename: `ADR-NNN-[topic].md`

Example: `ADR-001-use-fastapi-over-flask.md`

```markdown
# ADR-001: Use FastAPI Over Flask

## Status
Accepted

## Context
We need a Python web framework for the practice management system.

## Decision
Use FastAPI instead of Flask.

## Rationale
- Async support built-in
- Automatic OpenAPI documentation
- Type hints and validation via Pydantic
- Better performance for concurrent requests

## Consequences
- Team needs to learn async patterns
- Some Flask extensions won't work
- Deployment may need ASGI server (uvicorn)

## Alternatives Considered
- Flask: More familiar but lacks async
- Django: Too heavy for this use case
```

---

## File Naming Conventions

| Type | Pattern | Example |
|------|---------|---------|
| Session logs | `YYYY-MM-DD-[role]-[description].md` | `2025-01-18-builder-auth-system.md` |
| ADRs | `ADR-NNN-[topic].md` | `ADR-003-database-choice.md` |
| Test files | `test_[module].py` | `test_calendar.py` |

---

## Role-Specific Guidelines

### Scout
- Map the codebase thoroughly before recommending changes
- Document constraints, hazards, and patterns
- Output: Reconnaissance report in `.claude/logs/`

### Builder
- Implement incrementally with verification at each step
- Don't skip tests
- Document what you *actually built*, not what you intended
- Output: Working code + build log

### Tester
- Focus on edge cases and failure modes
- Test state transitions and boundary conditions
- Document reproduction steps for bugs
- Output: Test report + bug list

### Reviewer
- Verify claimed fixes are actually implemented
- Check for security vulnerabilities
- Validate documentation matches reality
- Output: Review report with severity ratings

### Refactorer
- Never change behavior, only improve structure
- Ensure tests pass before AND after
- Make small, atomic commits
- Output: Cleaner code + refactor notes

### Documentarian
- Write for the actual audience (user vs developer)
- Include concrete examples
- Keep it maintainable
- Output: Documentation in `docs/`

### PM
- Monitor for drift from requirements
- Surface ambiguities and blockers
- Coordinate handoffs between roles
- Output: Status updates, escalations

---

## Handoff Protocol

When your session ends and another Claude will continue:

1. **Complete your session log** (see format above)
2. **Update current-status.md** with latest state
3. **Add to changelog.md** 
4. **Be explicit about what's next** — don't assume the next Claude knows anything

When you start and a previous Claude worked on this:

1. **Read current-status.md first**
2. **Check recent logs** in `.claude/logs/`
3. **Don't redo work** — continue from where they left off
4. **Ask the user** if anything is unclear

---

## Things You Should Never Do

- ❌ Delete or overwrite previous session logs
- ❌ Modify files outside the project without explicit permission
- ❌ Skip updating status files at end of session
- ❌ Make changes without documenting them
- ❌ Assume you know what a previous Claude did — read the logs
- ❌ Leave the project in a broken state

---

## Quick Reference

```
End of session checklist:
[ ] Session log created in .claude/logs/
[ ] current-status.md updated
[ ] changelog.md updated
[ ] All changes documented
[ ] Handoff notes written
[ ] No broken code left behind
```

---

*This file is part of the Haslun Domains multi-Claude workflow system.*
