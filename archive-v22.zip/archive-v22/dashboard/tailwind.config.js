/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        // Premium dark theme palette
        slate: {
          850: '#1a1f2e',
          925: '#0f1219',
          950: '#080a0e',
        },
        // Status colors
        status: {
          compliant: '#10b981',   // emerald-500
          breach: '#ef4444',      // red-500
          warning: '#f59e0b',     // amber-500
          suspended: '#6b7280',   // gray-500
        },
        // Accent for premium feel (blue - v1.0)
        accent: {
          50: '#f0f9ff',
          100: '#e0f2fe',
          200: '#bae6fd',
          300: '#7dd3fc',
          400: '#38bdf8',
          500: '#0ea5e9',
          600: '#0284c7',
          700: '#0369a1',
          800: '#075985',
          900: '#0c4a6e',
        },
        // Gold accent for v2.0 Hub premium aesthetic
        gold: {
          50: '#fefce8',
          100: '#fef9c3',
          200: '#fef08a',
          300: '#fde047',
          400: '#facc15',
          500: '#D4AF37',    // Primary gold
          600: '#B8972E',
          700: '#8B7355',    // Muted gold
          800: '#713f12',
          900: '#422006',
        },
        // Hub-specific background colors
        hub: {
          bg: '#0A1628',           // Deep navy
          card: '#152238',         // Elevated card
          secondary: '#1C2433',    // Charcoal
          tertiary: '#2A3544',     // Lighter
          border: '#2D3748',       // Border
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        display: ['Playfair Display', 'Georgia', 'serif'],
        mono: ['JetBrains Mono', 'Consolas', 'monospace'],
      },
      boxShadow: {
        'glow': '0 0 20px rgba(14, 165, 233, 0.15)',
        'glow-sm': '0 0 10px rgba(14, 165, 233, 0.1)',
        'glow-gold': '0 0 20px rgba(212, 175, 55, 0.15)',
        'glow-gold-sm': '0 0 10px rgba(212, 175, 55, 0.1)',
      },
    },
  },
  plugins: [],
}
