export { DiffViewer } from './DiffViewer';
export type { DiffViewerProps, DiffLine } from './DiffViewer';
