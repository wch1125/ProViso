/**
 * Negotiation Studio - v2.0 Negotiation Module
 *
 * Form-based editing of credit agreement terms with version control.
 * This is the main editing interface for lawyers.
 */
import { useState } from 'react';
import { useParams } from 'react-router-dom';
import {
  Send,
  FileText,
  GitCompare,
  Code,
  History,
} from 'lucide-react';
import { Card, CardHeader, CardBody } from '../../components/Card';
import { Badge } from '../../components/base/Badge';
import { Button } from '../../components/base/Button';
import { Modal } from '../../components/base/Modal';
import { Select } from '../../components/base/Select';
import { DealPageLayout, DealPageSidebar, DealPageContent } from '../../components/layout';
import { NoChanges } from '../../components/base/EmptyState';
import { ConfirmationModal } from '../../components/base/ConfirmationModal';
import { DiffViewer } from '../../components/diff';
import { demoDeal, demoVersions, demoChangeSummaryV1toV2, demoChangeSummaryV2toV3 } from '../../data/negotiation-demo';
import type { DealVersion, ChangeSummary, Change } from '../../data/negotiation-demo';

export function NegotiationStudio() {
  const { dealId } = useParams<{ dealId: string }>();

  // In production, fetch deal from API using dealId
  const deal = demoDeal;
  const versions = demoVersions;
  const currentVersion = versions.find((v) => v.id === deal.currentVersionId);

  // Modal states
  const [showCompareModal, setShowCompareModal] = useState(false);
  const [showCodeModal, setShowCodeModal] = useState(false);
  const [showSendConfirmation, setShowSendConfirmation] = useState(false);
  const [selectedVersion, setSelectedVersion] = useState<DealVersion | null>(currentVersion || null);
  const [compareFromVersion, setCompareFromVersion] = useState<string>(versions[0]?.id || '');
  const [compareToVersion, setCompareToVersion] = useState<string>(versions[versions.length - 1]?.id || '');

  // Get change summary for display
  const getChangeSummary = (fromId: string, toId: string): ChangeSummary | null => {
    if (fromId === 'version-1' && toId === 'version-2') {
      return demoChangeSummaryV1toV2;
    }
    if (fromId === 'version-2' && toId === 'version-3') {
      return demoChangeSummaryV2toV3;
    }
    return null;
  };

  const handleVersionSelect = (version: DealVersion) => {
    setSelectedVersion(version);
  };

  const openCompareModal = () => {
    // Default to comparing current with previous
    const currentIdx = versions.findIndex((v) => v.id === currentVersion?.id);
    if (currentIdx > 0) {
      setCompareFromVersion(versions[currentIdx - 1].id);
      setCompareToVersion(versions[currentIdx].id);
    }
    setShowCompareModal(true);
  };

  const handleSendToCounterparty = () => {
    // In production, this would call the API
    setShowSendConfirmation(false);
    // Show success toast or redirect
  };

  return (
    <DealPageLayout
      dealId={dealId || 'unknown'}
      dealName={deal.name}
      dealStatus={deal.status as 'draft' | 'negotiation' | 'closing' | 'active' | 'matured'}
      subtitle={`${selectedVersion?.versionLabel} (v${selectedVersion?.versionNumber})`}
      actions={
        <>
          <Button
            variant="ghost"
            icon={<GitCompare className="w-4 h-4" />}
            size="sm"
            onClick={openCompareModal}
          >
            Compare
          </Button>
          <Button
            variant="ghost"
            icon={<Code className="w-4 h-4" />}
            size="sm"
            onClick={() => setShowCodeModal(true)}
          >
            View Code
          </Button>
          <Button
            variant="ghost"
            icon={<FileText className="w-4 h-4" />}
            size="sm"
          >
            Generate Word
          </Button>
          <Button
            variant="gold"
            icon={<Send className="w-4 h-4" />}
            size="sm"
            onClick={() => setShowSendConfirmation(true)}
          >
            Send to Counterparty
          </Button>
        </>
      }
    >
      {/* Main Layout: Sidebar + Content */}
      <div className="flex">
        {/* Left Sidebar - Versions */}
        <DealPageSidebar>
          <div className="mb-4">
            <h3 className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-3">
              Versions
            </h3>
            <div className="space-y-2">
              {versions.map((version) => (
                <button
                  key={version.id}
                  onClick={() => handleVersionSelect(version)}
                  className={`w-full text-left p-3 rounded-lg transition-colors ${
                    version.id === selectedVersion?.id
                      ? 'bg-accent-500/10 border border-accent-500/30'
                      : 'hover:bg-slate-800'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span
                      className={`text-sm font-medium ${
                        version.id === selectedVersion?.id
                          ? 'text-accent-400'
                          : 'text-white'
                      }`}
                    >
                      v{version.versionNumber}
                    </span>
                    <VersionStatusBadge status={version.status} />
                  </div>
                  <p className="text-xs text-slate-400 truncate">
                    {version.versionLabel}
                  </p>
                  <p className="text-xs text-slate-500 mt-1">
                    {version.authorParty}
                  </p>
                </button>
              ))}
            </div>
          </div>

          <div className="border-t border-slate-800 pt-4">
            <h3 className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-3">
              Sections
            </h3>
            <nav className="space-y-1">
              <SectionLink section="Art. 1" name="Definitions" active />
              <SectionLink section="Art. 7" name="Covenants" indent />
              <SectionLink section="7.02" name="Investments" indent />
              <SectionLink section="7.11" name="Financial Covenants" indent />
              <SectionLink section="Art. 8" name="Events of Default" />
            </nav>
          </div>
        </DealPageSidebar>

        {/* Main Content */}
        <DealPageContent className="flex-1">
          <div className="max-w-4xl">
            <Card className="mb-6">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <History className="w-5 h-5 text-slate-400" />
                    <h2 className="text-lg font-semibold text-white">
                      Changes in This Version
                    </h2>
                  </div>
                  {selectedVersion?.changeSummary && (
                    <div className="flex items-center gap-4 text-sm">
                      <span className="text-emerald-400">
                        {selectedVersion.changeSummary.borrowerFavorable} Borrower
                      </span>
                      <span className="text-red-400">
                        {selectedVersion.changeSummary.lenderFavorable} Lender
                      </span>
                      <span className="text-slate-400">
                        {selectedVersion.changeSummary.neutral} Neutral
                      </span>
                    </div>
                  )}
                </div>
              </CardHeader>
              <CardBody>
                {selectedVersion?.changeSummary ? (
                  <div className="space-y-4">
                    {selectedVersion.changeSummary.changes.map((change: Change) => (
                      <ChangeCard key={change.id} change={change} />
                    ))}
                  </div>
                ) : (
                  <NoChanges />
                )}
              </CardBody>
            </Card>

            {/* Placeholder for form-based editing */}
            <Card>
              <CardHeader>
                <h2 className="text-lg font-semibold text-white">
                  Article 7 - Financial Covenants
                </h2>
              </CardHeader>
              <CardBody>
                <div className="text-center py-12 text-slate-400">
                  <Code className="w-12 h-12 mx-auto mb-4 text-slate-600" />
                  <p className="text-lg mb-2">Form-based editing coming soon</p>
                  <p className="text-sm">
                    Forms will allow editing covenants, baskets, and definitions
                    <br />
                    with automatic code and Word document generation.
                  </p>
                </div>
              </CardBody>
            </Card>
          </div>
        </DealPageContent>
      </div>

      {/* Compare Modal */}
      <Modal
        isOpen={showCompareModal}
        onClose={() => setShowCompareModal(false)}
        title="Compare Versions"
        size="xl"
      >
        <div className="space-y-4">
          {/* Version selectors */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">
                From Version
              </label>
              <Select
                value={compareFromVersion}
                onChange={(e) => setCompareFromVersion(e.target.value)}
                options={versions.map((v) => ({
                  value: v.id,
                  label: `v${v.versionNumber} - ${v.versionLabel}`,
                }))}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">
                To Version
              </label>
              <Select
                value={compareToVersion}
                onChange={(e) => setCompareToVersion(e.target.value)}
                options={versions.map((v) => ({
                  value: v.id,
                  label: `v${v.versionNumber} - ${v.versionLabel}`,
                }))}
              />
            </div>
          </div>

          {/* Change Summary */}
          {(() => {
            const summary = getChangeSummary(compareFromVersion, compareToVersion);
            if (summary) {
              return (
                <div className="bg-slate-800/50 rounded-lg p-4">
                  <div className="flex items-center justify-between text-sm mb-2">
                    <span className="text-slate-400">
                      {summary.totalChanges} change{summary.totalChanges !== 1 ? 's' : ''}
                    </span>
                    <div className="flex gap-4">
                      <span className="text-emerald-400">
                        {summary.borrowerFavorable} Borrower Favorable
                      </span>
                      <span className="text-red-400">
                        {summary.lenderFavorable} Lender Favorable
                      </span>
                      <span className="text-slate-400">
                        {summary.neutral} Neutral
                      </span>
                    </div>
                  </div>
                </div>
              );
            }
            return null;
          })()}

          {/* Diff Viewer */}
          {(() => {
            const fromVersion = versions.find((v) => v.id === compareFromVersion);
            const toVersion = versions.find((v) => v.id === compareToVersion);
            if (fromVersion && toVersion) {
              return (
                <DiffViewer
                  fromCode={fromVersion.creditLangCode}
                  toCode={toVersion.creditLangCode}
                  fromLabel={`v${fromVersion.versionNumber} - ${fromVersion.authorParty}`}
                  toLabel={`v${toVersion.versionNumber} - ${toVersion.authorParty}`}
                  maxHeight="500px"
                />
              );
            }
            return null;
          })()}
        </div>
      </Modal>

      {/* View Code Modal */}
      <Modal
        isOpen={showCodeModal}
        onClose={() => setShowCodeModal(false)}
        title={`ProViso Code - ${selectedVersion?.versionLabel}`}
        size="lg"
      >
        <div className="rounded-lg border border-slate-700 bg-slate-900 overflow-hidden">
          <div className="px-4 py-2 bg-slate-800 border-b border-slate-700">
            <span className="text-sm text-slate-400">
              {selectedVersion?.authorParty} &middot; v{selectedVersion?.versionNumber}
            </span>
          </div>
          <pre className="p-4 text-sm font-mono text-slate-300 overflow-auto max-h-[500px]">
            <code>{selectedVersion?.creditLangCode}</code>
          </pre>
        </div>
      </Modal>

      {/* Send Confirmation Modal */}
      <ConfirmationModal
        isOpen={showSendConfirmation}
        onClose={() => setShowSendConfirmation(false)}
        onConfirm={handleSendToCounterparty}
        variant="warning"
        title="Send to Counterparty?"
        message="This will send the current version to the counterparty for review. They will be notified by email."
        confirmLabel="Send"
        cancelLabel="Cancel"
        details={[
          `Version: v${selectedVersion?.versionNumber} - ${selectedVersion?.versionLabel}`,
          `Changes: ${selectedVersion?.changeSummary?.totalChanges || 0} modifications`,
        ]}
      />
    </DealPageLayout>
  );
}

function VersionStatusBadge({ status }: { status: string }) {
  const config: Record<
    string,
    { label: string; variant: 'success' | 'warning' | 'info' | 'muted' }
  > = {
    draft: { label: 'Draft', variant: 'muted' },
    sent: { label: 'Sent', variant: 'info' },
    received: { label: 'Received', variant: 'info' },
    superseded: { label: 'Superseded', variant: 'muted' },
    executed: { label: 'Executed', variant: 'success' },
  };

  const c = config[status] || config.draft;
  return (
    <Badge variant={c.variant} size="sm">
      {c.label}
    </Badge>
  );
}

function SectionLink({
  section,
  name,
  active,
  indent,
}: {
  section: string;
  name: string;
  active?: boolean;
  indent?: boolean;
}) {
  return (
    <button
      className={`w-full text-left px-3 py-2 rounded-lg text-sm transition-colors ${
        active
          ? 'bg-accent-500/10 text-accent-400'
          : 'text-slate-400 hover:text-white hover:bg-slate-800'
      } ${indent ? 'pl-6' : ''}`}
    >
      <span className="text-slate-500 mr-2">{section}</span>
      {name}
    </button>
  );
}

interface ChangeCardProps {
  change: {
    id: string;
    title: string;
    description: string;
    sectionReference: string;
    elementType: string;
    impact: string;
    beforeValue: string | null;
    afterValue: string | null;
  };
}

function ChangeCard({ change }: ChangeCardProps) {
  const impactConfig: Record<string, { border: string; bg: string; icon: string }> = {
    borrower_favorable: {
      border: 'border-l-emerald-500',
      bg: 'bg-emerald-500/5',
      icon: '↑',
    },
    lender_favorable: {
      border: 'border-l-red-500',
      bg: 'bg-red-500/5',
      icon: '↓',
    },
    neutral: {
      border: 'border-l-slate-500',
      bg: 'bg-slate-500/5',
      icon: '•',
    },
    unclear: {
      border: 'border-l-slate-600',
      bg: '',
      icon: '?',
    },
  };

  const config = impactConfig[change.impact] || impactConfig.unclear;

  return (
    <div className={`border-l-4 rounded-r-lg p-4 ${config.border} ${config.bg}`}>
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-500 font-mono">
            {change.sectionReference}
          </span>
          <Badge variant="muted" size="sm">
            {change.elementType}
          </Badge>
        </div>
        <span className="text-xs text-slate-500" title={change.impact.replace('_', ' ')}>
          {config.icon}
        </span>
      </div>
      <h4 className="text-sm font-medium text-white mb-1">{change.title}</h4>
      <p className="text-sm text-slate-400">{change.description}</p>
      {change.beforeValue && change.afterValue && (
        <div className="flex items-center gap-3 mt-2 text-sm">
          <span className="text-slate-500 line-through">{change.beforeValue}</span>
          <span className="text-slate-600">&rarr;</span>
          <span className="text-white font-medium">{change.afterValue}</span>
        </div>
      )}
    </div>
  );
}

export default NegotiationStudio;
