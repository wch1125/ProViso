/**
 * Closing Dashboard - v2.0 Closing Module
 *
 * Tracks conditions precedent, documents, and signatures for deal closing.
 * Integrates ReadinessMeter, CPChecklist, DocumentTracker, and SignatureTracker components.
 */
import { useState } from 'react';
import { useParams } from 'react-router-dom';
import {
  FileCheck,
  FileText,
  PenTool,
  CheckCircle2,
} from 'lucide-react';
import { Card, CardHeader, CardBody } from '../../components/Card';
import { Badge } from '../../components/base/Badge';
import { Button } from '../../components/base/Button';
import { Tabs, TabList, TabTrigger, TabPanel } from '../../components/base/Tabs';
import { DealPageLayout, DealPageContent } from '../../components/layout';
import { ConfirmationModal } from '../../components/base/ConfirmationModal';
import {
  ReadinessMeter,
  CPChecklist,
  DocumentTracker,
  SignatureTracker,
} from '../../components/closing';
import {
  closingDeal,
  closingConditions,
  closingDocuments,
  closingParties,
  getConditionStats,
  getDocumentStats,
  getSignatureStats,
  getDaysUntilClosing,
  getReadinessPercentage,
} from '../../data/closing-demo';

export function ClosingDashboard() {
  const { dealId } = useParams<{ dealId: string }>();
  const [_activeTab, setActiveTab] = useState('overview');
  const [showReadyToCloseModal, setShowReadyToCloseModal] = useState(false);

  // Get computed stats
  const conditionStats = getConditionStats();
  const documentStats = getDocumentStats();
  const signatureStats = getSignatureStats();
  const readinessPercent = getReadinessPercentage();
  const daysUntilClosing = getDaysUntilClosing();

  // Build party lookup map
  const partyMap = new Map(closingParties.map((p) => [p.id, p]));

  // Transform conditions for CPChecklist component
  const cpChecklistData = closingConditions.map((cp) => ({
    id: cp.id,
    sectionReference: cp.sectionReference,
    category: cp.category,
    title: cp.title,
    description: cp.description,
    responsiblePartyId: cp.responsiblePartyId,
    responsiblePartyName: partyMap.get(cp.responsiblePartyId)?.shortName ?? 'Unknown',
    status: cp.status,
    dueDate: cp.dueDate,
    isOverdue: cp.status === 'pending' && cp.dueDate !== null && cp.dueDate < new Date(),
    notes: cp.notes,
  }));

  // Transform documents for DocumentTracker component
  const documentTrackerData = closingDocuments.map((doc) => ({
    id: doc.id,
    documentType: doc.documentType,
    title: doc.title,
    fileName: doc.fileName,
    status: doc.status,
    responsiblePartyName: doc.responsiblePartyId
      ? partyMap.get(doc.responsiblePartyId)?.shortName ?? null
      : null,
    dueDate: doc.dueDate,
    isOverdue: doc.status === 'pending' && doc.dueDate !== null && doc.dueDate < new Date(),
    signatures: doc.signatures.map((sig) => ({
      id: sig.id,
      partyId: sig.partyId,
      partyName: partyMap.get(sig.partyId)?.shortName ?? 'Unknown',
      signatoryName: sig.signatoryName,
      signatoryTitle: sig.signatoryTitle,
      status: sig.status,
      signedAt: sig.signedAt,
    })),
    linkedConditions: doc.satisfiesConditionIds,
  }));

  // Transform for SignatureTracker component
  const signatureTrackerData = closingDocuments
    .filter((doc) => doc.signatures.length > 0)
    .map((doc) => ({
      documentId: doc.id,
      documentTitle: doc.title,
      signatures: doc.signatures.map((sig) => ({
        id: sig.id,
        partyId: sig.partyId,
        partyName: partyMap.get(sig.partyId)?.shortName ?? 'Unknown',
        signatoryName: sig.signatoryName,
        signatoryTitle: sig.signatoryTitle,
        status: sig.status,
        signedAt: sig.signedAt,
      })),
    }));

  // Handler stubs (would call API in production)
  const handleConditionStatusChange = (_id: string, _status: 'satisfied' | 'waived') => {
    // In production, call API to update condition status
  };

  const handleDocumentUpload = (_documentId: string) => {
    // In production, trigger file upload dialog
  };

  const handleRequestSignature = (_documentId: string, _signatureId: string) => {
    // In production, send signature request email
  };

  const handleMarkReadyToClose = () => {
    // In production, call API to mark deal as ready to close
    setShowReadyToCloseModal(false);
  };

  return (
    <DealPageLayout
      dealId={dealId || 'unknown'}
      dealName={closingDeal.name}
      dealStatus="closing"
      subtitle={`Target Close: ${closingDeal.targetClosingDate.toLocaleDateString('en-US', {
        month: 'long',
        day: 'numeric',
        year: 'numeric',
      })}`}
      actions={
        <>
          <Button variant="ghost" icon={<FileText className="w-4 h-4" />} size="sm">
            Export Checklist
          </Button>
          <Button
            variant="gold"
            icon={<CheckCircle2 className="w-4 h-4" />}
            size="sm"
            onClick={() => setShowReadyToCloseModal(true)}
          >
            Mark Ready to Close
          </Button>
        </>
      }
    >
      {/* Content */}
      <DealPageContent>
        {/* Readiness Meter - Always visible */}
        <ReadinessMeter
          readinessPercentage={readinessPercent}
          conditions={conditionStats}
          documents={{
            total: documentStats.total,
            uploaded: documentStats.uploaded + documentStats.executed,
            pending: documentStats.pending,
          }}
          signatures={signatureStats}
          daysUntilClosing={daysUntilClosing}
          targetDate={closingDeal.targetClosingDate}
        />

        {/* Tabs for different views */}
        <div className="mt-6">
          <Tabs defaultTab="overview" onChange={setActiveTab}>
            <TabList>
              <TabTrigger id="overview" icon={<FileCheck className="w-4 h-4" />}>
                Conditions ({conditionStats.pending} pending)
              </TabTrigger>
              <TabTrigger id="documents" icon={<FileText className="w-4 h-4" />}>
                Documents ({documentStats.pending} pending)
              </TabTrigger>
              <TabTrigger id="signatures" icon={<PenTool className="w-4 h-4" />}>
                Signatures ({signatureStats.pending + signatureStats.requested} pending)
              </TabTrigger>
            </TabList>

            <TabPanel id="overview" className="mt-6">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <h2 className="text-lg font-semibold text-white">
                      Conditions Precedent
                    </h2>
                    <Badge variant="warning">
                      {conditionStats.pending} remaining
                    </Badge>
                  </div>
                </CardHeader>
                <CardBody>
                  <CPChecklist
                    conditions={cpChecklistData}
                    onStatusChange={handleConditionStatusChange}
                  />
                </CardBody>
              </Card>
            </TabPanel>

            <TabPanel id="documents" className="mt-6">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <h2 className="text-lg font-semibold text-white">
                      Closing Documents
                    </h2>
                    <Badge variant="info">
                      {documentStats.uploaded + documentStats.executed} received
                    </Badge>
                  </div>
                </CardHeader>
                <CardBody>
                  <DocumentTracker
                    documents={documentTrackerData}
                    onUpload={handleDocumentUpload}
                  />
                </CardBody>
              </Card>
            </TabPanel>

            <TabPanel id="signatures" className="mt-6">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <h2 className="text-lg font-semibold text-white">
                      Signature Tracking
                    </h2>
                    <Badge variant="success">
                      {signatureStats.signed} signed
                    </Badge>
                  </div>
                </CardHeader>
                <CardBody>
                  <SignatureTracker
                    documents={signatureTrackerData}
                    onRequestSignature={handleRequestSignature}
                  />
                </CardBody>
              </Card>
            </TabPanel>
          </Tabs>
        </div>
      </DealPageContent>

      {/* Ready to Close Confirmation Modal */}
      <ConfirmationModal
        isOpen={showReadyToCloseModal}
        onClose={() => setShowReadyToCloseModal(false)}
        onConfirm={handleMarkReadyToClose}
        variant="success"
        title="Mark Ready to Close?"
        message="This will notify all parties that the deal is ready for closing. Please ensure all conditions are satisfied."
        confirmLabel="Mark Ready"
        cancelLabel="Cancel"
        details={[
          `${conditionStats.satisfied + conditionStats.waived} of ${conditionStats.total} conditions complete`,
          `${documentStats.uploaded + documentStats.executed} of ${documentStats.total} documents received`,
          `${signatureStats.signed} of ${signatureStats.total} signatures collected`,
        ]}
      />
    </DealPageLayout>
  );
}

export default ClosingDashboard;
