/**
 * Default financial data for dashboard initialization.
 * This matches the Sunrise Solar Project example.
 */

export const DEFAULT_FINANCIALS = {
  // Income statement items
  net_income: 8_000_000,
  interest_expense: 6_000_000,
  tax_expense: 2_000_000,
  depreciation: 4_000_000,
  amortization: 1_000_000,

  // Debt structure
  senior_debt: 100_000_000,
  subordinated_debt: 20_000_000,
  senior_interest: 4_000_000,
  senior_principal: 3_000_000,

  // Project metrics
  total_project_cost: 150_000_000,
  equity_contributed: 55_000_000,

  // Cash flow items
  monthly_debt_service: 5_000_000,
  annual_capex_budget: 16_000_000,
  operating_expenses: 3_200_000,
  distributions: 5_000_000,
  Revenue: 12_500_000,

  // Balance sheet
  total_assets: 180_000_000,
};

/**
 * Project metadata (not used by interpreter, but useful for display)
 */
export const DEFAULT_PROJECT_INFO = {
  name: 'Sunrise Solar Project',
  facility: '$150M Construction + Term',
  sponsor: 'Renewable Energy Partners',
  borrower: 'Sunrise Solar Holdings LLC',
};

/**
 * Phase timeline info
 */
export const DEFAULT_PHASE_INFO = {
  current: 'construction',
  constructionStart: '2025-06-01',
  codTarget: '2026-09-15',
  maturity: '2041-09-15',
};
