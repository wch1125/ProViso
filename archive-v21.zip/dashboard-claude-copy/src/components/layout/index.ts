export {
  DealPageLayout,
  DealPageContent,
  DealPageSidebar,
  DealPageWithSidebar,
} from './DealPageLayout';
