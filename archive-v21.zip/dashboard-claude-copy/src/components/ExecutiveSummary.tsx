import { CheckCircle2, AlertTriangle, XCircle, DollarSign, Calendar, TrendingUp } from 'lucide-react';
import { Card, CardBody } from './Card';
import type { DashboardData } from '../types';

interface ExecutiveSummaryProps {
  data: DashboardData;
}

export function ExecutiveSummary({ data }: ExecutiveSummaryProps) {
  // Calculate key metrics
  const totalCovenants = data.covenants.length;
  const activeCovenants = data.covenants.filter(c => !c.suspended);
  const compliantCount = activeCovenants.filter(c => c.compliant).length;
  const activeCount = activeCovenants.length;

  const milestonesAchieved = data.milestones.filter(m => m.status === 'achieved').length;
  const milestonesAtRisk = data.milestones.filter(m => m.status === 'at_risk' || m.status === 'breached').length;

  const totalReserveBalance = data.reserves.reduce((sum, r) => sum + r.balance, 0);
  const totalReserveTarget = data.reserves.reduce((sum, r) => sum + r.target, 0);
  const reserveFunding = (totalReserveBalance / totalReserveTarget) * 100;

  const waterfallDistributed = data.waterfall.tiers
    .filter(t => !t.blocked)
    .reduce((sum, t) => sum + t.amount, 0);
  const blockedDistribution = data.waterfall.tiers
    .filter(t => t.blocked)
    .reduce((sum, t) => sum + t.amount, 0);

  // Overall status
  const allCompliant = activeCovenants.every(c => c.compliant);
  const hasWarnings = milestonesAtRisk > 0 || blockedDistribution > 0;

  return (
    <Card className="col-span-full">
      <CardBody className="p-0">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 divide-y md:divide-y-0 md:divide-x divide-slate-800">
          {/* Overall Compliance */}
          <div className="p-5">
            <div className="flex items-start justify-between">
              <div>
                <p className="metric-label mb-1">Overall Status</p>
                <div className="flex items-center gap-2">
                  {allCompliant ? (
                    <CheckCircle2 className="w-6 h-6 text-emerald-500" />
                  ) : (
                    <XCircle className="w-6 h-6 text-red-500" />
                  )}
                  <span className={`text-xl font-semibold ${allCompliant ? 'text-emerald-400' : 'text-red-400'}`}>
                    {allCompliant ? 'Compliant' : 'Breach'}
                  </span>
                </div>
              </div>
            </div>
            <p className="text-sm text-gray-500 mt-3">
              {compliantCount}/{activeCount} active covenants passing
              {totalCovenants - activeCount > 0 && (
                <span className="text-gray-600"> ({totalCovenants - activeCount} suspended)</span>
              )}
            </p>
          </div>

          {/* Project Progress */}
          <div className="p-5">
            <div className="flex items-start justify-between">
              <div>
                <p className="metric-label mb-1">Milestones</p>
                <div className="flex items-center gap-2">
                  <TrendingUp className="w-6 h-6 text-accent-500" />
                  <span className="metric-value">
                    {milestonesAchieved}/{data.milestones.length}
                  </span>
                </div>
              </div>
            </div>
            <p className="text-sm text-gray-500 mt-3">
              {milestonesAtRisk > 0 ? (
                <span className="text-amber-400">{milestonesAtRisk} at risk or breached</span>
              ) : (
                'All milestones on track'
              )}
            </p>
          </div>

          {/* Reserve Funding */}
          <div className="p-5">
            <div className="flex items-start justify-between">
              <div>
                <p className="metric-label mb-1">Reserve Funding</p>
                <div className="flex items-center gap-2">
                  <DollarSign className="w-6 h-6 text-accent-500" />
                  <span className="metric-value">{reserveFunding.toFixed(0)}%</span>
                </div>
              </div>
            </div>
            <p className="text-sm text-gray-500 mt-3">
              ${(totalReserveBalance / 1_000_000).toFixed(1)}M of ${(totalReserveTarget / 1_000_000).toFixed(1)}M target
            </p>
          </div>

          {/* Cash Flow */}
          <div className="p-5">
            <div className="flex items-start justify-between">
              <div>
                <p className="metric-label mb-1">Monthly Revenue</p>
                <div className="flex items-center gap-2">
                  <DollarSign className="w-6 h-6 text-accent-500" />
                  <span className="metric-value">${(data.waterfall.revenue / 1_000_000).toFixed(1)}M</span>
                </div>
              </div>
            </div>
            <p className="text-sm text-gray-500 mt-3">
              {blockedDistribution > 0 ? (
                <span className="text-amber-400">
                  ${(blockedDistribution / 1_000_000).toFixed(1)}M blocked
                </span>
              ) : (
                `$${(waterfallDistributed / 1_000_000).toFixed(1)}M distributed`
              )}
            </p>
          </div>

          {/* COD Target */}
          <div className="p-5">
            <div className="flex items-start justify-between">
              <div>
                <p className="metric-label mb-1">COD Target</p>
                <div className="flex items-center gap-2">
                  <Calendar className="w-6 h-6 text-accent-500" />
                  <span className="metric-value text-lg">
                    {new Date(data.phase.codTarget).toLocaleDateString('en-US', {
                      month: 'short',
                      year: 'numeric'
                    })}
                  </span>
                </div>
              </div>
            </div>
            <p className="text-sm text-gray-500 mt-3">
              {getDaysUntil(data.phase.codTarget)} days remaining
            </p>
          </div>
        </div>

        {/* Alert Banner */}
        {(hasWarnings || !allCompliant) && (
          <div className={`px-5 py-3 border-t ${allCompliant ? 'bg-amber-500/5 border-amber-500/20' : 'bg-red-500/5 border-red-500/20'}`}>
            <div className="flex items-center gap-2">
              <AlertTriangle className={`w-4 h-4 ${allCompliant ? 'text-amber-400' : 'text-red-400'}`} />
              <span className={`text-sm font-medium ${allCompliant ? 'text-amber-400' : 'text-red-400'}`}>
                {!allCompliant
                  ? 'Covenant breach detected - review required'
                  : milestonesAtRisk > 0
                  ? 'Milestone deadline at risk'
                  : 'Distribution blocked - DSCR gate not met'}
              </span>
            </div>
          </div>
        )}
      </CardBody>
    </Card>
  );
}

function getDaysUntil(dateStr: string): number {
  const target = new Date(dateStr);
  const now = new Date();
  const diff = target.getTime() - now.getTime();
  return Math.ceil(diff / (1000 * 60 * 60 * 24));
}
