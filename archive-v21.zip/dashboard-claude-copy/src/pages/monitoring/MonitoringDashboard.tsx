/**
 * Monitoring Dashboard - Post-Closing Dashboard (v1.0 + v2.1 Industry)
 *
 * This is the existing v1.0 dashboard with v2.1 industry components.
 * Shows project finance monitoring: phases, covenants, waterfalls, reserves, milestones,
 * plus industry-specific: performance guarantees, regulatory tracking, technical progress, tax equity.
 */
import { useParams } from 'react-router-dom';
import { FileText, Settings } from 'lucide-react';
import { Button } from '../../components/base/Button';
import { DealPageLayout, DealPageContent } from '../../components/layout';
import {
  ExecutiveSummary,
  PhaseTimeline,
  CovenantPanel,
  WaterfallChart,
  ReserveStatus,
  MilestoneTracker,
  CPChecklist,
  // v2.1 Industry components
  PerformanceChart,
  RegulatoryTracker,
  TechnicalProgress,
  TaxEquityPanel,
} from '../../components';
import { demoData } from '../../data/demo';

export function MonitoringDashboard() {
  const { dealId } = useParams<{ dealId: string }>();
  const data = demoData;

  return (
    <DealPageLayout
      dealId={dealId || 'unknown'}
      dealName={data.project.name}
      dealStatus="active"
      subtitle={data.project.facility}
      actions={
        <>
          <Button variant="ghost" icon={<FileText className="w-4 h-4" />} size="sm">
            Export Report
          </Button>
          <Button variant="ghost" icon={<Settings className="w-4 h-4" />} size="sm">
            Settings
          </Button>
        </>
      }
    >
      <DealPageContent>
        {/* Executive Summary - Full Width */}
        <ExecutiveSummary data={data} />

        {/* Phase Timeline - Full Width */}
        <div className="mt-6">
          <PhaseTimeline phase={data.phase} />
        </div>

        {/* Main Grid - 3 Column Layout */}
        <div className="mt-6 grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Covenants */}
          <div className="lg:col-span-1">
            <CovenantPanel covenants={data.covenants} />
          </div>

          {/* Middle Column - Waterfall + Reserves */}
          <div className="lg:col-span-1 space-y-6">
            <WaterfallChart waterfall={data.waterfall} />
            <ReserveStatus reserves={data.reserves} />
          </div>

          {/* Right Column - Milestones + CPs */}
          <div className="lg:col-span-1 space-y-6">
            <MilestoneTracker milestones={data.milestones} />
            <CPChecklist checklists={data.conditionsPrecedent} />
          </div>
        </div>

        {/* v2.1 Industry Section */}
        {data.industry && (
          <>
            <div className="mt-8 mb-4">
              <h2 className="text-xl font-bold text-white">Industry Analytics</h2>
              <p className="text-sm text-gray-400">Performance, regulatory, and tax equity tracking</p>
            </div>

            {/* Industry Grid - 2x2 Layout */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Performance & Technical */}
              {data.industry.performanceGuarantees && (
                <PerformanceChart
                  guarantees={data.industry.performanceGuarantees}
                  degradation={data.industry.degradation}
                />
              )}
              {data.industry.technicalMilestones && (
                <TechnicalProgress milestones={data.industry.technicalMilestones} />
              )}

              {/* Regulatory & Tax Equity */}
              {data.industry.regulatoryRequirements && (
                <RegulatoryTracker requirements={data.industry.regulatoryRequirements} />
              )}
              {data.industry.taxEquity && (
                <TaxEquityPanel
                  structure={data.industry.taxEquity.structure}
                  credits={data.industry.taxEquity.credits}
                  depreciation={data.industry.taxEquity.depreciation}
                  flipEvents={data.industry.taxEquity.flipEvents}
                />
              )}
            </div>
          </>
        )}
      </DealPageContent>
    </DealPageLayout>
  );
}

export default MonitoringDashboard;
