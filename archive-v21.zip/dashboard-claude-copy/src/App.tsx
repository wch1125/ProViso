import { lazy, Suspense } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';

// Lazy-loaded page components for code splitting
const DealList = lazy(() => import('./pages/deals/DealList'));
const NegotiationStudio = lazy(() => import('./pages/negotiation/NegotiationStudio'));
const ClosingDashboard = lazy(() => import('./pages/closing/ClosingDashboard'));
const MonitoringDashboard = lazy(() => import('./pages/monitoring/MonitoringDashboard'));

// Loading fallback component
function PageLoader() {
  return (
    <div className="min-h-screen bg-hub-bg flex items-center justify-center">
      <div className="text-center">
        <div className="w-8 h-8 border-2 border-gold-500 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
        <p className="text-gray-400">Loading...</p>
      </div>
    </div>
  );
}

function App() {
  return (
    <BrowserRouter>
      <Suspense fallback={<PageLoader />}>
        <Routes>
          {/* Deal list - entry point */}
          <Route path="/deals" element={<DealList />} />

          {/* Deal-specific routes */}
          <Route path="/deals/:dealId/negotiate" element={<NegotiationStudio />} />
          <Route path="/deals/:dealId/closing" element={<ClosingDashboard />} />
          <Route path="/deals/:dealId/monitor" element={<MonitoringDashboard />} />

          {/* Default redirect */}
          <Route path="/" element={<Navigate to="/deals" replace />} />
          <Route path="*" element={<Navigate to="/deals" replace />} />
        </Routes>
      </Suspense>
    </BrowserRouter>
  );
}

export default App;
